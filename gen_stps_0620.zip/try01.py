from pathlib import Path
import sys

ROOT_PATH = Path(__file__).resolve().parent
TOOLBOX_PATH = ROOT_PATH / "toolbox"
if str(TOOLBOX_PATH) not in sys.path: sys.path.append(str(TOOLBOX_PATH))
from common_functions import get_files, create_folder
from cad_helper import Cad_Helper

cad = Cad_Helper()
search_folder = ROOT_PATH / "stp_0620"
fnames, fpaths = get_files(str(search_folder), ["stp"])
out_folder = ROOT_PATH / "cad_output" / cad.timestamp
cad.debug_output_folder = out_folder
dxf_folder = out_folder / "dxf"
debug_folder = out_folder / "debug"
create_folder(str(dxf_folder))
create_folder(str(debug_folder))
ok_items = []
fail_items = []
used_names = {}
for fname, fpath in zip(fnames, fpaths):
    out_name = fname
    used_names[fname] = used_names.get(fname, 0) + 1
    dxf_path = dxf_folder / "{}.dxf".format(out_name)
    cad.debug_output_folder = debug_folder / out_name
    create_folder(str(cad.debug_output_folder))
    cad.load(fpath)
    # cad.rotate(z=1)
    # cad.set_hidden({"front":False})
    # cad.rotate(x=1)
    cad.gather_info()
    dxf = cad.get_views(show_hidden=True)
    cad.debug_dump_stp_parse_info()
    # cad.gather_hole_sequence()
    # cad.debug_dump_dxf_entities()
    cad.auto_dim_holes()
    dxf = cad.doc
    dxf.saveas(str(dxf_path))
    ok_items.append(str(dxf_path))
    print("dxf:", dxf_path)
    cad.debug_dump_dxf_entity_counts()

print("done:", len(ok_items), "fail:", len(fail_items))
print("output:", out_folder)
