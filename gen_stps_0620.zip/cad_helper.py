from pathlib import Path
import re
import math
import ezdxf
import numpy as np
import cadquery as cq
from cadquery import importers, Compound
from cadquery.occ_impl.exporters.dxf import DxfDocument
from ezdxf.addons.drawing import matplotlib
from ezdxf.math import Vec2
from ezdxf.render.mleader import ConnectionSide, HorizontalConnection, TextAlignment
from OCP.BRepLib import BRepLib
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt
from common_functions import create_folder, save_txt, get_timestemp as get_timestamp

dxf_color_map = {
    "依圖塊": 0, "紅": 1, "黃": 2, "綠": 3, "青": 4, "藍": 5, "紫紅": 6,
    "洋紅": 6, "粉": 6, "白": 7, "黑": 7, "深灰": 8, "淺灰": 9, "橘色": 30, "依圖層": 256,}
dxf_layer_items = {
    "0": {"color": dxf_color_map["白"], "linetype": "CONTINUOUS", "lineweight": 18},
    "HID": {"color": dxf_color_map["綠"], "linetype": "HIDDEN", "lineweight": 18},
    "SUP": {"color": dxf_color_map["橘色"], "linetype": "CONTINUOUS", "lineweight": 18},
    "AUTO_CEN": {"color": dxf_color_map["紅"], "linetype": "AUTO_CENTER", "lineweight": 18},
    "DIM": {"color": dxf_color_map["黃"], "linetype": "CONTINUOUS", "lineweight": 18},
    "HAT": {"color": dxf_color_map["青"], "linetype": "CONTINUOUS", "lineweight": 18},
    "TAN": {"color": dxf_color_map["青"], "linetype": "CONTINUOUS", "lineweight": 18},
    "DEBUG1": {"color": dxf_color_map["淺灰"], "linetype": "CONTINUOUS", "lineweight": 18},
    "DEBUG2": {"color": dxf_color_map["粉"], "linetype": "CONTINUOUS", "lineweight": 18},
    "DEBUG3": {"color": dxf_color_map["紫紅"], "linetype": "CONTINUOUS", "lineweight": 18},
}
dxf_linetype_items = {
    "HIDDEN": {"pattern": [4, 3, -1], "description": "Hidden __ __ __ __ __ __ __"},
    "AUTO_CENTER": {"pattern": [12.5, 5, -1, 0.5, -1, 5], "description": "Auto center ____ . ____ . ____"},
}
THREAD_SIZE_ITEMS = {
    "M2": {"major_d": 2.0, "minor_d": 1.57, "pitch": 0.4},
    "M2.5": {"major_d": 2.5, "minor_d": 2.01, "pitch": 0.45},
    "M3": {"major_d": 3.0, "minor_d": 2.46, "pitch": 0.5},
    "M3.5": {"major_d": 3.5, "minor_d": 2.85, "pitch": 0.6},
    "M4": {"major_d": 4.0, "minor_d": 3.24, "pitch": 0.7},
    "M5": {"major_d": 5.0, "minor_d": 4.13, "pitch": 0.8},
    "M6": {"major_d": 6.0, "minor_d": 4.92, "pitch": 1.0},
    "M7": {"major_d": 7.0, "minor_d": 5.92, "pitch": 1.0},
    "M8": {"major_d": 8.0, "minor_d": 6.65, "pitch": 1.25},
    "M10": {"major_d": 10.0, "minor_d": 8.38, "pitch": 1.5},
    "M12": {"major_d": 12.0, "minor_d": 10.11, "pitch": 1.75},
    "M14": {"major_d": 14.0, "minor_d": 11.83, "pitch": 2.0},
    "M16": {"major_d": 16.0, "minor_d": 13.83, "pitch": 2.0},
    "M18": {"major_d": 18.0, "minor_d": 15.29, "pitch": 2.5},
}
VIEW_DIRECTION = {
    "front": {"N": (0, 0, 1), "U": (0, 1, 0), "label": "FRONT"},
    "right": {"N": (1, 0, 0), "U": (0, 1, 0), "label": "RIGHT"},
    "top": {"N": (0, 1, 0), "U": (0, 0, -1), "label": "TOP"},
    "back": {"N": (0, 0, -1), "U": (0, 1, 0), "label": "BACK"},
    "left": {"N": (-1, 0, 0), "U": (0, 1, 0), "label": "LEFT"},
    "bottom": {"N": (0, -1, 0), "U": (0, 0, 1), "label": "BOTTOM"},
    "iso_front": {"N": (1, 1, 1), "U": (0, 1, 0), "label": "ISO FRONT"},
    "iso_back": {"N": (-1, -1, -1), "U": (0, 1, 0), "label": "ISO BACK"},
}


class Cad_Helper:
    ### ------------- 初始化 ------------------
    def __init__(self, stp_fpath=None):
        self.stp_fpath = None
        self.model = None
        self.doc = None
        self.dxf_doc = None
        self.view_data = None
        self.proj_matrix = None
        self.proj_offset = None
        self.dxf_entity_table = None
        self.timestamp = get_timestamp()
        self.debug_output_folder = Path("./cad_output") / self.timestamp
        create_folder(str(self.debug_output_folder))
        self.rotate_info = {"x": 0, "y": 0, "z": 0}
        self.rotation_matrix = np.eye(3)
        self.view_map_after_rotate = {"front": "front", "right": "right", "top": "top", "back": "back", "left": "left", "bottom": "bottom"}
        self.hidden_view_after_rotate = {}
        self.ct_info = None
        self.entities = {}
        self.info = {"circles": {}, "faces": {}, "lines": {}}
        self.hlr_view_cache = {}
        if stp_fpath is not None:
            self.load(stp_fpath)
    def load(self, stp_fpath):
        self.stp_fpath = Path(stp_fpath)
        self.model = importers.importStep(str(self.stp_fpath))
        txt_data = self.stp_fpath.read_text(encoding="utf-8", errors="ignore")
        entities = {}
        for m in re.finditer(r"#(\d+)\s*=\s*(.*?);", txt_data, re.S):
            id_name = "#" + m.group(1)
            text = " ".join(m.group(2).split())
            f = re.match(r"([A-Z0-9_]+)\s*\((.*)\)$", text)
            func, items = (f.group(1), self._split_params(f.group(2))) if f else ("", [])
            entities[id_name] = {"id": id_name, "idx": int(m.group(1)), "func": func, "items": items, "refs": re.findall(r"#\d+", text), "text": text}
        self.entities = entities
        return entities
    def _init_dxf_document(self):
        doc = DxfDocument(setup=["linetypes"])
        for name, item in dxf_linetype_items.items():
            if name not in doc.document.linetypes:
                doc.document.linetypes.add(name, **item)
            else:
                linetype = doc.document.linetypes.get(name)
                try:
                    linetype.dxf.description = item.get("description", linetype.dxf.get("description", ""))
                    linetype.setup_pattern(item["pattern"])
                except:
                    pass
        for layer_name, layer_item in dxf_layer_items.items():
            layer_kw = {"color": layer_item["color"]}
            if layer_item.get("linetype") is not None:
                layer_kw["linetype"] = layer_item["linetype"]
            if layer_name not in doc.document.layers:
                doc.add_layer(layer_name, **layer_kw)
            layer = doc.document.layers.get(layer_name)
            layer.dxf.color = layer_item["color"]
            layer.dxf.linetype = layer_item.get("linetype", "CONTINUOUS")
            layer.dxf.lineweight = layer_item["lineweight"]
        self.dxf_doc = doc
        self.doc = doc.document
        msp = self.doc.modelspace()
        init_entities = list(msp)
        init_handles = [ent.dxf.handle for ent in init_entities if hasattr(ent.dxf, "handle")]
        self.dxf_entity_table = {"init_count": len(init_entities), "init_handles": init_handles, "items": [], "by_view": {}}
        return self.doc
    def gather_info(self,):
        entities = self.entities
        self.info["circles"] = self._gather_circles(entities)
        self.info["faces"] = self._gather_faces(entities)
        self.info["lines"] = self._gather_lines(entities)
        self.gather_cylinder_groups()
        self.gather_planes_dim()
        self.gather_hole_sequence()
        return self.info
    def gather_planes_dim(self,):
        if not self.info.get("faces"):
            self.gather_info()
        info = self.info["faces"]
        if not hasattr(self, "need_dim") or self.need_dim is None:
            self.need_dim = {}
        self.need_dim["planes"] = {"dx": [], "dy": [], "dz": []}
        axis_items = {0: "dx", 1: "dy", 2: "dz"}
        for id in info:
            item = info[id]
            this_type = item.get("type")
            if this_type != "PLANE":
                continue
            org = item.get("org", [])
            dir_n = item.get("dir_n", [])
            if len(org) != 3 or len(dir_n) != 3:
                continue
            dir_n = np.array(dir_n, dtype=float)
            org = np.array(org, dtype=float)
            dir_len = float(np.linalg.norm(dir_n))
            if dir_len <= 1e-3:
                continue
            dir_n = dir_n / dir_len
            axis_i = int(np.argmax(np.abs(dir_n)))
            if abs(abs(dir_n[axis_i]) - 1) > 1e-6:
                continue
            if any(abs(dir_n[i]) > 1e-6 for i in range(3) if i != axis_i):
                continue
            this_axis = axis_items[axis_i]
            this_axis_dval = float(org[axis_i])
            self.need_dim["planes"][this_axis].append(this_axis_dval)
        return self.need_dim["planes"]
    def gather_cylinder_groups(self,):
        if not self.info.get("faces"):
            self.gather_info()
        faces = self.info["faces"]
        curve_types = ("CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "TOROIDAL_SURFACE")
        curve_ids = [fid for fid in faces if faces[fid].get("type") in curve_types]
        circle2faces = {}
        for fid in faces:
            for c in faces[fid].get("edge_circles", []):
                circle2faces.setdefault(c, []).append(fid)
        parent = {fid: fid for fid in curve_ids}
        shoulder_planes = {}
        def find(a):
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a
        def union(a, b):
            ra, rb = find(a), find(b)
            if ra != rb:
                parent[ra] = rb
        for c in circle2faces:
            cur = [f for f in circle2faces[c] if f in parent]
            for i in range(1, len(cur)):
                union(cur[0], cur[i])
        for fid in faces:
            if faces[fid].get("type") != "PLANE":
                continue
            touch = []
            for c in faces[fid].get("edge_circles", []):
                for f in circle2faces.get(c, []):
                    if f in parent and f not in touch:
                        touch.append(f)
            for i in range(len(touch)):
                for j in range(i + 1, len(touch)):
                    if self._is_coaxial(faces[touch[i]], faces[touch[j]]):
                        union(touch[i], touch[j])
                        shoulder_planes.setdefault(fid, [])
                        if touch[i] not in shoulder_planes[fid]:
                            shoulder_planes[fid].append(touch[i])
                        if touch[j] not in shoulder_planes[fid]:
                            shoulder_planes[fid].append(touch[j])
        groups = {}
        for fid in curve_ids:
            root = find(fid)
            groups.setdefault(root, []).append(fid)
        for plane_id, touch in shoulder_planes.items():
            for fid in touch:
                root = find(fid)
                if plane_id not in groups[root]:
                    groups[root].append(plane_id)
        result = list(groups.values())
        self.info["cylinder_groups"] = result
        return result
    def gather_hole_sequence(self,):
        if not self.info.get("faces"):
            self.gather_info()
        if "cylinder_groups" not in self.info:
            self.gather_cylinder_groups()
        if not hasattr(self, "dim_info") or self.dim_info is None:
            self.dim_info = {}
        self.dim_info["holes"] = {}
        faces = self.info["faces"]
        circles = self.info.get("circles", {})
        curve_types = ("CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "TOROIDAL_SURFACE")
        type_map = {"CYLINDRICAL_SURFACE": "圓柱", "CONICAL_SURFACE": "導角", "TOROIDAL_SURFACE": "圓角", "PLANE": "平面"}
        for gp_i, this_cylin_gp in enumerate(self.info.get("cylinder_groups", [])):
            axis_dir = None
            for fid in this_cylin_gp:
                face = faces.get(fid, {})
                if face.get("type") not in curve_types:
                    continue
                dir_n = face.get("dir_n", [])
                if len(dir_n) != 3:
                    continue
                dir_v = np.array(dir_n, dtype=float)
                dir_len = float(np.linalg.norm(dir_v))
                if dir_len <= 1e-12:
                    continue
                axis_dir = dir_v / dir_len
                break
            if axis_dir is None:
                for fid in this_cylin_gp:
                    dir_n = faces.get(fid, {}).get("dir_n", [])
                    if len(dir_n) != 3:
                        continue
                    dir_v = np.array(dir_n, dtype=float)
                    dir_len = float(np.linalg.norm(dir_v))
                    if dir_len > 1e-12:
                        axis_dir = dir_v / dir_len
                        break
            if axis_dir is None:
                continue
            hole_items = []
            for fid in this_cylin_gp:
                face = faces.get(fid, {})
                if not face:
                    continue
                centers = []
                radii = []
                for circle_id in face.get("edge_circles", []):
                    circle = circles.get(circle_id, {})
                    org = circle.get("org", [])
                    if len(org) == 3:
                        centers.append(np.array(org, dtype=float))
                    r = circle.get("r")
                    if r not in (None, ""):
                        try:
                            radii.append(float(r))
                        except:
                            pass
                if centers:
                    center = np.mean(np.array(centers, dtype=float), axis=0)
                else:
                    org = face.get("org", [])
                    if len(org) != 3:
                        continue
                    center = np.array(org, dtype=float)
                hole_items.append({"id": fid, "type": type_map.get(face.get("type"), face.get("type")), "surface_type": face.get("type"), "center": center, "r": max(radii) if radii else None})
            if not hole_items:
                continue
            for item in hole_items:
                item["depth"] = float(np.dot(item["center"], axis_dir))
            rank = sorted(hole_items, key=lambda item: item["depth"])
            r_items = [item for item in rank if item["r"] is not None and item["surface_type"] in curve_types]
            if not r_items:
                r_items = [item for item in rank if item["r"] is not None]
            c_start = max(r_items, key=lambda item: item["r"]) if r_items else None
            seq_dir = axis_dir
            if c_start is not None and rank and c_start["id"] != rank[0]["id"]:
                seq_dir = -seq_dir
            for item in hole_items:
                item["depth"] = float(np.dot(item["center"], seq_dir))
            rank = sorted(hole_items, key=lambda item: item["depth"])
            this_seq = []
            for item in rank:
                seq_item = {"id": item["id"], "type": item["type"], "depth": item["depth"], "center": item["center"].tolist()}
                if item["r"] is not None:
                    seq_item["r"] = item["r"]
                if item["surface_type"] == "PLANE":
                    dir_n = faces.get(item["id"], {}).get("dir_n", [])
                    body = "unknown"
                    if len(dir_n) == 3:
                        dir_v = np.array(dir_n, dtype=float)
                        dir_len = float(np.linalg.norm(dir_v))
                        if dir_len > 1e-12:
                            body = "forward" if float(np.dot(dir_v / dir_len, seq_dir)) >= 0 else "backward"
                    seq_item["body"] = body
                this_seq.append(seq_item)
            self.dim_info["holes"][gp_i] = {"faces": list(this_cylin_gp), "axis_dir": seq_dir.tolist(), "seq": this_seq}
        return self.dim_info["holes"]
    ### ------------- 內部呼叫 ------------------
    def _cvt_hole_dim_text(self, thd_dim=None, drill_dim=None, thd_depth=None, drill_depth=None, cb_dim=None, cb_depth=None):
        ret = []
        if thd_dim not in (None, ""):
            text = str(thd_dim)
            if thd_depth in (None, ""):
                text = "{},攻穿".format(text)
            else:
                thd_depth_text = "{:g}".format(float(thd_depth)) if isinstance(thd_depth, (int, float, np.integer, np.floating)) else str(thd_depth)
                text = "{},牙深{}".format(text, thd_depth_text)
            ret.append(text)
        elif drill_dim not in (None, ""):
            drill_dim_text = "{:g}".format(float(drill_dim)) if isinstance(drill_dim, (int, float, np.integer, np.floating)) else str(drill_dim)
            if not drill_dim_text.startswith(("∅", "Φ", "φ")):
                drill_dim_text = "∅" + drill_dim_text
            if drill_depth in (None, ""):
                text = "{},貫穿".format(drill_dim_text)
            else:
                drill_depth_text = "{:g}".format(float(drill_depth)) if isinstance(drill_depth, (int, float, np.integer, np.floating)) else str(drill_depth)
                text = "{},深{}".format(drill_dim_text, drill_depth_text)
            ret.append(text)
        if cb_dim not in (None, ""):
            cb_dim_text = "{:g}".format(float(cb_dim)) if isinstance(cb_dim, (int, float, np.integer, np.floating)) else str(cb_dim)
            if not cb_dim_text.startswith(("∅", "Φ", "φ")):
                cb_dim_text = "∅" + cb_dim_text
            if cb_depth in (None, ""):
                text = cb_dim_text
            else:
                cb_depth_text = "{:g}".format(float(cb_depth)) if isinstance(cb_depth, (int, float, np.integer, np.floating)) else str(cb_depth)
                text = "{},深{}".format(cb_dim_text, cb_depth_text)
            ret.append(text)
        word1 = ret[0] if ret else ""
        word2 = ret[1] if len(ret) > 1 else ""
        return word1, word2
    def _is_coaxial(self, fa, fb, dir_tol=1e-6, pos_tol=1e-3):
        na = np.array(fa.get("dir_n", []), dtype=float)
        nb = np.array(fb.get("dir_n", []), dtype=float)
        if na.shape != (3,) or nb.shape != (3,):
            return False
        na_len = float(np.linalg.norm(na))
        nb_len = float(np.linalg.norm(nb))
        if na_len <= 1e-12 or nb_len <= 1e-12:
            return False
        na = na / na_len
        nb = nb / nb_len
        if float(np.linalg.norm(np.cross(na, nb))) > dir_tol:
            return False
        oa = np.array(fa.get("org", []), dtype=float)
        ob = np.array(fb.get("org", []), dtype=float)
        if oa.shape != (3,) or ob.shape != (3,):
            return False
        d = ob - oa
        if float(np.linalg.norm(np.cross(d, na))) > pos_tol:
            return False
        return True
    def _split_params(self, data):
        ret, buf = [], []
        layer, in_text, i = 0, False, 0
        while i < len(data):
            ch = data[i]
            if ch == "'":
                buf.append(ch)
                if i + 1 < len(data) and data[i + 1] == "'":
                    buf.append(data[i + 1]); i += 2; continue
                in_text = not in_text
            elif not in_text and ch in "()":
                layer += 1 if ch == "(" else -1
                buf.append(ch)
            elif not in_text and ch == "," and layer == 0:
                ret.append("".join(buf).strip()); buf = []
            else:
                buf.append(ch)
            i += 1
        if buf: ret.append("".join(buf).strip())
        return ret
    def _cal_proj_hlr(self, stp_shape, view_normal_dir, x_dir, eta=1e-3):
        hlr = HLRBRep_Algo()
        hlr.Add(stp_shape.wrapped)
        hlr.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(), gp_Dir(*view_normal_dir), gp_Dir(*x_dir))))
        hlr.Update()
        hlr.Hide()
        hlr_shapes = HLRBRep_HLRToShape(hlr)
        visible = []
        hidden = []
        tan = []
        for target, items in (
            (visible, (hlr_shapes.VCompound(), hlr_shapes.OutLineVCompound())),
            (tan, (hlr_shapes.Rg1LineVCompound(),)),
            (hidden, (hlr_shapes.HCompound(), hlr_shapes.OutLineHCompound())),   ):
            for item in items:
                if item.IsNull(): continue
                BRepLib.BuildCurves3d_s(item, eta)
                for edge in Compound(item).Edges():  target.append(edge)
        return visible, hidden, tan
    def _proj_2_view(self, pts, view_name="front"):
        pts = np.array(pts, dtype=float)
        if pts.ndim == 1:  pts = pts.reshape(1, 3)
        matrix = np.array(self.proj_matrix[view_name], dtype=float)
        offset = np.array(self.proj_offset[view_name], dtype=float)
        rotation_matrix = np.array(self.rotation_matrix, dtype=float)
        pts_2d = pts @ rotation_matrix.T @ matrix.T + offset
        return pts_2d
    def _gather_circles(self, entities):
        data = {}
        for e_id in entities:
            item = entities[e_id]
            if item["func"] != "CIRCLE":
                continue
            nums = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", item["items"][-1] if item["items"] else item["text"])]
            axis_id = item["refs"][0] if item["refs"] else None
            axis_item = entities.get(axis_id, {})
            axis_refs = axis_item.get("refs", [])
            org_item = entities.get(axis_refs[0], {}) if len(axis_refs) > 0 else {}
            dir_n_item = entities.get(axis_refs[1], {}) if len(axis_refs) > 1 else {}
            dir_x_item = entities.get(axis_refs[2], {}) if len(axis_refs) > 2 else {}
            org = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", org_item.get("items", [""])[-1] if org_item.get("items") else org_item.get("text", ""))]
            dir_n = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", dir_n_item.get("items", [""])[-1] if dir_n_item.get("items") else dir_n_item.get("text", ""))]
            dir_x = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", dir_x_item.get("items", [""])[-1] if dir_x_item.get("items") else dir_x_item.get("text", ""))]
            data[e_id] = {"id": e_id, "org": org, "dir_n": dir_n, "dir_x": dir_x, "r": nums[0] if nums else None}
        return data
    def _gather_lines(self, entities):
        data = {}
        for e_id in entities:
            item = entities[e_id]
            if item["func"] != "EDGE_CURVE":
                continue
            if len(item["refs"]) < 3:
                continue
            curve_id = item["refs"][2]
            curve_item = entities.get(curve_id, {})
            if curve_item.get("func") != "LINE":
                continue
            pts = []
            for vertex_id in item["refs"][:2]:
                vertex_item = entities.get(vertex_id, {})
                point_id = vertex_item.get("refs", [None])[0] if vertex_item.get("refs") else None
                point_item = entities.get(point_id, {})
                point = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", point_item.get("items", [""])[-1] if point_item.get("items") else point_item.get("text", ""))]
                pts.append(point)
            if len(pts) != 2 or len(pts[0]) != 3 or len(pts[1]) != 3:
                continue
            p1 = np.array(pts[0], dtype=float)
            p2 = np.array(pts[1], dtype=float)
            vec = p2 - p1
            length = float(np.linalg.norm(vec))
            if length <= 1e-12:
                continue
            p_mid = (p1 + p2) / 2
            dir = vec / length
            data[e_id] = {"id": e_id, "p1": p1.tolist(), "p2": p2.tolist(), "p_mid": p_mid.tolist(), "dir": dir.tolist(), "length": length}
        return data
    def _gather_faces(self, entities):
        data = {}
        surface_funcs = ("PLANE", "CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "TOROIDAL_SURFACE", "SPHERICAL_SURFACE", "B_SPLINE_SURFACE_WITH_KNOTS")
        for e_id in entities:
            item = entities[e_id]
            if item["func"] != "ADVANCED_FACE":
                continue
            face_type = None
            org = []
            dir_n = []
            edges = []
            edge_circles = []
            edge_lines = []
            same_sense = str(item["items"][-1]).upper() if item.get("items") else None
            for ref in item["refs"]:
                ref_item = entities.get(ref, {})
                if ref_item.get("func") in surface_funcs:
                    face_type = ref_item.get("func")
                    axis_item = {}
                    for axis_id in ref_item.get("refs", []):
                        this_axis_item = entities.get(axis_id, {})
                        if this_axis_item.get("func") in ("AXIS2_PLACEMENT_3D", "AXIS1_PLACEMENT"):
                            axis_item = this_axis_item
                            break
                    axis_refs = axis_item.get("refs", [])
                    org_item = entities.get(axis_refs[0], {}) if len(axis_refs) > 0 else {}
                    dir_n_item = entities.get(axis_refs[1], {}) if len(axis_refs) > 1 else {}
                    org = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", org_item.get("items", [""])[-1] if org_item.get("items") else org_item.get("text", ""))]
                    dir_n = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", dir_n_item.get("items", [""])[-1] if dir_n_item.get("items") else dir_n_item.get("text", ""))]
                    continue
                if ref_item.get("func") not in ("FACE_OUTER_BOUND", "FACE_BOUND"):
                    continue
                for loop_id in ref_item.get("refs", []):
                    loop_item = entities.get(loop_id, {})
                    if loop_item.get("func") != "EDGE_LOOP":
                        continue
                    for oriented_id in loop_item.get("refs", []):
                        oriented_item = entities.get(oriented_id, {})
                        if oriented_item.get("func") != "ORIENTED_EDGE":
                            continue
                        for edge_id in oriented_item.get("refs", []):
                            if entities.get(edge_id, {}).get("func") == "EDGE_CURVE" and edge_id not in edges:
                                edges.append(edge_id)
                                edge_item = entities.get(edge_id, {})
                                curve_id = None
                                for ref in edge_item.get("refs", []):
                                    ref_func = entities.get(ref, {}).get("func")
                                    if ref_func not in ("VERTEX_POINT", ""):
                                        curve_id = ref
                                        break
                                curve_item = entities.get(curve_id, {}) if curve_id is not None else {}
                                circle_id = None
                                if curve_item.get("func") == "CIRCLE":
                                    circle_id = curve_id
                                elif curve_item.get("func") == "SURFACE_CURVE":
                                    for ref in curve_item.get("refs", []):
                                        if entities.get(ref, {}).get("func") == "CIRCLE":
                                            circle_id = ref
                                            break
                                if circle_id is not None and circle_id not in edge_circles:
                                    edge_circles.append(circle_id)
                                elif curve_item.get("func") in ("LINE", "SEAM_CURVE") or curve_item.get("func") == "SURFACE_CURVE" and any(entities.get(ref, {}).get("func") == "LINE" for ref in curve_item.get("refs", [])):
                                    edge_lines.append(edge_id)
            if len(dir_n) == 3:
                dir_n_val = np.array(dir_n, dtype=float)
                dir_n_len = float(np.linalg.norm(dir_n_val))
                if dir_n_len > 1e-12:
                    dir_n_val = dir_n_val / dir_n_len
                    if same_sense == ".F.":
                        dir_n_val = -dir_n_val
                    dir_n = dir_n_val.tolist()
            if face_type == "CYLINDRICAL_SURFACE":
                seam_edges = []
                body = None
                if same_sense == ".T.":
                    body = "inside"
                elif same_sense == ".F.":
                    body = "outside"
                for edge_id in edges:
                    edge_item = entities.get(edge_id, {})
                    curve_id = None
                    for ref in edge_item.get("refs", []):
                        ref_func = entities.get(ref, {}).get("func")
                        if ref_func not in ("VERTEX_POINT", ""):
                            curve_id = ref
                            break
                    curve_item = entities.get(curve_id, {}) if curve_id is not None else {}
                    if curve_item.get("func") in ("SEAM_CURVE", "LINE"):
                        seam_edges.append(edge_id)
                data[e_id] = {"type": face_type, "org": org, "dir_n": dir_n, "body": body, "edges": edge_circles, "edge_circles": edge_circles, "edge_lines": edge_lines, "raw_edges": edges, "seam_edges": seam_edges}
                continue
            data[e_id] = {"type": face_type, "org": org, "dir_n": dir_n, "edges": edges, "edge_circles": edge_circles, "edge_lines": edge_lines}
        return data
    ### ------------- API ------------------
    
    def rotate(self, x=None, y=None, z=None):
        if x is None and y is None and z is None:
            return {"rotate_info": self.rotate_info.copy(), "rotation_matrix": self.rotation_matrix.copy(), "view_map_after_rotate": self.view_map_after_rotate.copy()}
        for key, val in {"x": x, "y": y, "z": z}.items():
            if val is None:
                continue
            turns = int(val)
            self.rotate_info[key] = self.rotate_info.get(key, 0) + turns
        rx = math.radians((self.rotate_info["x"] % 4) * 90)
        ry = math.radians((self.rotate_info["y"] % 4) * 90)
        rz = math.radians((self.rotate_info["z"] % 4) * 90)
        mx = np.array([[1, 0, 0], [0, math.cos(rx), -math.sin(rx)], [0, math.sin(rx), math.cos(rx)]], dtype=float)
        my = np.array([[math.cos(ry), 0, math.sin(ry)], [0, 1, 0], [-math.sin(ry), 0, math.cos(ry)]], dtype=float)
        mz = np.array([[math.cos(rz), -math.sin(rz), 0], [math.sin(rz), math.cos(rz), 0], [0, 0, 1]], dtype=float)
        self.rotation_matrix = mz @ my @ mx
        view_names = ("front", "right", "top", "back", "left", "bottom")
        view_dir = {name: np.array(VIEW_DIRECTION[name]["N"], dtype=float) for name in view_names}
        self.view_map_after_rotate = {}
        for target_name in view_names:
            source_n = self.rotation_matrix.T @ view_dir[target_name]
            source_name = max(view_names, key=lambda name: float(np.dot(source_n, view_dir[name])))
            self.view_map_after_rotate[target_name] = source_name
        return {"rotate_info": self.rotate_info.copy(), "rotation_matrix": self.rotation_matrix.copy(), "view_map_after_rotate": self.view_map_after_rotate.copy()}
    def set_hidden(self, kw):
        for target_name, val in kw.items():
            self.hidden_view_after_rotate[target_name] = bool(val)
        return self.hidden_view_after_rotate.copy()
    def get_views(self, show_hidden=True):
        self._init_dxf_document()
        shape = self.model.val()
        view_order = ["iso_front", "top", "iso_back", "left", "front", "right", "back", "bottom"]
        layout = {
            "iso_front": (0, 2),
            "top": (1, 2),
            "iso_back": (2, 2),
            "left": (0, 1),
            "front": (1, 1),
            "right": (2, 1),
            "back": (3, 1),
            "bottom": (1, 0),
        }
        source_items = {}
        rotation_matrix = np.array(self.rotation_matrix, dtype=float)
        for target_name in view_order:
            target_dir = VIEW_DIRECTION[target_name]
            target_n = np.array(target_dir["N"], dtype=float)
            target_u = np.array(target_dir["U"], dtype=float)
            is_iso = target_name.startswith("iso")
            if is_iso:
                source_n = target_n
                source_u = target_u
            else:
                source_n = rotation_matrix.T @ target_n
                source_u = rotation_matrix.T @ target_u
            source_n = source_n / np.linalg.norm(source_n)
            source_u = source_u / np.linalg.norm(source_u)
            source_r = np.cross(source_u, source_n)
            source_r = source_r / np.linalg.norm(source_r)
            visible, hidden, tan = self._cal_proj_hlr(shape, tuple(source_n.tolist()), tuple(source_r.tolist()))
            this_show_hidden = False if is_iso else bool(self.hidden_view_after_rotate.get(target_name, show_hidden))
            all_items = visible + tan + (hidden if this_show_hidden else [])
            if not all_items:
                raise ValueError(f"{target_name} view no projection edge")
            bb = Compound.makeCompound(all_items).BoundingBox()
            source_items[target_name] = {
                "visible": visible,
                "hidden": hidden,
                "tan": tan,
                "bb": bb,
                "width": bb.xlen,
                "height": bb.ylen,
                "show_hidden": this_show_hidden,
            }
        target_items = {}
        for target_name in view_order:
            item = source_items[target_name]
            bb = item["bb"]
            target_items[target_name] = {
                "xmin": float(bb.xmin),
                "xmax": float(bb.xmax),
                "ymin": float(bb.ymin),
                "ymax": float(bb.ymax),
                "width": float(item["width"]),
                "height": float(item["height"]),
            }
        col_w = [0.0, 0.0, 0.0, 0.0]
        row_h = [0.0, 0.0, 0.0]
        for name, item in target_items.items():
            c, r = layout[name]
            col_w[c] = max(col_w[c], item["width"])
            row_h[r] = max(row_h[r], item["height"])
        spacing = float(getattr(self, "view_spacing", 80))
        col_x = [0.0]
        for w in col_w[:-1]:   col_x.append(col_x[-1] + w + spacing)
        row_y = [0.0]
        for h in row_h[:-1]:    row_y.append(row_y[-1] + h + spacing)
        self.proj_matrix = {}
        self.proj_offset = {}
        view_data = {}
        for target_name in view_order:
            is_iso = target_name.startswith("iso")
            item = target_items[target_name]
            c, r = layout[target_name]
            dx = col_x[c] + (col_w[c] - item["width"]) / 2 - item["xmin"]
            dy = row_y[r] + (row_h[r] - item["height"]) / 2 - item["ymin"]
            source_cache = source_items[target_name]
            msp = self.doc.modelspace()
            for group_name, layer in (("visible", "0"), ("hidden", "HID"), ("tan", "TAN")):
                if group_name == "hidden" and not source_cache["show_hidden"]:
                    continue
                for edge_i, edge in enumerate(source_cache[group_name]):
                    before_i = len(msp)
                    move_edge = edge.translate((dx, dy, 0))
                    wp = cq.Workplane("XY").newObject([move_edge])
                    self.dxf_doc.add_shape(wp, layer)
            target_dir = VIEW_DIRECTION[target_name]
            target_u = np.array(target_dir["U"], dtype=float)
            target_n = np.array(target_dir["N"], dtype=float)
            target_r = np.cross(target_u, target_n)
            target_r = target_r / np.linalg.norm(target_r)
            target_u = target_u / np.linalg.norm(target_u)
            self.proj_matrix[target_name] = np.array([target_r, target_u], dtype=float)
            self.proj_offset[target_name] = np.array([dx, dy], dtype=float)
            view_data[target_name] = {
                "dx": dx,
                "dy": dy,
                "xmin": item["xmin"] + dx,
                "xmax": item["xmax"] + dx,
                "ymin": item["ymin"] + dy,
                "ymax": item["ymax"] + dy,
                "bb": source_cache["bb"],
                "width": item["width"],
                "height": item["height"],
                "label": target_dir["label"],
                "N": target_dir["N"],
                "U": target_dir["U"],
                "R": tuple(target_r.tolist()),
                "is_iso": is_iso,
            }
        self.hlr_view_cache = source_items
        self.view_data = view_data
        return self.doc
    def get_dxf(self,):
        return self.doc
    def add_dxf(self, dxf=None, offset=[0, 0]):
        if self.doc is None:
            self._init_dxf_document()
        if dxf is None:
            return 0
        if isinstance(dxf, Cad_Helper):
            dxf = dxf.get_dxf()
        if hasattr(dxf, "document"):
            dxf = dxf.document
        dx = float(offset[0])
        dy = float(offset[1])
        count = 0
        msp = self.doc.modelspace()
        for ent in list(dxf.modelspace()):
            try:
                new_ent = ent.copy()
                if dx or dy:
                    new_ent.translate(dx, dy, 0)
                msp.add_entity(new_ent)
                count += 1
            except:
                pass
        return count
    def add_qleader(self, xy, txy, word1, word2, h, layer):
        if self.doc is None:
            self._init_dxf_document()
        layer_item = dxf_layer_items.get(layer, dxf_layer_items["DIM"])
        if layer not in self.doc.layers:
            self.doc.layers.add(name=layer, color=layer_item["color"], linetype=layer_item.get("linetype", "CONTINUOUS"))
            self.doc.layers.get(layer).dxf.lineweight = layer_item.get("lineweight", 18)
        x, y = float(xy[0]), float(xy[1])
        tx, ty = float(txy[0]), float(txy[1])
        h = float(h)
        word1 = "" if word1 is None else str(word1)
        word2 = "" if word2 is None else str(word2)
        lines = [word1] if word2 == "" else [word1, word2]
        words = "\n".join(lines)
        line_len = max(h * 4, max(len(item) for item in lines) * h + h * 2)
        msp = self.doc.modelspace()
        builder = msp.add_multileader_mtext(dxfattribs={"layer": layer})
        builder.set_content(words, char_height=h, alignment=TextAlignment.center)
        builder.context.mtext.width = line_len
        builder.set_leader_properties(color=dxf_color_map["依圖層"], linetype="BYLAYER", lineweight=layer_item.get("lineweight", 18))
        builder.set_connection_properties(landing_gap=0, dogleg_length=0)
        connection_type = HorizontalConnection.bottom_of_bottom_line if word2 == "" else HorizontalConnection.bottom_of_top_line
        builder.set_connection_types(left=connection_type, right=connection_type)
        box = builder._build_connection_box()
        insert = Vec2(tx, ty) - Vec2((box.left.x + box.right.x) / 2, box.left.y)
        left_pt = insert + box.left
        right_pt = insert + box.right
        if x <= tx:
            builder.add_leader_line(ConnectionSide.right, [Vec2(x, y), left_pt])
        else:
            builder.add_leader_line(ConnectionSide.left, [Vec2(x, y), right_pt])
        builder.build(insert)
        return builder.multileader
    def auto_dim_holes(self, h=3, offset=12, layer="DIM"):
        if self.view_data is None:
            self.get_views(show_hidden=True)
        if not self.info.get("faces"):
            self.gather_info()
        hole_sequence = self.gather_hole_sequence()
        faces = self.info.get("faces", {})
        circles = self.info.get("circles", {})
        ret = []
        view_stack = {}
        radius_tol = 1e-3
        thread_tol = 0.08
        for gp_id in hole_sequence:
            gp = hole_sequence[gp_id]
            seq = gp.get("seq", [])
            axis_dir = np.array(gp.get("axis_dir", []), dtype=float)
            axis_len = float(np.linalg.norm(axis_dir))
            if axis_len <= 1e-12:
                ret.append({"id": gp_id, "status": "skipped", "reason": "axis_dir_invalid"})
                continue
            axis_dir = axis_dir / axis_len
            cyl_infos = []
            all_edge_centers = []
            for seq_item in seq:
                if seq_item.get("type") != "圓柱":
                    continue
                face = faces.get(seq_item.get("id"), {})
                if face.get("body") == "inside":
                    cyl_infos = []
                    break
                depth_vals = []
                center_vals = []
                r_vals = []
                for circle_id in face.get("edge_circles", []):
                    circle = circles.get(circle_id, {})
                    org = circle.get("org", [])
                    if len(org) != 3:
                        continue
                    center = np.array(org, dtype=float)
                    depth = float(np.dot(center, axis_dir))
                    depth_vals.append(depth)
                    center_vals.append(center)
                    all_edge_centers.append((depth, center))
                    if circle.get("r") not in (None, ""):
                        r_vals.append(float(circle.get("r")))
                if len(depth_vals) < 2:
                    continue
                r = max(r_vals) if r_vals else seq_item.get("r")
                if r in (None, ""):
                    continue
                cyl_infos.append({"id": seq_item.get("id"), "r": float(r), "d0": min(depth_vals), "d1": max(depth_vals), "center": np.mean(np.array(center_vals, dtype=float), axis=0), "seq": seq_item})
            if not cyl_infos:
                ret.append({"id": gp_id, "status": "skipped", "reason": "no_hole_cylinder"})
                continue
            for seq_item in seq:
                if seq_item.get("type") not in ("導角", "圓角"):
                    continue
                face = faces.get(seq_item.get("id"), {})
                for circle_id in face.get("edge_circles", []):
                    circle = circles.get(circle_id, {})
                    org = circle.get("org", [])
                    if len(org) == 3:
                        center = np.array(org, dtype=float)
                        all_edge_centers.append((float(np.dot(center, axis_dir)), center))
            if not all_edge_centers:
                ret.append({"id": gp_id, "status": "skipped", "reason": "no_opening_center"})
                continue
            opening_depth = min(item[0] for item in all_edge_centers)
            opening_pts = [item[1] for item in all_edge_centers if abs(item[0] - opening_depth) <= 1e-3]
            opening_center = np.mean(np.array(opening_pts, dtype=float), axis=0)
            min_r = min(item["r"] for item in cyl_infos)
            main_cyls = [item for item in cyl_infos if abs(item["r"] - min_r) <= radius_tol]
            deepest_main = max(main_cyls, key=lambda item: item["d1"])
            has_deep_cone = any(item.get("type") == "導角" and item.get("depth", opening_depth) > deepest_main["seq"].get("depth", opening_depth) for item in seq)
            through = not has_deep_cone
            thd_dim = None
            for thd_name, thd_item in THREAD_SIZE_ITEMS.items():
                if abs(min_r * 2 - thd_item["minor_d"]) <= thread_tol:
                    thd_dim = "{}x{:g}".format(thd_name, float(thd_item["pitch"]))
                    break
            drill_dim = None if thd_dim is not None else min_r * 2
            drill_depth = None if through or thd_dim is not None else deepest_main["d1"] - opening_depth
            thd_cyl = deepest_main
            cone_depths = [float(item.get("depth")) for item in seq if item.get("type") == "導角" and item.get("depth") not in (None, "")]
            if thd_dim is not None and cone_depths:
                thd_cyl = max(main_cyls, key=lambda item: min(abs(item["seq"].get("depth", (item["d0"] + item["d1"]) / 2) - cone_depth) for cone_depth in cone_depths))
            thd_depth = None if through or thd_dim is None else thd_cyl["d1"] - thd_cyl["d0"]
            cb_items = [item for item in cyl_infos if item["r"] > min_r + radius_tol]
            cb_dim = None
            cb_depth = None
            if cb_items:
                cb_item = max(cb_items, key=lambda item: item["r"])
                cb_dim = cb_item["r"] * 2
                cb_depth = cb_item["d1"] - opening_depth
            word1, word2 = self._cvt_hole_dim_text(thd_dim=thd_dim, drill_dim=drill_dim, thd_depth=thd_depth, drill_depth=drill_depth, cb_dim=cb_dim, cb_depth=cb_depth)
            if not word1 and not word2:
                ret.append({"id": gp_id, "status": "skipped", "reason": "empty_dim_text"})
                continue
            target_view = None
            target_score = -1
            target_dot = 0
            for view_name, view in self.view_data.items():
                if view.get("is_iso"):
                    continue
                view_n = np.array(view.get("N", []), dtype=float)
                if view_n.shape != (3,):
                    continue
                dot_val = float(np.dot(axis_dir, view_n))
                score = abs(dot_val)
                if score > target_score:
                    target_view = view_name
                    target_score = score
                    target_dot = dot_val
            if target_view is None:
                ret.append({"id": gp_id, "status": "skipped", "reason": "no_target_view"})
                continue
            if target_dot > 0 and word1:
                word1 = "背面" + word1
            xy = self._proj_2_view([opening_center], target_view)[0]
            view = self.view_data[target_view]
            view_cx = (float(view["xmin"]) + float(view["xmax"])) / 2
            stack = view_stack.get(target_view, 0)
            view_stack[target_view] = stack + 1
            sign = 1 if float(xy[0]) <= view_cx else -1
            tx = float(xy[0]) + sign * (offset + stack * h * 4)
            ty = float(xy[1]) + offset * 0.5 + stack * h * 1.5
            entity = self.add_qleader((float(xy[0]), float(xy[1])), (tx, ty), word1, word2, h, layer)
            ret.append({"id": gp_id, "status": "done", "view": target_view, "xy": [float(xy[0]), float(xy[1])], "txy": [tx, ty], "word1": word1, "word2": word2, "entity": entity.dxf.handle if hasattr(entity.dxf, "handle") else None, "thread": thd_dim, "through": through})
        self.dim_info["hole_dims"] = ret
        return ret
    ### ------------- 除錯 ------------------
    def debug_dump_stp_parse_info(self,):
        if not any(self.info.values()):
            self.gather_info()
        cylinder_groups = self.gather_cylinder_groups()
        planes_dim = self.gather_planes_dim()
        hole_sequence = self.gather_hole_sequence()
        txt_data = []
        text = "-"*50
        txt_data.append(text); print(text)
        text = str(self.stp_fpath)
        txt_data.append(text); print(text)
        text = "Circles↓ ↓ "
        txt_data.append(text); print(text)
        for id in self.info["circles"]:
            text = "{} {}".format(id, self.info["circles"][id])
            txt_data.append(text); print(text)
        text = "Lines↓ ↓ "
        txt_data.append(text); print(text)
        for id in self.info["lines"]:
            text = "{} {}".format(id, self.info["lines"][id])
            txt_data.append(text); print(text)
        text = "Faces↓ ↓ "
        txt_data.append(text); print(text)
        for id in self.info["faces"]:
            text = "{} {}".format(id, self.info["faces"][id])
            txt_data.append(text); print(text)
        text = "Cylinder Groups↓ ↓ "
        txt_data.append(text); print(text)
        for item in cylinder_groups:
            text = "{}".format(item)
            txt_data.append(text); print(text)
        text = "Planes Dim↓ ↓ "
        txt_data.append(text); print(text)
        for key in planes_dim:
            text = "{} {}".format(key, planes_dim[key])
            txt_data.append(text); print(text)
        text = "Hole Sequence↓ ↓ "
        txt_data.append(text); print(text)
        for key in hole_sequence:
            text = "{} {}".format(key, hole_sequence[key])
            txt_data.append(text); print(text)
        save_txt(str(self.debug_output_folder / "debug_dump_stp_parse_info.txt"), txt_data)
        return self.info
    def debug_mark_circle_edges(self, mark_r=0.6, layer="SUP"):
        msp = self.doc.modelspace()
        circles = self.info["circles"]
        pts = [item["org"] for item in circles.values() if len(item.get("org", [])) == 3]
        txt_data = []
        if not pts:
            text = "debug_mark_circle_edges no circle org points"
            txt_data.append(text); print(text)
            save_txt(str(self.debug_output_folder / "debug_mark_circle_edges.txt"), txt_data)
            return None
        for view_name, view in self.view_data.items():
            if view.get("is_iso"):
                continue
            pts_2d = self._proj_2_view(pts, view_name)
            for this_pt in pts_2d:
                msp.add_circle((float(this_pt[0]), float(this_pt[1])), float(mark_r), dxfattribs={"layer": layer})
                text = "mark circle view={}, x={}, y={}, r={}, layer={}".format(view_name, float(this_pt[0]), float(this_pt[1]), float(mark_r), layer)
                txt_data.append(text); print(text)
        save_txt(str(self.debug_output_folder / "debug_mark_circle_edges.txt"), txt_data)
        return None
    def debug_dump_dxf_entity_counts(self,):
        if self.doc is None and self.dxf_doc is not None:
            self.doc = self.dxf_doc.document
        type_info = {}
        if self.doc is not None:
            entities = self.doc.modelspace() if hasattr(self.doc, "modelspace") else self.doc
            for ent in entities:
                unique_key = ent.dxftype() if hasattr(ent, "dxftype") else type(ent).__name__
                type_info[unique_key] = type_info.get(unique_key, 0) + 1
        txt_data = []
        text = "-------------"
        txt_data.append(text); print(text)
        for unique_key in sorted(type_info):
            text = "Type : {}, Num : {}".format(unique_key, type_info[unique_key])
            txt_data.append(text); print(text)
        save_txt(str(self.debug_output_folder / "debug_dump_dxf_entity_counts.txt"), txt_data)
        return type_info
    def debug_dump_dxf_entities(self,):
        if self.doc is None and self.dxf_doc is not None:
            self.doc = self.dxf_doc.document
        txt_data = []
        if self.doc is None:
            text = "DXF document is None"
            txt_data.append(text); print(text)
            save_txt(str(self.debug_output_folder / "debug_dump_dxf_entities.txt"), txt_data)
            return []
        msp = self.doc.modelspace()
        ret = []
        for ix, ent in enumerate(msp):
            item = {
                "idx": ix,
                "handle": ent.dxf.handle if hasattr(ent.dxf, "handle") else None,
                "type": ent.dxftype(),
                "layer": ent.dxf.layer if hasattr(ent.dxf, "layer") else None,
            }
            ret.append(item)
            text = "msp[{}] -> handle={}, type={}, layer={}, entity={}".format(item["idx"], item["handle"], item["type"], item["layer"], ent)
            txt_data.append(text); print(text)
        save_txt(str(self.debug_output_folder / "debug_dump_dxf_entities.txt"), txt_data)
        return ret
    

def cvt_dxf_to_img(dxf=None, img_path=None, dpi=180, line_width=1.2, pad_ratio=0.08, flatten_distance=0.2, draw_text=True, alpha=1.0, figsize=(7, 5), lineweight_scale=1.0):
    if dxf is None:
        raise ValueError("cvt_dxf_to_img need dxf")
    src_path = None
    if isinstance(dxf, Cad_Helper):
        src_path = dxf.stp_fpath
        dxf = dxf.get_dxf()
    elif hasattr(dxf, "get_dxf"):
        src_path = getattr(dxf, "stp_fpath", None)
        dxf = dxf.get_dxf()
    elif isinstance(dxf, (str, Path)):
        src_path = Path(dxf)
    if img_path is None:
        if src_path is not None:
            img_path = Path(src_path).with_suffix(".png")
        else:
            raise ValueError("cvt_dxf_to_img need img_path")
    img_path = Path(img_path)
    doc = dxf if hasattr(dxf, "modelspace") else dxf.document if hasattr(dxf, "document") and hasattr(dxf.document, "modelspace") else ezdxf.readfile(str(dxf))
    img_path.parent.mkdir(parents=True, exist_ok=True)
    matplotlib.qsave(doc.modelspace(), str(img_path))
    return str(img_path)
