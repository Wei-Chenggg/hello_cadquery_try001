from pathlib import Path
import re
import math
import numpy as np
import cadquery as cq
from cadquery import importers, Compound
from cadquery.occ_impl.exporters.dxf import DxfDocument
from OCP.BRepLib import BRepLib
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt
from toolbox.common_functions import *

THREAD_SIZE_ITEMS = {
    "M2": {"major_d": 2.0, "minor_d": 1.57, "pitch": 0.4},
    "M2.5": {"major_d": 2.5, "minor_d": 2.01, "pitch": 0.45},
    "M3": {"major_d": 3.0, "minor_d": 2.46, "pitch": 0.5},
    "M3.5": {"major_d": 3.5, "minor_d": 2.85, "pitch": 0.6},
    "M4": {"major_d": 4.0, "minor_d": 3.24, "pitch": 0.7},
    "M5": {"major_d": 5.0, "minor_d": 4.13, "pitch": 0.8},
    "M6": {"major_d": 6.0, "minor_d": 4.92, "pitch": 1.0},
    "M7": {"major_d": 7.0, "minor_d": 5.92, "pitch": 1.0},
    "M8": {"major_d": 8.0, "minor_d": 6.65, "pitch": 1.25},
    "M10": {"major_d": 10.0, "minor_d": 8.38, "pitch": 1.5},
    "M12": {"major_d": 12.0, "minor_d": 10.11, "pitch": 1.75},
    "M14": {"major_d": 14.0, "minor_d": 11.83, "pitch": 2.0},
    "M16": {"major_d": 16.0, "minor_d": 13.83, "pitch": 2.0},
    "M18": {"major_d": 18.0, "minor_d": 15.29, "pitch": 2.5},
}

class STP_Generator:
    FACE_ITEMS = {
        "front": {"selector": ">Z", "axis": "Z", "sign": 1},
        "back": {"selector": "<Z", "axis": "Z", "sign": -1},
        "left": {"selector": "<X", "axis": "X", "sign": -1},
        "right": {"selector": ">X", "axis": "X", "sign": 1},
        "up": {"selector": ">Y", "axis": "Y", "sign": 1},
        "top": {"selector": ">Y", "axis": "Y", "sign": 1},
        "down": {"selector": "<Y", "axis": "Y", "sign": -1},
        "bottom": {"selector": "<Y", "axis": "Y", "sign": -1},
    }
    def __init__(self):
        self.obj = None
        self.rotate_info = {"x": 0, "y": 0, "z": 0}
    def box(self, size):
        x, y, z = [float(v) for v in size]
        self.obj = cq.Workplane("XY").box(x, y, z)
        return self
    def cylinder(self, r, h, axis="Z"):
        radius = float(r)
        height = float(h)
        self.obj = cq.Workplane("XY").circle(radius).extrude(height).translate((0, 0, -height / 2))
        axis = str(axis).upper()
        if axis == "X":
            self.obj = self.obj.rotate((0, 0, 0), (0, 1, 0), 90)
        elif axis == "Y":
            self.obj = self.obj.rotate((0, 0, 0), (1, 0, 0), 90)
        elif axis != "Z":
            raise ValueError(f"unknown cylinder axis: {axis}")
        return self
    def _check_obj(self):
        if self.obj is None:
            raise ValueError("STP_Generator 尚未建立幾何")
    def _face_item(self, face):
        key = str(face).strip().lower()
        if key in self.FACE_ITEMS:
            return self.FACE_ITEMS[key]
        if len(key) == 2 and key[0] in (">", "<") and key[1].upper() in ("X", "Y", "Z"):
            return {"selector": key[0] + key[1].upper(), "axis": key[1].upper(), "sign": 1 if key[0] == ">" else -1}
        raise ValueError(f"unknown face: {face}")
    def _points(self, point):
        if isinstance(point, tuple):
            point = list(point)
        if isinstance(point, list) and len(point) == 2 and not isinstance(point[0], (tuple, list)):
            return [(float(point[0]), float(point[1]))]
        return [(float(p[0]), float(p[1])) for p in point]
    def _solid_depth(self, face_item):
        bb = self.obj.val().BoundingBox()
        return {"X": bb.xlen, "Y": bb.ylen, "Z": bb.zlen}[face_item["axis"]]
    def _face_value(self, face_obj, face_item):
        bb = face_obj.BoundingBox()
        axis = face_item["axis"]
        if axis == "X":
            return bb.xmax if face_item["sign"] > 0 else bb.xmin
        if axis == "Y":
            return bb.ymax if face_item["sign"] > 0 else bb.ymin
        return bb.zmax if face_item["sign"] > 0 else bb.zmin
    def _workplane(self, face_item):
        faces = self.obj.faces(face_item["selector"]).vals()
        if not faces:
            raise ValueError(f"no face selected: {face_item['selector']}")
        face_obj = max(faces, key=lambda item: self._face_value(item, face_item)) if face_item["sign"] > 0 else min(faces, key=lambda item: self._face_value(item, face_item))
        return self.obj.newObject([face_obj]).workplane(centerOption="CenterOfBoundBox")
    def _hole_radius(self, r):
        if isinstance(r, str):
            thread = r.upper()
            if thread not in THREAD_SIZE_ITEMS:
                raise ValueError(f"unknown thread size: {r}")
            return float(THREAD_SIZE_ITEMS[thread]["minor_d"]) / 2, thread
        return float(r), None
    def _cut_hole_cylinder(self, face_item, points, radius, depth, through=False):
        wp = self._workplane(face_item)
        for pt in points:
            tool = wp.pushPoints([pt]).circle(float(radius)).extrude(-float(depth), combine=False)
            self.obj = self.obj.cut(tool, clean=False)
    def _cut_drill_tip(self, face_item, points, radius, depth, tip_angle):
        cone_h = float(radius) / math.tan(math.radians(float(tip_angle) / 2))
        cone_wp = self._workplane(face_item).workplane(offset=-float(depth))
        for pt in points:
            cone_tool = cone_wp.transformed(offset=cq.Vector(pt[0], pt[1], 0)).circle(float(radius)).workplane(offset=-cone_h).circle(0.0001).loft(combine=False)
            self.obj = self.obj.cut(cone_tool, clean=False)
    def _hole_start_edges(self, face_item):
        edges = []
        for face_obj in self.obj.faces(face_item["selector"]).vals():
            for wire in face_obj.innerWires():
                edges += wire.Edges()
        return edges
    def _proc_hole_start(self, face_item, start_chamfer=None, start_round=None):
        edges = self._hole_start_edges(face_item)
        if start_chamfer is not None and edges:
            self.obj = self.obj.newObject(edges).chamfer(float(start_chamfer))
            edges = self._hole_start_edges(face_item)
        if start_round is not None and edges:
            self.obj = self.obj.newObject(edges).fillet(float(start_round))
    def hole(self, face, point, r, depth, drilling=False, tip_angle=120, start_chamfer=None, start_round=None):
        self._check_obj()
        face_item = self._face_item(face)
        points = self._points(point)
        radius, thread = self._hole_radius(r)
        solid_depth = self._solid_depth(face_item)
        if isinstance(depth, str) and depth.upper() in ("ALL", "THROUGH", "THRU"):
            cut_depth = solid_depth
            through = True
        else:
            target_depth = float(depth)
            cut_depth = min(target_depth, solid_depth)
            through = cut_depth >= solid_depth - 0.001
        self._cut_hole_cylinder(face_item, points, radius, cut_depth, through)
        if drilling and not through:
            self._cut_drill_tip(face_item, points, radius, cut_depth, tip_angle)
        self._proc_hole_start(face_item, start_chamfer, start_round)
        return self
    def thread_hole(self, face, point, thread, thread_depth, drill_depth, tip_angle=120, start_chamfer=None, start_round=None):
        self._check_obj()
        face_item = self._face_item(face)
        points = self._points(point)
        radius, thread = self._hole_radius(thread)
        solid_depth = self._solid_depth(face_item)
        thread_depth = min(float(thread_depth), solid_depth)
        drill_depth = min(float(drill_depth), solid_depth)
        if drill_depth < thread_depth:
            drill_depth = thread_depth
        if drill_depth > thread_depth:
            wp = self._workplane(face_item).workplane(offset=-thread_depth)
            for pt in points:
                tool = wp.pushPoints([pt]).circle(radius).extrude(-(drill_depth - thread_depth), combine=False)
                self.obj = self.obj.cut(tool, clean=False)
        self._cut_hole_cylinder(face_item, points, radius, thread_depth, False)
        if drill_depth < solid_depth - 0.001:
            self._cut_drill_tip(face_item, points, radius, drill_depth, tip_angle)
        self._proc_hole_start(face_item, start_chamfer, start_round)
        return self
    def slot(self, face, point, r, c2c, depth):
        self._check_obj()
        face_item = self._face_item(face)
        points = self._points(point)
        radius = float(r)
        if isinstance(depth, str) and depth.upper() in ("ALL", "THROUGH", "THRU"):
            cut_depth = self._solid_depth(face_item)
        else:
            cut_depth = min(float(depth), self._solid_depth(face_item))
        for pt in points:
            if float(c2c) > 0:
                rect_tool = self._workplane(face_item).center(pt[0], pt[1]).rect(float(c2c), radius * 2).extrude(-cut_depth, combine=False)
                self.obj = self.obj.cut(rect_tool, clean=False)
                end_points = [(pt[0] - float(c2c) / 2, pt[1]), (pt[0] + float(c2c) / 2, pt[1])]
            else:
                end_points = [pt]
            circle_tool = self._workplane(face_item).pushPoints(end_points).circle(radius).extrude(-cut_depth, combine=False)
            self.obj = self.obj.cut(circle_tool, clean=False)
        return self
    def extend_rect(self, face, sign, p1, p2, h):
        self._check_obj()
        face_item = self._face_item(face)
        x1, y1 = float(p1[0]), float(p1[1])
        x2, y2 = float(p2[0]), float(p2[1])
        w = abs(x2 - x1)
        hh = abs(y2 - y1)
        cx = (x1 + x2) / 2
        cy = (y1 + y2) / 2
        depth = float(h)
        tool = self._workplane(face_item).center(cx, cy).rect(w, hh).extrude(depth if sign == "+" else -depth, combine=False)
        self.obj = self.obj.union(tool).clean() if sign == "+" else self.obj.cut(tool, clean=False)
        return self
    def extend_circle(self, face, sign, c, h, r=None):
        self._check_obj()
        face_item = self._face_item(face)
        radius = float(h if r is None else r)
        depth = float(h)
        tool = self._workplane(face_item).center(float(c[0]), float(c[1])).circle(radius).extrude(depth if sign == "+" else -depth, combine=False)
        self.obj = self.obj.union(tool).clean() if sign == "+" else self.obj.cut(tool, clean=False)
        return self
    def _face_edges(self, face, corner):
        selector = self._face_item(face)["selector"]
        edges = []
        for face_obj in self.obj.faces(selector).vals():
            if corner in ("out-corner", "outer", "out"):
                edges += face_obj.outerWire().Edges()
            elif corner in ("in-corner", "inner", "in"):
                for wire in face_obj.innerWires():
                    edges += wire.Edges()
            else:
                raise ValueError(f"unknown corner: {corner}")
        return edges
    def chamfer(self, face, corner, val):
        self._check_obj()
        edges = self._face_edges(face, corner)
        if edges:
            self.obj = self.obj.newObject(edges).chamfer(float(val))
        return self
    def round(self, face, corner, val):
        self._check_obj()
        edges = self._face_edges(face, corner)
        if edges:
            self.obj = self.obj.newObject(edges).fillet(float(val))
        return self
    def rotate(self, kw):
        self._check_obj()
        for key, val in kw.items():
            turns = int(val)
            self.rotate_info[key] = self.rotate_info.get(key, 0) + turns
            angle = turns * 90
            if key == "x":
                self.obj = self.obj.rotate((0, 0, 0), (1, 0, 0), angle)
            elif key == "y":
                self.obj = self.obj.rotate((0, 0, 0), (0, 1, 0), angle)
            elif key == "z":
                self.obj = self.obj.rotate((0, 0, 0), (0, 0, 1), angle)
            else:
                raise ValueError(f"unknown rotate axis: {key}")
        return self
    def save(self, path, write_pcurves=False):
        self._check_obj()
        path = Path(path)
        if path.suffix == "":
            path = path.with_suffix(".stp")
        path.parent.mkdir(parents=True, exist_ok=True)
        cq.exporters.export(self.obj, str(path), exportType=cq.exporters.ExportTypes.STEP, opt={"write_pcurves": write_pcurves})
        return str(path)




def split_params(data):
    ret, buf = [], []
    layer, in_text, i = 0, False, 0
    while i < len(data):
        ch = data[i]
        if ch == "'":
            buf.append(ch)
            if i + 1 < len(data) and data[i + 1] == "'":
                buf.append(data[i + 1]); i += 2; continue
            in_text = not in_text
        elif not in_text and ch in "()":
            layer += 1 if ch == "(" else -1
            buf.append(ch)
        elif not in_text and ch == "," and layer == 0:
            ret.append("".join(buf).strip()); buf = []
        else:
            buf.append(ch)
        i += 1
    if buf: ret.append("".join(buf).strip())
    return ret
def parse_stp_entities(stp_path):
    txt_data = Path(stp_path).read_text(encoding="utf-8", errors="ignore")
    entities = {}
    for m in re.finditer(r"#(\d+)\s*=\s*(.*?);", txt_data, re.S):
        id_name = "#" + m.group(1)
        text = " ".join(m.group(2).split())
        f = re.match(r"([A-Z0-9_]+)\s*\((.*)\)$", text)
        func, items = (f.group(1), split_params(f.group(2))) if f else ("", [])
        entities[id_name] = {"id": id_name, "idx": int(m.group(1)), "func": func, "items": items, "refs": re.findall(r"#\d+", text), "text": text}
    return entities
def gather_circles(entities):
    data = {}
    for e_id in entities:
        item = entities[e_id]
        if item["func"] != "CIRCLE":
            continue
        nums = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", item["items"][-1] if item["items"] else item["text"])]
        axis_id = item["refs"][0] if item["refs"] else None
        axis_item = entities.get(axis_id, {})
        axis_refs = axis_item.get("refs", [])
        org_item = entities.get(axis_refs[0], {}) if len(axis_refs) > 0 else {}
        dir_n_item = entities.get(axis_refs[1], {}) if len(axis_refs) > 1 else {}
        dir_x_item = entities.get(axis_refs[2], {}) if len(axis_refs) > 2 else {}
        org = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", org_item.get("items", [""])[-1] if org_item.get("items") else org_item.get("text", ""))]
        dir_n = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", dir_n_item.get("items", [""])[-1] if dir_n_item.get("items") else dir_n_item.get("text", ""))]
        dir_x = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", dir_x_item.get("items", [""])[-1] if dir_x_item.get("items") else dir_x_item.get("text", ""))]
        data[e_id] = {"id": e_id, "org": org, "dir_n": dir_n, "dir_x": dir_x, "r": nums[0] if nums else None}
    return data
def gather_lines(entities):
    data = {}
    for e_id in entities:
        item = entities[e_id]
        if item["func"] != "LINE":
            continue
        org_item = entities.get(item["refs"][0], {}) if len(item["refs"]) > 0 else {}
        vec_item = entities.get(item["refs"][1], {}) if len(item["refs"]) > 1 else {}
        dir_x_item = entities.get(vec_item.get("refs", [""])[0], {}) if vec_item.get("refs") else {}
        org = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", org_item.get("items", [""])[-1] if org_item.get("items") else org_item.get("text", ""))]
        dir_x = [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", dir_x_item.get("items", [""])[-1] if dir_x_item.get("items") else dir_x_item.get("text", ""))]
        data[e_id] = {"id": e_id, "org": org, "dir_x": dir_x, "vector": item["refs"][1] if len(item["refs"]) > 1 else None}
    return data
def gather_faces(entities):
    data = {}
    surface_funcs = ("PLANE", "CYLINDRICAL_SURFACE", "CONICAL_SURFACE", "TOROIDAL_SURFACE", "SPHERICAL_SURFACE", "B_SPLINE_SURFACE_WITH_KNOTS")
    for e_id in entities:
        item = entities[e_id]
        if item["func"] != "ADVANCED_FACE":
            continue
        face_type = None
        edges = []
        for ref in item["refs"]:
            ref_item = entities.get(ref, {})
            if ref_item.get("func") in surface_funcs:
                face_type = ref_item.get("func")
                continue
            if ref_item.get("func") not in ("FACE_OUTER_BOUND", "FACE_BOUND"):
                continue
            for loop_id in ref_item.get("refs", []):
                loop_item = entities.get(loop_id, {})
                if loop_item.get("func") != "EDGE_LOOP":
                    continue
                for oriented_id in loop_item.get("refs", []):
                    oriented_item = entities.get(oriented_id, {})
                    if oriented_item.get("func") != "ORIENTED_EDGE":
                        continue
                    for edge_id in oriented_item.get("refs", []):
                        if entities.get(edge_id, {}).get("func") == "EDGE_CURVE" and edge_id not in edges:
                            edges.append(edge_id)
        if face_type == "CYLINDRICAL_SURFACE":
            circle_edges = []
            seam_edges = []
            for edge_id in edges:
                edge_item = entities.get(edge_id, {})
                curve_id = None
                for ref in edge_item.get("refs", []):
                    ref_func = entities.get(ref, {}).get("func")
                    if ref_func not in ("VERTEX_POINT", ""):
                        curve_id = ref
                        break
                curve_item = entities.get(curve_id, {}) if curve_id is not None else {}
                if curve_item.get("func") in ("SEAM_CURVE", "LINE"):
                    seam_edges.append(edge_id)
                elif curve_item.get("func") == "CIRCLE" or curve_item.get("func") == "SURFACE_CURVE" and any(entities.get(ref, {}).get("func") == "CIRCLE" for ref in curve_item.get("refs", [])):
                    circle_edges.append(edge_id)
            data[e_id] = {"type": face_type, "edges": circle_edges, "raw_edges": edges, "seam_edges": seam_edges}
            continue
        data[e_id] = {"type": face_type, "edges": edges}
    return data
def build_step_report(fname, entities):
    lines = []
    lines.append("=" * 80)
    lines.append(f"FILE {fname}")
    circles = gather_circles(entities)
    faces = gather_faces(entities)
    lines.append(f"CIRCLE_COUNT {len(circles)}")
    lines.append(f"FACE_COUNT {len(faces)}")
    for face_id, face in faces.items():
        if face["type"] != "CYLINDRICAL_SURFACE":
            continue
        face_item = entities.get(face_id, {})
        lines.append("-" * 80)
        raw_edges = face.get("raw_edges", face["edges"])
        lines.append(f"CYL_FACE {face_id} edge_count={len(face['edges'])} edges={face['edges']} raw_edge_count={len(raw_edges)} raw_edges={raw_edges} seam_edges={face.get('seam_edges', [])}")
        lines.append(f"FACE_TEXT {face_item.get('text', '')}")
        for edge_id in raw_edges:
            edge_item = entities.get(edge_id, {})
            curve_id = None
            for ref in edge_item.get("refs", []):
                ref_func = entities.get(ref, {}).get("func")
                if ref_func not in ("VERTEX_POINT", ""):
                    curve_id = ref
                    break
            curve_item = entities.get(curve_id, {}) if curve_id is not None else {}
            lines.append(f"EDGE {edge_id} func={edge_item.get('func')} refs={edge_item.get('refs', [])}")
            lines.append(f"EDGE_TEXT {edge_item.get('text', '')}")
            lines.append(f"CURVE {curve_id} func={curve_item.get('func')} refs={curve_item.get('refs', [])}")
            lines.append(f"CURVE_TEXT {curve_item.get('text', '')}")
            if curve_item.get("func") in ("SURFACE_CURVE", "SEAM_CURVE"):
                for ref in curve_item.get("refs", []):
                    ref_item = entities.get(ref, {})
                    lines.append(f"CURVE_REF {ref} func={ref_item.get('func')} text={ref_item.get('text', '')}")
    return lines



this_workflow_stp_folder = "./stp_0619"
def gen_test_parts():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth="ALL", drilling=False)
    hpr.save(Path(this_workflow_stp_folder) / "part1.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth=5, drilling=True)
    hpr.save(Path(this_workflow_stp_folder) / "part2.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth=5, drilling=True, start_chamfer=2)
    hpr.save(Path(this_workflow_stp_folder) / "part3.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth=5, drilling=True, start_round=2)
    hpr.save(Path(this_workflow_stp_folder) / "part4.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth=5, drilling=True)
    cut_tool = cq.Workplane("XY").polyline([(4, 10), (10, 10), (10, 4)]).close().extrude(12).translate((0, 0, -6))
    hpr.obj = hpr.obj.cut(cut_tool, clean=False)
    hpr.save(Path(this_workflow_stp_folder) / "part6.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth=5, drilling=True)
    hpr.obj = hpr.obj.edges("|Z").chamfer(3)
    hpr.save(Path(this_workflow_stp_folder) / "part7.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth=5, drilling=True)
    hpr.obj = hpr.obj.edges("|Z").fillet(3)
    hpr.obj = hpr.obj.faces(">Y").edges().fillet(3)
    hpr.save(Path(this_workflow_stp_folder) / "part8.stp")
    pts = [[-15, -15], [15, -15], [-15, 15], [15, 15]]
    hpr = STP_Generator()
    hpr.box([60, 60, 20])
    hpr.hole("front", pts, r=6, depth=2, drilling=False)
    hpr.thread_hole("front", pts, thread="M3", thread_depth=6, drill_depth=7)
    hpr.save(Path(this_workflow_stp_folder) / "part9.stp")
    hpr = STP_Generator()
    hpr.box([60, 60, 20])
    hpr.hole("back", pts, r=6, depth=2, drilling=False)
    hpr.thread_hole("back", pts, thread="M3", thread_depth=6, drill_depth=7)
    hpr.save(Path(this_workflow_stp_folder) / "part10.stp")
    hpr = STP_Generator()
    hpr.box([60, 60, 20])
    hpr.hole("front", pts, r=6, depth=2, drilling=False)
    hpr.thread_hole("front", pts, thread="M3", thread_depth=6, drill_depth=7)
    hpr.thread_hole("left", [0, 0], thread="M4", thread_depth=6, drill_depth=9)
    hpr.hole("left", [10, 0], r=3, depth=6, drilling=False)
    hpr.save(Path(this_workflow_stp_folder) / "part11.stp")
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=3, depth="ALL", drilling=False)
    hpr.slot("front", [0, 6], r=2, c2c=8, depth="ALL")
    hpr.save(Path(this_workflow_stp_folder) / "part12.stp")

def main():
    gen_test_parts()


if __name__ == "__main__":
    main()
