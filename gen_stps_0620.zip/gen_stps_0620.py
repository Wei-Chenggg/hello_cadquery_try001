from pathlib import Path
from gen_stps import STP_Generator, parse_stp_entities, gather_circles, gather_lines, gather_faces, build_step_report
from toolbox.common_functions import *

this_workflow_stp_folder = "./stp_0620"

def gen_test_parts():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.thread_hole("front", [0, 0], thread="M4", thread_depth=6, drill_depth=8, start_chamfer=2)
    round_edges = []
    for edge in hpr.obj.edges("|Z").vals():
        x, y, z = edge.Center().toTuple()
        if abs(x + 10) <= 0.001 and abs(y - 10) <= 0.001:
            round_edges.append(edge)
    if round_edges:
        hpr.obj = hpr.obj.newObject(round_edges).fillet(4)
    chamfer_edges = []
    for edge in hpr.obj.edges("|Z").vals():
        x, y, z = edge.Center().toTuple()
        for tx, ty in ((10, 10), (10, -10), (-10, -10)):
            if abs(x - tx) <= 0.001 and abs(y - ty) <= 0.001:
                chamfer_edges.append(edge)
    if chamfer_edges:
        hpr.obj = hpr.obj.newObject(chamfer_edges).chamfer(3)
    hpr.save(Path(this_workflow_stp_folder) / "part1.stp")
    pts = [[-15, -15], [15, -15], [-15, 15], [15, 15]]
    side_pts = [[-15, 0], [15, 0]]
    hpr = STP_Generator()
    hpr.box([60, 60, 10])
    hpr.thread_hole("front", pts, thread="M3", thread_depth=6, drill_depth=7)
    hpr.thread_hole("left", side_pts, thread="M3", thread_depth=6, drill_depth=7)
    hpr.hole("right", side_pts, r=3, depth=2, drilling=False)
    hpr.thread_hole("right", side_pts, thread="M3", thread_depth=6, drill_depth=7)
    hpr.obj = hpr.obj.edges("|X").chamfer(1)
    hpr.save(Path(this_workflow_stp_folder) / "part2.stp")
    hpr = STP_Generator()
    hpr.box([60, 60, 14])
    hpr.round("top", "out-corner", 3)
    hpr.round("bottom", "out-corner", 3)
    pts = [[-20, -20], [10, -20], [-20, 20], [10, 20], [20, 20]]
    hpr.thread_hole("front", pts, thread="M3", thread_depth=3, drill_depth=5)
    pts = [[5, 5], [5, -5]]
    hpr.hole("front", pts, r="M4", depth="ALL", drilling=False)
    hpr.save(Path(this_workflow_stp_folder) / "part3.stp")
    hpr = STP_Generator()
    hpr.box([60, 60, 10])
    hpr.extend_circle("front", "+", [0, 0], 6, r=25)
    pts = [[-10, -10], [10, -10], [-10, 10], [10, 10]]
    hpr.hole("front", pts, r=3, depth=2, drilling=False)
    hpr.thread_hole("front", pts, thread="M2", thread_depth=6, drill_depth=8)
    hpr.hole("front", [0, 0], r=4, depth=4, drilling=False)
    hpr.thread_hole("front", [0, 0], thread="M4", thread_depth=9, drill_depth=11)
    ring_tool = hpr._workplane(hpr._face_item("back")).circle(29).circle(26).extrude(-5, combine=False)
    hpr.obj = hpr.obj.cut(ring_tool, clean=False)
    hpr.save(Path(this_workflow_stp_folder) / "part4.stp")
    hpr = STP_Generator()
    hpr.box([140, 30, 20])
    
    hpr.hole("front", [-60, 0], r=5, depth=6, drilling=False)
    hpr.hole("front", [-45, 0], r=5, depth=6, drilling=True)
    hpr.hole("front", [-30, 0], r=5, depth=6, drilling=False)
    hpr.hole("front", [-10, 0], r=5, depth=6, drilling=False)
    hpr.hole("front", [10, 0], r=5, depth=20, drilling=False)
    hpr.hole("front", [30, 0], r=5, depth=20, drilling=False)
    hpr.hole("front", [50, 0], r=6, depth=4, drilling=False)
    hpr.hole("front", [50, 0], r=5, depth=20, drilling=False)
    for val, edge_pts in ((2, [[-30, 0]]), (3, [[30, 0], [50, 0]])):
        for tx, ty in edge_pts:
            round_edges = []
            for edge in hpr.obj.faces(">Z").edges().vals():
                x, y, z = edge.Center().toTuple()
                if abs(x - tx) <= 0.001 and abs(y - ty) <= 0.001:
                    round_edges.append(edge)
            if round_edges:
                hpr.obj = hpr.obj.newObject(round_edges).fillet(val)
    for val, edge_pts in ((2, [[-10, 0]]), (3, [[10, 0]])):
        for tx, ty in edge_pts:
            chamfer_edges = []
            for edge in hpr.obj.faces(">Z").edges().vals():
                x, y, z = edge.Center().toTuple()
                if abs(x - tx) <= 0.001 and abs(y - ty) <= 0.001:
                    chamfer_edges.append(edge)
            if chamfer_edges:
                hpr.obj = hpr.obj.newObject(chamfer_edges).chamfer(val)
    hpr.save(Path(this_workflow_stp_folder) / "part5.stp")
    hpr = STP_Generator()
    hpr.box([140, 30, 20])
    m8_r = hpr._hole_radius("M8")[0]
    hpr.hole("front", [-60, 0], r="M8", depth=6, drilling=False)
    hpr.hole("front", [-45, 0], r="M8", depth=6, drilling=False)
    hpr.hole("front", [-30, 0], r="M8", depth=6, drilling=False)
    hpr.hole("front", [-10, 0], r="M8", depth=6, drilling=False)
    hpr.hole("front", [10, 0], r="M8", depth=20, drilling=False)
    hpr.hole("front", [30, 0], r="M8", depth=20, drilling=False)
    hpr.hole("front", [50, 0], r=6, depth=4, drilling=False)
    hpr.hole("front", [50, 0], r="M8", depth=20, drilling=False)
    for val, edge_pts in ((2, [[-30, 0]]), (3, [[30, 0], [50, 0]])):
        for tx, ty in edge_pts:
            round_edges = []
            for edge in hpr.obj.faces(">Z").edges().vals():
                x, y, z = edge.Center().toTuple()
                if abs(x - tx) <= 0.001 and abs(y - ty) <= 0.001:
                    round_edges.append(edge)
            if round_edges:
                hpr.obj = hpr.obj.newObject(round_edges).fillet(val)
    for val, edge_pts in ((2, [[-10, 0]]), (3, [[10, 0]])):
        for tx, ty in edge_pts:
            chamfer_edges = []
            for edge in hpr.obj.faces(">Z").edges().vals():
                x, y, z = edge.Center().toTuple()
                if abs(x - tx) <= 0.001 and abs(y - ty) <= 0.001:
                    chamfer_edges.append(edge)
            if chamfer_edges:
                hpr.obj = hpr.obj.newObject(chamfer_edges).chamfer(val)
    wp = hpr._workplane(hpr._face_item("front")).workplane(offset=-6)
    for pt in [[-60, 0], [-45, 0], [-30, 0], [-10, 0]]:
        tool = wp.pushPoints([pt]).circle(m8_r).extrude(-2, combine=False)
        hpr.obj = hpr.obj.cut(tool, clean=False)
    hpr._cut_drill_tip(hpr._face_item("front"), [[-45, 0]], m8_r, 8, 120)
    hpr.save(Path(this_workflow_stp_folder) / "part6.stp")

def main():
    gen_test_parts()
    fnames, fpaths = get_files(this_workflow_stp_folder, ["stp"])
    report_lines = []
    for i, fpath in enumerate(fpaths):
        fname = fnames[i]
        entities = parse_stp_entities(fpath)
        report_lines += build_step_report(fname, entities)
        data = gather_circles(entities)
        print(fname)
        for id in data:
            print(id, data[id])
        data = gather_lines(entities)
        for id in data:
            print(id, data[id])
        data = gather_faces(entities)
        for id in data:
            print(id, data[id])
    save_txt(str(Path(this_workflow_stp_folder) / "step_parse_report"), report_lines)
    print(str(Path(this_workflow_stp_folder) / "step_parse_report.txt"))

if __name__ == "__main__":
    main()
