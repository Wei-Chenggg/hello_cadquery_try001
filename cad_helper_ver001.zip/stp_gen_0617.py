from pathlib import Path
import sys
import types

THREAD_SIZE_ITEMS = {
    "M2": {"major_d": 2.0, "minor_d": 1.57, "pitch": 0.4},
    "M3": {"major_d": 3.0, "minor_d": 2.46, "pitch": 0.5},
    "M4": {"major_d": 4.0, "minor_d": 3.24, "pitch": 0.7},
}
cad_helper_mod = types.ModuleType("cad_helper")
cad_helper_mod.THREAD_SIZE_ITEMS = THREAD_SIZE_ITEMS
sys.modules.setdefault("cad_helper", cad_helper_mod)
from stp_generator import STP_Generator

SAVE_FOLDER = Path("./stp_files_basic_hole")
def gen_func01():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r="M3", depth="ALL", drilling=True)
    return hpr
def gen_func02():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=1.5, depth="ALL", drilling=False)
    return hpr
def gen_func03():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r="M3", depth=5, drilling=True)
    return hpr
def gen_func04():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r="M3", depth=6, drilling=True)
    hpr.hole("front", [0, 0], r=3, depth=2, drilling=False)
    return hpr
def gen_func05():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r=1.5, depth=6, drilling=False)
    hpr.hole("front", [0, 0], r=3, depth=2, drilling=False)
    return hpr
def gen_func06():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 0], r="M3", depth="ALL", drilling=True)
    hpr.hole("front", [0, 0], r=3, depth=2, drilling=False)
    return hpr
def gen_func07():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("right", [0, 0], r="M4", depth="ALL", drilling=True)
    return hpr
def gen_func08():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("back", [0, 0], r="M3", depth="ALL", drilling=True)
    hpr.hole("back", [0, 0], r=3, depth=2, drilling=False)
    return hpr
def gen_func09():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("down", [6, 0], r="M2", depth=8, drilling=True)
    hpr.hole("down", [6, 0], r=6, depth=2, drilling=False)
    return hpr
def gen_func10():
    hpr = STP_Generator()
    hpr.box([20, 20, 10])
    hpr.hole("front", [0, 8], r="M2", depth=9, drilling=True)
    hpr.hole("front", [0, 8], r=6, depth=2, drilling=False)
    return hpr

GEN_ITEMS = [
    ("part1", gen_func01),
    ("part2", gen_func02),
    ("part3", gen_func03),
    ("part4", gen_func04),
    ("part5", gen_func05),
    ("part6", gen_func06),
    ("part7", gen_func07),
    ("part8", gen_func08),
    ("part9", gen_func09),
    ("part10", gen_func10),
]
def save_one(name, gen_func):
    SAVE_FOLDER.mkdir(parents=True, exist_ok=True)
    path = SAVE_FOLDER / f"{name}.stp"
    hpr = gen_func()
    hpr.save(path)
    return str(path)
def main():
    for name, gen_func in GEN_ITEMS:
        path = save_one(name, gen_func)
        print(name, path)
if __name__ == "__main__":
    main()
