from pathlib import Path
import math
import cadquery as cq
THREAD_SIZE_ITEMS = {
    "M2": {"major_d": 2.0, "minor_d": 1.57, "pitch": 0.4},
    "M2.5": {"major_d": 2.5, "minor_d": 2.01, "pitch": 0.45},
    "M3": {"major_d": 3.0, "minor_d": 2.46, "pitch": 0.5},
    "M3.5": {"major_d": 3.5, "minor_d": 2.85, "pitch": 0.6},
    "M4": {"major_d": 4.0, "minor_d": 3.24, "pitch": 0.7},
    "M5": {"major_d": 5.0, "minor_d": 4.13, "pitch": 0.8},
    "M6": {"major_d": 6.0, "minor_d": 4.92, "pitch": 1.0},
    "M7": {"major_d": 7.0, "minor_d": 5.92, "pitch": 1.0},
    "M8": {"major_d": 8.0, "minor_d": 6.65, "pitch": 1.25},
    "M10": {"major_d": 10.0, "minor_d": 8.38, "pitch": 1.5},
    "M12": {"major_d": 12.0, "minor_d": 10.11, "pitch": 1.75},
    "M14": {"major_d": 14.0, "minor_d": 11.83, "pitch": 2.0},
    "M16": {"major_d": 16.0, "minor_d": 13.83, "pitch": 2.0},
    "M18": {"major_d": 18.0, "minor_d": 15.29, "pitch": 2.5},
}

class STP_Generator:
    FACE_ITEMS = {
        "front": {"selector": ">Z", "axis": "Z", "sign": 1},
        "back": {"selector": "<Z", "axis": "Z", "sign": -1},
        "left": {"selector": "<X", "axis": "X", "sign": -1},
        "right": {"selector": ">X", "axis": "X", "sign": 1},
        "up": {"selector": ">Y", "axis": "Y", "sign": 1},
        "top": {"selector": ">Y", "axis": "Y", "sign": 1},
        "down": {"selector": "<Y", "axis": "Y", "sign": -1},
        "bottom": {"selector": "<Y", "axis": "Y", "sign": -1},
    }
    def __init__(self):
        self.obj = None
        self.rotate_info = {"x": 0, "y": 0, "z": 0}
    def box(self, size):
        x, y, z = [float(v) for v in size]
        self.obj = cq.Workplane("XY").box(x, y, z)
        return self
    def cylinder(self, r, h, axis="Z"):
        radius = float(r)
        height = float(h)
        self.obj = cq.Workplane("XY").circle(radius).extrude(height).translate((0, 0, -height / 2))
        axis = str(axis).upper()
        if axis == "X":
            self.obj = self.obj.rotate((0, 0, 0), (0, 1, 0), 90)
        elif axis == "Y":
            self.obj = self.obj.rotate((0, 0, 0), (1, 0, 0), 90)
        elif axis != "Z":
            raise ValueError(f"unknown cylinder axis: {axis}")
        return self
    def _check_obj(self):
        if self.obj is None:
            raise ValueError("STP_Generator 尚未建立幾何")
    def _face_item(self, face):
        key = str(face).strip().lower()
        if key in self.FACE_ITEMS:
            return self.FACE_ITEMS[key]
        if len(key) == 2 and key[0] in (">", "<") and key[1].upper() in ("X", "Y", "Z"):
            return {"selector": key[0] + key[1].upper(), "axis": key[1].upper(), "sign": 1 if key[0] == ">" else -1}
        raise ValueError(f"unknown face: {face}")
    def _points(self, point):
        if isinstance(point, tuple):
            point = list(point)
        if isinstance(point, list) and len(point) == 2 and not isinstance(point[0], (tuple, list)):
            return [(float(point[0]), float(point[1]))]
        return [(float(p[0]), float(p[1])) for p in point]
    def _solid_depth(self, face_item):
        bb = self.obj.val().BoundingBox()
        return {"X": bb.xlen, "Y": bb.ylen, "Z": bb.zlen}[face_item["axis"]]
    def _face_value(self, face_obj, face_item):
        bb = face_obj.BoundingBox()
        axis = face_item["axis"]
        if axis == "X":
            return bb.xmax if face_item["sign"] > 0 else bb.xmin
        if axis == "Y":
            return bb.ymax if face_item["sign"] > 0 else bb.ymin
        return bb.zmax if face_item["sign"] > 0 else bb.zmin
    def _workplane(self, face_item):
        faces = self.obj.faces(face_item["selector"]).vals()
        if not faces:
            raise ValueError(f"no face selected: {face_item['selector']}")
        face_obj = max(faces, key=lambda item: self._face_value(item, face_item)) if face_item["sign"] > 0 else min(faces, key=lambda item: self._face_value(item, face_item))
        return self.obj.newObject([face_obj]).workplane(centerOption="CenterOfBoundBox")
    def _hole_radius(self, r):
        if isinstance(r, str):
            thread = r.upper()
            if thread not in THREAD_SIZE_ITEMS:
                raise ValueError(f"unknown thread size: {r}")
            return float(THREAD_SIZE_ITEMS[thread]["minor_d"]) / 2, thread
        return float(r), None
    def _cut_drill_tip(self, face_item, points, radius, depth, tip_angle):
        cone_h = float(radius) / math.tan(math.radians(float(tip_angle) / 2))
        cone_wp = self._workplane(face_item).workplane(offset=-float(depth))
        for pt in points:
            cone_tool = cone_wp.transformed(offset=cq.Vector(pt[0], pt[1], 0)).circle(float(radius)).workplane(offset=-cone_h).circle(0.0001).loft(combine=False)
            self.obj = self.obj.cut(cone_tool, clean=False)
    def hole(self, face, point, r, depth, drilling=True, tip_angle=120):
        self._check_obj()
        face_item = self._face_item(face)
        points = self._points(point)
        radius, thread = self._hole_radius(r)
        solid_depth = self._solid_depth(face_item)
        if isinstance(depth, str) and depth.upper() in ("ALL", "THROUGH", "THRU"):
            cut_depth = solid_depth
            through = True
        else:
            target_depth = float(depth)
            cut_depth = target_depth + 1 if thread is not None else target_depth
            cut_depth = min(cut_depth, solid_depth)
            through = cut_depth >= solid_depth - 0.001
        cut_tool = self._workplane(face_item).pushPoints(points).circle(radius).extrude(-cut_depth, combine=False)
        self.obj = self.obj.cut(cut_tool, clean=False)
        if drilling and not through:
            self._cut_drill_tip(face_item, points, radius, cut_depth, tip_angle)
        return self
    def slot(self, face, point, r, c2c, depth):
        self._check_obj()
        face_item = self._face_item(face)
        points = self._points(point)
        radius = float(r)
        if isinstance(depth, str) and depth.upper() in ("ALL", "THROUGH", "THRU"):
            cut_depth = self._solid_depth(face_item)
        else:
            cut_depth = min(float(depth), self._solid_depth(face_item))
        for pt in points:
            if float(c2c) > 0:
                rect_tool = self._workplane(face_item).center(pt[0], pt[1]).rect(float(c2c), radius * 2).extrude(-cut_depth, combine=False)
                self.obj = self.obj.cut(rect_tool, clean=False)
                end_points = [(pt[0] - float(c2c) / 2, pt[1]), (pt[0] + float(c2c) / 2, pt[1])]
            else:
                end_points = [pt]
            circle_tool = self._workplane(face_item).pushPoints(end_points).circle(radius).extrude(-cut_depth, combine=False)
            self.obj = self.obj.cut(circle_tool, clean=False)
        return self
    def extend_rect(self, face, sign, p1, p2, h):
        self._check_obj()
        face_item = self._face_item(face)
        x1, y1 = float(p1[0]), float(p1[1])
        x2, y2 = float(p2[0]), float(p2[1])
        w = abs(x2 - x1)
        hh = abs(y2 - y1)
        cx = (x1 + x2) / 2
        cy = (y1 + y2) / 2
        depth = float(h)
        tool = self._workplane(face_item).center(cx, cy).rect(w, hh).extrude(depth if sign == "+" else -depth, combine=False)
        self.obj = self.obj.union(tool).clean() if sign == "+" else self.obj.cut(tool, clean=False)
        return self
    def extend_circle(self, face, sign, c, h, r=None):
        self._check_obj()
        face_item = self._face_item(face)
        radius = float(h if r is None else r)
        depth = float(h)
        tool = self._workplane(face_item).center(float(c[0]), float(c[1])).circle(radius).extrude(depth if sign == "+" else -depth, combine=False)
        self.obj = self.obj.union(tool).clean() if sign == "+" else self.obj.cut(tool, clean=False)
        return self
    def _face_edges(self, face, corner):
        selector = self._face_item(face)["selector"]
        edges = []
        for face_obj in self.obj.faces(selector).vals():
            if corner in ("out-corner", "outer", "out"):
                edges += face_obj.outerWire().Edges()
            elif corner in ("in-corner", "inner", "in"):
                for wire in face_obj.innerWires():
                    edges += wire.Edges()
            else:
                raise ValueError(f"unknown corner: {corner}")
        return edges
    def chamfer(self, face, corner, val):
        self._check_obj()
        edges = self._face_edges(face, corner)
        if edges:
            self.obj = self.obj.newObject(edges).chamfer(float(val))
        return self
    def round(self, face, corner, val):
        self._check_obj()
        edges = self._face_edges(face, corner)
        if edges:
            self.obj = self.obj.newObject(edges).fillet(float(val))
        return self
    def rotate(self, kw):
        self._check_obj()
        for key, val in kw.items():
            turns = int(val)
            self.rotate_info[key] = self.rotate_info.get(key, 0) + turns
            angle = turns * 90
            if key == "x":
                self.obj = self.obj.rotate((0, 0, 0), (1, 0, 0), angle)
            elif key == "y":
                self.obj = self.obj.rotate((0, 0, 0), (0, 1, 0), angle)
            elif key == "z":
                self.obj = self.obj.rotate((0, 0, 0), (0, 0, 1), angle)
            else:
                raise ValueError(f"unknown rotate axis: {key}")
        return self
    def save(self, path):
        self._check_obj()
        path = Path(path)
        if path.suffix == "":
            path = path.with_suffix(".stp")
        path.parent.mkdir(parents=True, exist_ok=True)
        cq.exporters.export(self.obj, str(path), exportType=cq.exporters.ExportTypes.STEP)
        return str(path)
