


建立鍊式關係
def get_tree_relation(,,):
    data = {"#101":{"#60":{"#15","#14",}, "#59":None},,,,}
    return data
    

建立可視畫鍊式關係
def draw_tree_view(,,):
    使用 matplotlib 
    
    像 excel 那樣排版 levels 由左到右 連連看
    
    












