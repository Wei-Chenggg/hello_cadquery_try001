from pathlib import Path
import re
import numpy as np
import cadquery as cq
from cadquery import importers, Compound
from cadquery.occ_impl.exporters.dxf import DxfDocument
from OCP.BRepLib import BRepLib
from OCP.GeomConvert import GeomConvert_CurveToAnaCurve
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt
from toolbox.common_functions import *


dxf_color_map = {
    "依圖塊": 0,  "紅": 1, "黃": 2,  "綠": 3, "青": 4, "藍": 5, "紫紅": 6,
    "洋紅": 6,   "白": 7,"黑": 7,"深灰": 8,"淺灰": 9,"橘色": 30,"依圖層": 256,}
dxf_layer_items = {
                "0": {"color": dxf_color_map["白"], "linetype": "CONTINUOUS", "lineweight": 18},
                "HID": {"color": dxf_color_map["綠"], "linetype": "HIDDEN", "lineweight": 18},
                "SUP": {"color": dxf_color_map["橘色"], "linetype": "CONTINUOUS", "lineweight": 18},
                "AUTO_CEN": {"color": dxf_color_map["紅"], "linetype": "CENTER", "lineweight": 18},
                "DIM": {"color": dxf_color_map["黃"], "linetype": "CONTINUOUS", "lineweight": 18},
                "HAT": {"color": dxf_color_map["青"], "linetype": "CONTINUOUS", "lineweight": 18},
                "TAN": {"color": dxf_color_map["青"], "linetype": "CONTINUOUS", "lineweight": 18},
                }
dxf_linetype_items = {
                "HIDDEN": {"pattern":[4, 3, -1], "description": "Hidden __ __ __ __ __ __ __"},
                "CENTER": {"pattern":[12.5, 5, -1, 0.5, -1, 5], "description": "Hidden __ __ __ __ __ __ __"},
                }

SPACE_IN_PAPER = [270, 200]
SCALE_OPTIONS = ["1/20", "1/15","1/10","1/8","1/5","1/4","1/3","1/2","2/3","3/4","1/1","4/3","3/2","2/1","3/1","4/1","5/1","10/1","15/1","20/1"]

LINE_RATIO_GAMMA = {"AUTO_CEN":0.05, "HID":0.02}

THREAD_ARC_ANGLE = [255,165]

class STP_Helper:
    def __init__(self, ):
        self.stp_fpath = None
        self.model = None
        self.doc = None
        self.dxf_doc = None
        self.view_data = None
        self.proj_matrix = None
        self.proj_offset = None
        self.ct_info = None
        self.topology_info = None
    def load(self, stp_fpath):
        stp_fpath = Path(stp_fpath)
        if not stp_fpath.exists():
            raise FileNotFoundError(str(stp_fpath))
        self.stp_fpath = stp_fpath
        self.model = importers.importStep(str(stp_fpath))
    def _init_dxf_document(self):
        doc = DxfDocument(setup=["linetypes"])
        for name, item in dxf_linetype_items.items():
            if name not in doc.document.linetypes:
                doc.document.linetypes.add(name, **item)
            else:
                linetype = doc.document.linetypes.get(name)
                try:
                    linetype.dxf.description = item.get("description", linetype.dxf.get("description", ""))
                    linetype.setup_pattern(item["pattern"])
                except:
                    pass
        for layer_name, layer_item in dxf_layer_items.items():
            layer_kw = {"color": layer_item["color"]}
            if layer_item.get("linetype") is not None:
                layer_kw["linetype"] = layer_item["linetype"]
            if layer_name not in doc.document.layers:
                doc.add_layer(layer_name, **layer_kw)
            layer = doc.document.layers.get(layer_name)
            layer.dxf.color = layer_item["color"]
            layer.dxf.linetype = layer_item.get("linetype", "CONTINUOUS")
            layer.dxf.lineweight = layer_item["lineweight"]
        self.dxf_doc = doc
        self.doc = doc.document
        return self.doc
    def _cal_proj_hlr(self, stp_shape, view_normal_dir, x_dir, eta=1e-3):
        hlr = HLRBRep_Algo()
        hlr.Add(stp_shape.wrapped)
        hlr.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(), gp_Dir(*view_normal_dir), gp_Dir(*x_dir))))
        hlr.Update()
        hlr.Hide()
        hlr_shapes = HLRBRep_HLRToShape(hlr)
        visible = []
        hidden = []
        tan = []
        for target, items in (
            (visible, (hlr_shapes.VCompound(), hlr_shapes.OutLineVCompound())),
            (tan, (hlr_shapes.Rg1LineVCompound(),)),
            (hidden, (hlr_shapes.HCompound(), hlr_shapes.OutLineHCompound())),
        ):
            for item in items:
                if item.IsNull():
                    continue
                BRepLib.BuildCurves3d_s(item, eta)
                for edge in Compound(item).Edges():
                    target.append(edge)
        return visible, hidden, tan
    def proc_proj_stp_all_views(self, show_hidden=True, spacing=80):
        shape = self.model.val()
        dxf_doc = self._init_dxf_document()
        self.ct_info = {"bspline_to_line": 0, "bspline_fallback": 0}
        view_cfgs = {
            "iso_lt": {"N": (-1, 1, 1), "U": (0, 1, 0), "label": "ISO LT"},
            "top": {"N": (0, 1, 0), "U": (0, 0, -1), "label": "TOP"},
            "iso_rt": {"N": (1, 1, 1), "U": (0, 1, 0), "label": "ISO RT"},
            "left": {"N": (-1, 0, 0), "U": (0, 1, 0), "label": "LEFT"},
            "front": {"N": (0, 0, 1), "U": (0, 1, 0), "label": "FRONT"},
            "right": {"N": (1, 0, 0), "U": (0, 1, 0), "label": "RIGHT"},
            "iso_lb": {"N": (-1, -1, 1), "U": (0, 1, 0), "label": "ISO LB"},
            "bottom": {"N": (0, -1, 0), "U": (0, 0, 1), "label": "BOTTOM"},
            "iso_rb": {"N": (1, -1, 1), "U": (0, 1, 0), "label": "ISO RB"},
        }
        view_data = {}
        for name, cfg in view_cfgs.items():
            n = cfg["N"]
            u = cfg["U"]
            r = (u[1] * n[2] - u[2] * n[1], u[2] * n[0] - u[0] * n[2], u[0] * n[1] - u[1] * n[0])
            visible, hidden, tan = self._cal_proj_hlr(shape, n, r)
            all_items = visible + hidden + tan
            if not all_items:
                raise ValueError(f"{name} view no projection edge")
            bb = Compound.makeCompound(all_items).BoundingBox()
            view_data[name] = {"visible": visible, "hidden": hidden, "tan": tan, "bb": bb, "width": bb.xlen, "height": bb.ylen, "label": cfg["label"], "N": n, "U": u, "R": r, "is_iso": name.startswith("iso")}
        col_w = [
            max(view_data["iso_lt"]["width"], view_data["left"]["width"], view_data["iso_lb"]["width"]),
            max(view_data["top"]["width"], view_data["front"]["width"], view_data["bottom"]["width"]),
            max(view_data["iso_rt"]["width"], view_data["right"]["width"], view_data["iso_rb"]["width"]),
        ]
        row_h = [
            max(view_data["iso_lb"]["height"], view_data["bottom"]["height"], view_data["iso_rb"]["height"]),
            max(view_data["left"]["height"], view_data["front"]["height"], view_data["right"]["height"]),
            max(view_data["iso_lt"]["height"], view_data["top"]["height"], view_data["iso_rt"]["height"]),
        ]
        col_x = [0, col_w[0] + spacing, col_w[0] + spacing + col_w[1] + spacing]
        row_y = [0, row_h[0] + spacing, row_h[0] + spacing + row_h[1] + spacing]
        layout = {
            "iso_lt": (0, 2),
            "top": (1, 2),
            "iso_rt": (2, 2),
            "left": (0, 1),
            "front": (1, 1),
            "right": (2, 1),
            "iso_lb": (0, 0),
            "bottom": (1, 0),
            "iso_rb": (2, 0),
        }
        self.proj_matrix = {}
        self.proj_offset = {}
        for name in ("iso_lt", "top", "iso_rt", "left", "front", "right", "iso_lb", "bottom", "iso_rb"):
            view = view_data[name]
            c, r = layout[name]
            x = col_x[c] + (col_w[c] - view["width"]) / 2
            y = row_y[r] + (row_h[r] - view["height"]) / 2
            dx = x - view["bb"].xmin
            dy = y - view["bb"].ymin
            view["dx"] = dx
            view["dy"] = dy
            proj_r = np.array(view["R"], dtype=float)
            proj_u = np.array(view["U"], dtype=float)
            proj_r = proj_r / np.linalg.norm(proj_r)
            proj_u = proj_u / np.linalg.norm(proj_u)
            view["proj_matrix"] = np.array([proj_r, proj_u], dtype=float)
            view["proj_offset"] = np.array([dx, dy], dtype=float)
            self.proj_matrix[name] = view["proj_matrix"]
            self.proj_offset[name] = view["proj_offset"]
            edge_layer_items = []
            if show_hidden and not view["is_iso"]:
                edge_layer_items.append((view["hidden"], "HID"))
            edge_layer_items.append((view["visible"], "0"))
            edge_layer_items.append((view["tan"], "TAN"))
            for items, layer in edge_layer_items:
                for item in items:
                    edge = item.translate((dx, dy, 0))
                    is_ct_line = False
                    if edge.geomType() == "BSPLINE":
                        adaptor = edge._geomAdaptor()
                        curve = adaptor.Curve().Curve()
                        first = adaptor.FirstParameter()
                        last = adaptor.LastParameter()
                        try:
                            is_ct_line = GeomConvert_CurveToAnaCurve.ComputeLine_s(curve, 1e-6, first, last, first, last, 0.0) is not None
                        except:
                            is_ct_line = False
                    if is_ct_line:
                        self.dxf_doc.msp.add_line(edge.startPoint().toTuple(), edge.endPoint().toTuple(), dxfattribs={"layer": layer})
                        self.ct_info["bspline_to_line"] += 1
                    else:
                        self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                        if edge.geomType() == "BSPLINE":  self.ct_info["bspline_fallback"] += 1
        self.view_data = view_data
        return self.doc
    def proc_fix_edges(self, tan_gap=None, tan_gap_gamma=0.008, tan_overlap_tol=1e-3):
        if self.doc is None or self.view_data is None:
            raise ValueError("請先 proc_proj_stp_all_views")
        tol = 1e-3
        sample_n = 32
        msp = self.doc.modelspace()
        for ent in list(msp):
            if ent.dxf.layer in ("0", "HID", "TAN"):
                msp.delete_entity(ent)
        def _sample_edge(edge, n=sample_n):
            adaptor = edge._geomAdaptor()
            curve = adaptor.Curve().Curve()
            first = adaptor.FirstParameter()
            last = adaptor.LastParameter()
            pts = []
            for t in np.linspace(first, last, n):
                p = curve.Value(float(t))
                pts.append([p.X(), p.Y()])
            return np.array(pts, dtype=float)
        def _trim_pts(pts, gap):
            if gap <= 0 or len(pts) < 2:
                return pts
            if np.linalg.norm(pts[0] - pts[-1]) <= max(tol * 5, 1e-5):
                return None
            seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
            total = float(np.sum(seg))
            if total <= gap * 2 + 1e-6:
                return None
            def _point_at(s):
                acc = 0.0
                for i, lg in enumerate(seg):
                    if lg <= 1e-12:
                        continue
                    if acc + lg >= s:
                        t = (s - acc) / lg
                        return pts[i] * (1 - t) + pts[i + 1] * t, i
                    acc += lg
                return pts[-1], len(seg) - 1
            p1, i1 = _point_at(gap)
            p2, i2 = _point_at(total - gap)
            if i2 < i1:
                return None
            ret = [p1]
            for i in range(i1 + 1, i2 + 1):
                ret.append(pts[i])
            ret.append(p2)
            ret = np.array(ret, dtype=float)
            return ret if len(ret) >= 2 else None
        def _dist_pts_to_polyline(pts, polyline):
            if len(polyline) < 2:
                return np.full(len(pts), np.inf)
            ret = np.full(len(pts), np.inf)
            for p1, p2 in zip(polyline[:-1], polyline[1:]):
                v = p2 - p1
                vv = float(np.dot(v, v))
                if vv <= 1e-12:
                    d = np.linalg.norm(pts - p1, axis=1)
                else:
                    t = np.clip(((pts - p1) @ v) / vv, 0, 1)
                    proj = p1 + np.outer(t, v)
                    d = np.linalg.norm(pts - proj, axis=1)
                ret = np.minimum(ret, d)
            return ret
        def _is_overlap_0(pts, visible_pts_items):
            if pts is None or len(pts) < 2 or not visible_pts_items:
                return False
            dist = np.full(len(pts), np.inf)
            for item in visible_pts_items:
                dist = np.minimum(dist, _dist_pts_to_polyline(pts, item))
            return float(np.mean(dist <= tan_overlap_tol)) >= 0.85 and float(np.median(dist)) <= tan_overlap_tol
        def _fit_line(pts):
            if len(pts) < 2:
                return None
            pc = pts.mean(axis=0)
            data = pts - pc
            try:
                _, _, vh = np.linalg.svd(data, full_matrices=False)
            except:
                return None
            v = vh[0]
            k = data @ v
            proj = pc + np.outer(k, v)
            err = float(np.max(np.linalg.norm(pts - proj, axis=1)))
            if err > tol:
                return None
            p1 = pc + v * float(np.min(k))
            p2 = pc + v * float(np.max(k))
            if np.linalg.norm(p2 - p1) <= 1e-8:
                return None
            return {"kind": "line", "p1": p1, "p2": p2, "max_error": err}
        def _fit_circle(pts):
            if len(pts) < 5:
                return None
            x = pts[:, 0]
            y = pts[:, 1]
            a = np.column_stack([x, y, np.ones(len(pts))])
            b = -(x * x + y * y)
            try:
                d, e, f = np.linalg.lstsq(a, b, rcond=None)[0]
            except:
                return None
            cx = -d / 2
            cy = -e / 2
            r2 = cx * cx + cy * cy - f
            if r2 <= 1e-12:
                return None
            radius = float(r2 ** 0.5)
            dist = np.linalg.norm(pts - np.array([cx, cy]), axis=1)
            err = float(np.max(np.abs(dist - radius)))
            if err > max(tol, radius * 1e-5):
                return None
            angles = np.unwrap(np.arctan2(pts[:, 1] - cy, pts[:, 0] - cx))
            delta = float(angles[-1] - angles[0])
            start_raw = float(np.degrees(np.arctan2(pts[0, 1] - cy, pts[0, 0] - cx)) % 360)
            end_raw = float(np.degrees(np.arctan2(pts[-1, 1] - cy, pts[-1, 0] - cx)) % 360)
            chord = float(np.linalg.norm(pts[-1] - pts[0]))
            span = abs(delta)
            if chord <= max(tol * 5, radius * 1e-5) and span >= np.pi * 1.8:
                return {"kind": "circle", "center": (cx, cy), "radius": radius, "max_error": err}
            if span <= 1e-6:
                return None
            if delta >= 0:
                start_angle, end_angle = start_raw, end_raw
            else:
                start_angle, end_angle = end_raw, start_raw
            return {"kind": "arc", "center": (cx, cy), "radius": radius, "start_angle": start_angle, "end_angle": end_angle, "max_error": err}
        def _fit_edge(edge):
            if edge.geomType() != "BSPLINE":
                return None
            try:
                pts = _sample_edge(edge)
            except:
                return None
            line_fit = _fit_line(pts)
            circle_fit = _fit_circle(pts)
            if circle_fit is not None:
                box = pts.max(axis=0) - pts.min(axis=0)
                diag = float(np.linalg.norm(box))
                if line_fit is None or circle_fit["radius"] <= max(diag, 1e-6) * 100:
                    return circle_fit
            return line_fit
        def _draw_fit(fit, layer):
            if fit["kind"] == "line":
                msp.add_line(tuple(fit["p1"]), tuple(fit["p2"]), dxfattribs={"layer": layer})
            elif fit["kind"] == "circle":
                msp.add_circle(fit["center"], fit["radius"], dxfattribs={"layer": layer})
            elif fit["kind"] == "arc":
                msp.add_arc(fit["center"], fit["radius"], fit["start_angle"], fit["end_angle"], dxfattribs={"layer": layer})
        def _draw_tan_edge(edge, layer, visible_pts_items, tan_gap_now):
            try:
                src_pts = _sample_edge(edge, 64)
            except:
                src_pts = None
            if src_pts is None:
                self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                return "tan_unchanged"
            if np.linalg.norm(src_pts[0] - src_pts[-1]) <= max(tol * 5, 1e-5):
                if _is_overlap_0(src_pts, visible_pts_items):
                    return "tan_overlap_skip"
                self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), "0")
                return "tan_closed_to_0"
            pts = _trim_pts(src_pts, tan_gap_now)
            if pts is None:
                self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                return "tan_unchanged"
            if _is_overlap_0(pts, visible_pts_items):
                return "tan_overlap_skip"
            line_fit = _fit_line(pts)
            circle_fit = _fit_circle(pts)
            if circle_fit is not None:
                box = pts.max(axis=0) - pts.min(axis=0)
                diag = float(np.linalg.norm(box))
                if line_fit is None or circle_fit["radius"] <= max(diag, 1e-6) * 100:
                    _draw_fit(circle_fit, layer)
                    return "tan_" + circle_fit["kind"]
            if line_fit is not None:
                _draw_fit(line_fit, layer)
                return "tan_line"
            msp.add_lwpolyline([tuple(p) for p in pts], dxfattribs={"layer": layer})
            return "tan_polyline"
        def _draw_edge(edge, layer, fix_iso=False, visible_pts_items=None, tan_gap_now=0):
            if layer == "TAN" and tan_gap_now > 0:
                return _draw_tan_edge(edge, layer, visible_pts_items or [], tan_gap_now)
            if fix_iso:
                self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                return "iso_unchanged"
            if edge.geomType() != "BSPLINE":
                self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                return "unchanged"
            fit = _fit_edge(edge)
            if fit is None:
                self.dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                return "spline_fallback"
            _draw_fit(fit, layer)
            return fit["kind"]
        fix_info = {"line": 0, "arc": 0, "circle": 0, "spline_fallback": 0, "unchanged": 0, "iso_unchanged": 0, "tan_line": 0, "tan_arc": 0, "tan_circle": 0, "tan_polyline": 0, "tan_unchanged": 0, "tan_overlap_skip": 0, "tan_closed_to_0": 0, "overlap_ref_edges": 0}
        tan_gap_items = {}
        for name in ("iso_lt", "top", "iso_rt", "left", "front", "right", "iso_lb", "bottom", "iso_rb"):
            view = self.view_data[name]
            tan_gap_now = float(tan_gap) if tan_gap is not None else float(max(view["width"], view["height"]) * tan_gap_gamma)
            tan_gap_items[name] = tan_gap_now
            visible_pts_items = []
            if not view.get("is_iso"):
                for item in view["visible"]:
                    if item.geomType() not in ("LINE", "CIRCLE", "ARC"):
                        continue
                    try:
                        visible_pts_items.append(_sample_edge(item.translate((view["dx"], view["dy"], 0)), 48))
                    except:
                        pass
            fix_info["overlap_ref_edges"] += len(visible_pts_items)
            edge_layer_items = []
            if not view.get("is_iso"):
                edge_layer_items.append((view["hidden"], "HID"))
            edge_layer_items.append((view["visible"], "0"))
            edge_layer_items.append((view["tan"], "TAN"))
            for items, layer in edge_layer_items:
                for item in items:
                    edge = item.translate((view["dx"], view["dy"], 0))
                    kind = _draw_edge(edge, layer, view.get("is_iso"), visible_pts_items, tan_gap_now)
                    fix_info[kind] = fix_info.get(kind, 0) + 1
        self.fix_edge_info = fix_info
        self.fix_edge_tan_gap = tan_gap_items
        return fix_info
    def proc_parse_stp(self,):
        text = self.stp_fpath.read_text(encoding="utf-8", errors="ignore")
        def _split_params(data):
            ret = []
            buf = []
            layer = 0
            in_text = False
            i = 0
            while i < len(data):
                ch = data[i]
                if ch == "'":
                    buf.append(ch)
                    if i + 1 < len(data) and data[i + 1] == "'":
                        buf.append(data[i + 1])
                        i += 2
                        continue
                    in_text = not in_text
                elif not in_text:
                    if ch == "(":
                        layer += 1
                    elif ch == ")":
                        layer -= 1
                    elif ch == "," and layer == 0:
                        ret.append("".join(buf).strip())
                        buf = []
                        i += 1
                        continue
                    buf.append(ch)
                else:
                    buf.append(ch)
                i += 1
            if buf:
                ret.append("".join(buf).strip())
            return ret
        def _refs(data):
            return re.findall(r"#\d+", data or "")
        def _nums(data):
            return [float(x) for x in re.findall(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?", data or "")]
        def _idx(ref):
            try:
                return int(str(ref).lstrip("#"))
            except:
                return 0
        entities = {}
        for item in re.finditer(r"#(\d+)\s*=\s*(.*?);", text, re.S):
            key = "#" + item.group(1)
            idx = int(item.group(1))
            body = " ".join(item.group(2).split())
            m = re.match(r"([A-Z0-9_]+)\s*\((.*)\)$", body)
            if not m:
                entities[key] = {"idx": idx, "type": "", "params": [], "text": body}
                continue
            entities[key] = {"idx": idx, "type": m.group(1), "params": _split_params(m.group(2)), "text": body}
        def _point(ref):
            item = entities.get(ref)
            if not item or item["type"] != "CARTESIAN_POINT":
                return None
            nums = _nums(item["params"][-1] if item["params"] else item["text"])
            return nums if nums else None
        def _direction(ref):
            item = entities.get(ref)
            if not item or item["type"] != "DIRECTION":
                return None
            nums = _nums(item["params"][-1] if item["params"] else item["text"])
            return nums if nums else None
        def _axis3(ref):
            item = entities.get(ref)
            if not item or item["type"] != "AXIS2_PLACEMENT_3D":
                return {}
            ids = _refs(item["text"])
            return {"point": _point(ids[0]) if len(ids) > 0 else None, "dir": _direction(ids[1]) if len(ids) > 1 else None, "ref_dir": _direction(ids[2]) if len(ids) > 2 else None}
        def _surface(ref):
            item = entities.get(ref)
            if not item:
                return {"surface_id": ref, "surface_idx": _idx(ref), "type": "unknown"}
            if item["type"] == "PLANE":
                ids = _refs(item["text"])
                ax = _axis3(ids[0]) if ids else {}
                return {"surface_id": ref, "surface_idx": item["idx"], "type": "plane", "point": ax.get("point"), "normal": ax.get("dir")}
            if item["type"] == "CYLINDRICAL_SURFACE":
                ids = _refs(item["text"])
                ax = _axis3(ids[0]) if ids else {}
                nums = _nums(item["params"][-1] if item["params"] else item["text"])
                return {"surface_id": ref, "surface_idx": item["idx"], "type": "cylinder", "point": ax.get("point"), "axis_dir": ax.get("dir"), "radius": nums[0] if nums else None}
            if item["type"] == "CONICAL_SURFACE":
                ids = _refs(item["text"])
                ax = _axis3(ids[0]) if ids else {}
                nums = _nums(",".join(item["params"][-2:]) if len(item["params"]) >= 2 else item["text"])
                return {"surface_id": ref, "surface_idx": item["idx"], "type": "cone", "point": ax.get("point"), "axis_dir": ax.get("dir"), "radius": nums[0] if nums else None, "semi_angle": nums[1] if len(nums) > 1 else None}
            if item["type"] == "TOROIDAL_SURFACE":
                ids = _refs(item["text"])
                ax = _axis3(ids[0]) if ids else {}
                nums = _nums(",".join(item["params"][-2:]) if len(item["params"]) >= 2 else item["text"])
                return {"surface_id": ref, "surface_idx": item["idx"], "type": "toroid", "point": ax.get("point"), "axis_dir": ax.get("dir"), "major_radius": nums[0] if nums else None, "minor_radius": nums[1] if len(nums) > 1 else None}
            return {"surface_id": ref, "surface_idx": item["idx"], "type": item["type"].lower()}
        def _curve(ref):
            item = entities.get(ref)
            if not item:
                return {"curve_id": ref, "curve_idx": _idx(ref), "type": "unknown"}
            if item["type"] in ("SURFACE_CURVE", "SEAM_CURVE"):
                ids = _refs(item["text"])
                ret = _curve(ids[0]) if ids else {"type": "unknown"}
                ret["source_curve_id"] = ref
                ret["source_curve_idx"] = item["idx"]
                return ret
            if item["type"] == "CIRCLE":
                ids = _refs(item["text"])
                ax = _axis3(ids[0]) if ids else {}
                nums = _nums(item["params"][-1] if item["params"] else item["text"])
                return {"curve_id": ref, "curve_idx": item["idx"], "type": "circle", "center": ax.get("point"), "normal": ax.get("dir"), "radius": nums[0] if nums else None}
            return {"curve_id": ref, "curve_idx": item["idx"], "type": item["type"].lower()}
        def _vertex(ref):
            item = entities.get(ref)
            ids = _refs(item["text"]) if item else []
            return _point(ids[0]) if ids else None
        def _edge(ref):
            item = entities.get(ref)
            if not item or item["type"] != "EDGE_CURVE":
                return {"edge_id": ref, "edge_idx": _idx(ref), "type": "unknown"}
            ids = _refs(item["text"])
            curve_id = ids[2] if len(ids) > 2 else None
            curve = _curve(curve_id)
            same_sense = str(item["params"][-1]).upper() == ".T." if item["params"] else None
            return {"edge_id": ref, "edge_idx": item["idx"], "type": "edge_curve", "start_vertex": ids[0] if len(ids) > 0 else None, "start_vertex_idx": _idx(ids[0]) if len(ids) > 0 else None, "end_vertex": ids[1] if len(ids) > 1 else None, "end_vertex_idx": _idx(ids[1]) if len(ids) > 1 else None, "curve_id": curve_id, "curve_idx": _idx(curve_id), "curve_type": curve.get("type"), "curve": curve, "points": [p for p in (_vertex(ids[0]) if len(ids) > 0 else None, _vertex(ids[1]) if len(ids) > 1 else None) if p is not None], "same_sense": same_sense}
        def _loop(ref):
            item = entities.get(ref)
            if not item or item["type"] != "EDGE_LOOP":
                return []
            edge_items = []
            for oriented_ref in _refs(item["params"][-1] if item["params"] else item["text"]):
                oriented = entities.get(oriented_ref)
                ids = _refs(oriented["text"]) if oriented else []
                edge_id = None
                for target_id in ids:
                    if entities.get(target_id, {}).get("type") == "EDGE_CURVE":
                        edge_id = target_id
                        break
                if edge_id is None:
                    continue
                same_sense = str(oriented["params"][-1]).upper() == ".T." if oriented and oriented["params"] else None
                edge_items.append({"oriented_edge_id": oriented_ref, "oriented_edge_idx": _idx(oriented_ref), "edge_id": edge_id, "edge_idx": _idx(edge_id), "same_sense": same_sense})
            return edge_items
        f2e = {}
        e2f = {}
        faces = {}
        surfaces = {}
        for face_id, item in entities.items():
            if item["type"] != "ADVANCED_FACE":
                continue
            face_params = item["params"]
            bound_ids = _refs(face_params[1]) if len(face_params) > 1 else []
            surface_ids = _refs(face_params[2]) if len(face_params) > 2 else []
            surface_id = surface_ids[0] if surface_ids else None
            surface = _surface(surface_id)
            surfaces[surface_id] = surface
            same_sense = str(face_params[3]).upper() == ".T." if len(face_params) > 3 else None
            face_edges = []
            bound_items = []
            for bound_ix, bound_id in enumerate(bound_ids):
                bound = entities.get(bound_id)
                loop_ids = _refs(bound["text"]) if bound else []
                loop_id = loop_ids[0] if loop_ids else None
                loop_edges = _loop(loop_id)
                for edge_item in loop_edges:
                    edge_id = edge_item["edge_id"]
                    if edge_id not in face_edges:
                        face_edges.append(edge_id)
                    e2f.setdefault(edge_id, [])
                    if face_id not in e2f[edge_id]:
                        e2f[edge_id].append(face_id)
                bound_items.append({"bound_id": bound_id, "bound_idx": _idx(bound_id), "bound_type": bound["type"] if bound else None, "loop_id": loop_id, "loop_idx": _idx(loop_id), "is_outer": bound_ix == 0 or (bound and bound["type"] == "FACE_OUTER_BOUND"), "edges": loop_edges})
            f2e[face_id] = face_edges
            faces[face_id] = {"face_id": face_id, "face_idx": _idx(face_id), "surface_id": surface_id, "surface_idx": _idx(surface_id), "surface_type": surface.get("type"), "same_sense": same_sense, "bounds": bound_items, "edges": face_edges, "edge_idxs": [_idx(edge_id) for edge_id in face_edges], "surface": surface}
        edges = {}
        for edge_id in sorted(e2f, key=_idx):
            edge_item = _edge(edge_id)
            edge_item["faces"] = e2f.get(edge_id, [])
            edge_item["face_idxs"] = [_idx(face_id) for face_id in edge_item["faces"]]
            edges[edge_id] = edge_item
        self.topology_info = {"f2e": f2e, "e2f": e2f, "faces": faces, "edges": edges, "surfaces": surfaces, "face_count": len(faces), "edge_count": len(edges), "entity_count": len(entities)}
        return self.topology_info
    def proc_gather_cylinder(self,):
        faces = self.topology_info.get("faces", {})
        edges = self.topology_info.get("edges", {})
        face_neighbors = {face_id: [] for face_id in faces}
        for edge_id, edge in edges.items():
            edge_faces = edge.get("faces", [])
            for face_id in edge_faces:
                for other_face_id in edge_faces:
                    if face_id != other_face_id:
                        face_neighbors.setdefault(face_id, []).append({"face_id": other_face_id, "face_idx": faces.get(other_face_id, {}).get("face_idx"), "edge_id": edge_id, "edge_idx": edge.get("edge_idx")})
        cylinder_items = {}
        for face in sorted(faces.values(), key=lambda item: item.get("face_idx", 0)):
            face_id = face.get("face_id")
            if face.get("surface_type") != "cylinder":
                continue
            surface = face.get("surface", {})
            axis = surface.get("axis_dir")
            radius = surface.get("radius")
            if axis is None or radius is None:
                continue
            axis = np.array(axis, dtype=float)
            axis_len = np.linalg.norm(axis)
            if axis_len <= 1e-12:
                continue
            axis = axis / axis_len
            radius = float(radius)
            circle_edges = []
            circle_centers = []
            circle_keys = set()
            for edge_id in face.get("edges", []):
                edge = edges.get(edge_id, {})
                curve = edge.get("curve", {})
                if edge.get("curve_type") != "circle" or curve.get("center") is None:
                    continue
                points = edge.get("points", [])
                endpoint_dist = None
                is_full_circle = None
                is_arc = None
                if len(points) >= 2:
                    endpoint_dist = float(np.linalg.norm(np.array(points[0], dtype=float) - np.array(points[-1], dtype=float)))
                    is_full_circle = endpoint_dist <= 1e-5
                    is_arc = endpoint_dist > 1e-5
                key = tuple(round(float(v), 6) for v in curve.get("center"))
                if key not in circle_keys:
                    circle_keys.add(key)
                    circle_centers.append(curve.get("center"))
                circle_edges.append({"edge_id": edge_id, "edge_idx": edge.get("edge_idx"), "center": curve.get("center"), "radius": curve.get("radius"), "faces": edge.get("faces", []), "face_idxs": edge.get("face_idxs", []), "endpoint_dist": endpoint_dist, "is_full_circle": is_full_circle, "is_arc": is_arc})
            end_planes = []
            end_plane_ids = set()
            linked_faces = []
            queue = [{"face_id": face_id, "path": [], "depth": 0}]
            seen = {face_id}
            while queue:
                now = queue.pop(0)
                if now["depth"] >= 5:
                    continue
                for link in face_neighbors.get(now["face_id"], []):
                    next_face_id = link["face_id"]
                    if next_face_id in seen:
                        continue
                    seen.add(next_face_id)
                    next_face = faces.get(next_face_id, {})
                    surface_type = next_face.get("surface_type")
                    path = now["path"] + [{"face_id": next_face_id, "face_idx": next_face.get("face_idx"), "edge_id": link["edge_id"], "edge_idx": link.get("edge_idx"), "surface_type": surface_type}]
                    linked_faces.append({"face_id": next_face_id, "face_idx": next_face.get("face_idx"), "edge_id": link["edge_id"], "edge_idx": link.get("edge_idx"), "surface_type": surface_type})
                    if surface_type == "plane":
                        plane_surface = next_face.get("surface", {})
                        normal = plane_surface.get("normal")
                        point = plane_surface.get("point")
                        if normal is None or point is None:
                            continue
                        normal = np.array(normal, dtype=float)
                        normal_len = np.linalg.norm(normal)
                        if normal_len <= 1e-12:
                            continue
                        normal = normal / normal_len
                        point_arr = np.array(point, dtype=float)
                        if abs(abs(float(np.dot(normal, axis))) - 1) <= 1e-3 and next_face_id not in end_plane_ids:
                            end_plane_ids.add(next_face_id)
                            end_planes.append({"face_id": next_face_id, "face_idx": next_face.get("face_idx"), "edge_id": link["edge_id"], "edge_idx": link.get("edge_idx"), "point": point, "normal": normal.tolist(), "axis_val": float(np.dot(point_arr, axis)), "path": path})
                        continue
                    if surface_type in ("cone", "toroid"):
                        queue.append({"face_id": next_face_id, "path": path, "depth": now["depth"] + 1})
            circle_vals = [float(np.dot(np.array(p, dtype=float), axis)) for p in circle_centers if p is not None]
            circle_vals = [v for v in circle_vals if v is not None]
            end_vals = [item["axis_val"] for item in end_planes if item.get("axis_val") is not None]
            circle_span = max(circle_vals) - min(circle_vals) if len(circle_vals) >= 2 else None
            depth = max(end_vals) - min(end_vals) if len(end_vals) >= 2 else None
            has_arc_edge = any(item.get("is_arc") is True for item in circle_edges)
            has_full_circle_edge = any(item.get("is_full_circle") is True for item in circle_edges)
            if has_arc_edge and has_full_circle_edge:
                circle_edge_type = "mixed"
            elif has_arc_edge:
                circle_edge_type = "arc"
            elif has_full_circle_edge:
                circle_edge_type = "full_circle"
            elif circle_edges:
                circle_edge_type = "unknown"
            else:
                circle_edge_type = "none"
            body_side = "inside_cylinder" if face.get("same_sense") is True else "outside_cylinder" if face.get("same_sense") is False else "unknown"
            is_valid_feature = depth is not None and len(end_planes) >= 2
            if has_arc_edge:
                kind = "round_bbox"
                kind_reason = "arc_circle_edge"
            elif not is_valid_feature:
                kind = "unknown"
                kind_reason = "missing_depth"
            elif body_side == "inside_cylinder":
                kind = "pin"
                kind_reason = "body_inside_cylinder"
            elif body_side == "outside_cylinder":
                kind = "hole"
                kind_reason = "body_outside_cylinder"
            else:
                kind = "unknown"
                kind_reason = "unknown_body_side"
            cylinder_items[face_id] = {"face_id": face_id, "face_idx": face.get("face_idx"), "surface_id": face.get("surface_id"), "surface_idx": face.get("surface_idx"), "kind": kind, "kind_reason": kind_reason, "body_side": body_side, "same_sense": face.get("same_sense"), "axis_dir": axis.tolist(), "surface_point": surface.get("point"), "radius": radius, "diameter": radius * 2, "circle_edges": circle_edges, "circle_centers": circle_centers, "circle_span": circle_span, "circle_edge_type": circle_edge_type, "has_arc_edge": has_arc_edge, "has_full_circle_edge": has_full_circle_edge, "is_valid_feature": is_valid_feature, "end_planes": sorted(end_planes, key=lambda item: item.get("axis_val") or 0), "end_plane_count": len(end_planes), "depth": depth, "linked_faces": linked_faces}
        self.cylinder_info = cylinder_items
        self.topology_info["cylinder_info"] = cylinder_items
        return cylinder_items
    def proc_center_lines(self, extend=None):
        msp = self.doc.modelspace()
        for ent in list(msp.query('*[layer=="AUTO_CEN"]')):
            msp.delete_entity(ent)
        if extend is None:
            scale = float(getattr(self, "scale", {}).get("float", 1))
            if scale <= 0:  scale = 1
            extend = 1 / scale
        eps = 1e-5
        raw_items = []
        for item in sorted(self.topology_info.get("cylinder_info", {}).values(), key=lambda item: item.get("face_idx", 0)):
            face_id = item.get("face_id")
            axis = item.get("axis_dir")
            p0 = item.get("surface_point")
            radius = item.get("radius")
            end_vals = [v for v in [end.get("axis_val") for end in item.get("end_planes", [])] if v is not None]
            if axis is None or p0 is None or radius is None or len(end_vals) < 2:
                continue
            axis = np.array(axis, dtype=float)
            axis_len = np.linalg.norm(axis)
            if axis_len <= 1e-12:  continue
            axis = axis / axis_len
            p0 = np.array(p0, dtype=float)
            radius = float(radius)
            diameter = float(item.get("diameter", radius * 2))
            for size_item in THREAD_SIZE_ITEMS.values():
                if abs(diameter - float(size_item["minor_d"])) <= max(0.03, float(size_item.get("pitch", 0)) * 0.08):
                    radius = float(size_item["major_d"]) / 2
                    break
            base_val = float(np.dot(p0, axis))
            c1 = p0 + axis * (min(end_vals) - base_val)
            c2 = p0 + axis * (max(end_vals) - base_val)
            cc = (c1 + c2) / 2
            for view_name, view in self.view_data.items():
                if view.get("is_iso"):
                    continue
                proj_matrix = self.proj_matrix.get(view_name)
                proj_offset = self.proj_offset.get(view_name)
                if proj_matrix is None or proj_offset is None:
                    continue
                axis2 = proj_matrix @ axis
                axis2_len = np.linalg.norm(axis2)
                center = proj_matrix @ cc + proj_offset
                if axis2_len <= eps:
                    cx, cy = float(center[0]), float(center[1])
                    rr = radius + extend
                    msp.add_line((cx - rr, cy), (cx + rr, cy), dxfattribs={"layer": "AUTO_CEN"})
                    msp.add_line((cx, cy - rr), (cx, cy + rr), dxfattribs={"layer": "AUTO_CEN"})
                    raw_items.append({"view": view_name, "face_id": face_id, "kind": item.get("kind"), "mode": "circle", "center": (cx, cy), "radius": radius})
                    continue
                p1 = proj_matrix @ c1 + proj_offset
                p2 = proj_matrix @ c2 + proj_offset
                if abs(axis2[0]) >= abs(axis2[1]):
                    cy = float((p1[1] + p2[1]) / 2)
                    msp.add_line((float(min(p1[0], p2[0]) - extend), cy), (float(max(p1[0], p2[0]) + extend), cy), dxfattribs={"layer": "AUTO_CEN"})
                    raw_items.append({"view": view_name, "face_id": face_id, "kind": item.get("kind"), "mode": "rect", "ori": "h"})
                else:
                    cx = float((p1[0] + p2[0]) / 2)
                    msp.add_line((cx, float(min(p1[1], p2[1]) - extend)), (cx, float(max(p1[1], p2[1]) + extend)), dxfattribs={"layer": "AUTO_CEN"})
                    raw_items.append({"view": view_name, "face_id": face_id, "kind": item.get("kind"), "mode": "rect", "ori": "v"})
        merge_items = {}
        remove_items = []
        for ent in list(msp.query('*[layer=="AUTO_CEN"]')):
            if ent.dxftype() != "LINE":
                continue
            p1 = np.array([float(ent.dxf.start[0]), float(ent.dxf.start[1])], dtype=float)
            p2 = np.array([float(ent.dxf.end[0]), float(ent.dxf.end[1])], dtype=float)
            view_name = None
            for name, view in self.view_data.items():
                if view.get("is_iso"):
                    continue
                xmin = float(view["bb"].xmin + view["dx"])
                xmax = float(view["bb"].xmax + view["dx"])
                ymin = float(view["bb"].ymin + view["dy"])
                ymax = float(view["bb"].ymax + view["dy"])
                if min(p1[0], p2[0]) >= xmin - extend - 1e-4 and max(p1[0], p2[0]) <= xmax + extend + 1e-4 and min(p1[1], p2[1]) >= ymin - extend - 1e-4 and max(p1[1], p2[1]) <= ymax + extend + 1e-4:
                    view_name = name
                    break
            if view_name is None:
                continue
            if abs(p1[0] - p2[0]) <= 1e-5:
                key = (view_name, "v", round(float((p1[0] + p2[0]) / 2), 4))
                a, b = float(min(p1[1], p2[1])), float(max(p1[1], p2[1]))
            elif abs(p1[1] - p2[1]) <= 1e-5:
                key = (view_name, "h", round(float((p1[1] + p2[1]) / 2), 4))
                a, b = float(min(p1[0], p2[0])), float(max(p1[0], p2[0]))
            else:
                continue
            if key not in merge_items:
                merge_items[key] = {"view": view_name, "ori": key[1], "pos": key[2], "a": a, "b": b}
            else:
                merge_items[key]["a"] = min(merge_items[key]["a"], a)
                merge_items[key]["b"] = max(merge_items[key]["b"], b)
            remove_items.append(ent)
        for ent in remove_items:
            msp.delete_entity(ent)
        center_line_items = []
        for item in merge_items.values():
            if item["b"] - item["a"] <= 1e-6:
                continue
            if item["ori"] == "h":
                p1, p2 = (item["a"], item["pos"]), (item["b"], item["pos"])
            else:
                p1, p2 = (item["pos"], item["a"]), (item["pos"], item["b"])
            msp.add_line(p1, p2, dxfattribs={"layer": "AUTO_CEN"})
            center_line_items.append({"view": item["view"], "ori": item["ori"], "p1": p1, "p2": p2})
        self.center_line_items = center_line_items
        self.center_line_raw_items = raw_items
        return center_line_items
    def debug_cylinder_bbox(self,):
        def _aci_color(ix):
            return ix * 29 % 255 + 1
        def _true_color(ix):
            r = 40 + ix * 71 % 216
            g = 40 + ix * 151 % 216
            b = 40 + ix * 197 % 216
            return (r << 16) + (g << 8) + b
        msp = self.doc.modelspace()
        debug_items = []
        for item in sorted(self.topology_info.get("cylinder_info", {}).values(), key=lambda item: item.get("face_idx", 0)):
            face_id = item.get("face_id")
            axis = item.get("axis_dir")
            p0 = item.get("surface_point")
            radius = item.get("radius")
            end_vals = [v for v in [end.get("axis_val") for end in item.get("end_planes", [])] if v is not None]
            if axis is None or p0 is None or radius is None or item.get("depth") is None or len(end_vals) < 2:
                continue
            axis = np.array(axis, dtype=float)
            axis_len = np.linalg.norm(axis)
            if axis_len <= 1e-12:
                continue
            axis = axis / axis_len
            p0 = np.array(p0, dtype=float)
            radius = float(radius)
            base_val = float(np.dot(p0, axis))
            c1 = p0 + axis * (min(end_vals) - base_val)
            c2 = p0 + axis * (max(end_vals) - base_val)
            ref = np.array([1, 0, 0], dtype=float) if abs(float(np.dot(axis, np.array([1, 0, 0], dtype=float)))) < 0.9 else np.array([0, 1, 0], dtype=float)
            ru = np.cross(axis, ref)
            ru_len = np.linalg.norm(ru)
            if ru_len <= 1e-12:
                continue
            ru = ru / ru_len
            rv = np.cross(axis, ru)
            rv_len = np.linalg.norm(rv)
            if rv_len <= 1e-12:
                continue
            rv = rv / rv_len
            for view_name, view in self.view_data.items():
                if view.get("is_iso"):
                    continue
                proj_matrix = self.proj_matrix.get(view_name)
                proj_offset = self.proj_offset.get(view_name)
                if proj_matrix is None or proj_offset is None:
                    continue
                p1 = proj_matrix @ c1 + proj_offset
                p2 = proj_matrix @ c2 + proj_offset
                ru2 = proj_matrix @ ru
                rv2 = proj_matrix @ rv
                ex = radius * (ru2[0] ** 2 + rv2[0] ** 2) ** 0.5
                ey = radius * (ru2[1] ** 2 + rv2[1] ** 2) ** 0.5
                xmin = min(p1[0] - ex, p2[0] - ex)
                xmax = max(p1[0] + ex, p2[0] + ex)
                ymin = min(p1[1] - ey, p2[1] - ey)
                ymax = max(p1[1] + ey, p2[1] + ey)
                if xmax - xmin <= 1e-6 or ymax - ymin <= 1e-6:
                    continue
                color_ix = len(debug_items)
                color = _aci_color(color_ix)
                true_color = _true_color(color_ix)
                msp.add_lwpolyline([(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)], close=True, dxfattribs={"layer": "SUP", "color": color, "true_color": true_color})
                debug_items.append({"face_id": face_id, "view": view_name, "kind": item.get("kind"), "bbox": [xmin, ymin, xmax, ymax], "diameter": item.get("diameter"), "depth": item.get("depth"), "color": color, "true_color": true_color})
        self.debug_cylinder_boxes = debug_items
        return debug_items
    def proc_gather_linear_dim(self, tol=0.01):
        axis_items = {"dx": (0, np.array([1, 0, 0], dtype=float)), "dy": (1, np.array([0, 1, 0], dtype=float)), "dz": (2, np.array([0, 0, 1], dtype=float))}
        dim_data_linear = {"dx": [], "dy": [], "dz": []}
        def _add(axis_key, value, point, source):
            if value is None or point is None:
                return None
            value = float(value)
            point = np.array(point, dtype=float)
            for old in dim_data_linear[axis_key]:
                if abs(old["value"] - value) <= tol:
                    old["sources"].append(source)
                    if old.get("kind") != "plane" and source.get("kind") == "plane":
                        old.update(source)
                        old["point"] = point.tolist()
                    return old
            item = {"axis": axis_key, "value": value, "point": point.tolist(), "sources": [source], **source}
            dim_data_linear[axis_key].append(item)
            return item
        for face in sorted(self.topology_info.get("faces", {}).values(), key=lambda item: item.get("face_idx", 0)):
            if face.get("surface_type") != "plane":
                continue
            face_edges = [self.topology_info.get("edges", {}).get(edge_id, {}) for edge_id in face.get("edges", [])]
            if not any(str(edge.get("curve_type", "")).lower() == "line" for edge in face_edges):
                continue
            surface = face.get("surface", {})
            normal = surface.get("normal")
            point = surface.get("point")
            if normal is None or point is None:
                continue
            normal = np.array(normal, dtype=float)
            normal_len = np.linalg.norm(normal)
            if normal_len <= 1e-12:
                continue
            normal = normal / normal_len
            point = np.array(point, dtype=float)
            for axis_key, (axis_ix, axis_vec) in axis_items.items():
                if abs(abs(float(np.dot(normal, axis_vec))) - 1) <= 1e-3:
                    _add(axis_key, point[axis_ix], point, {"kind": "plane", "face_id": face.get("face_id"), "face_idx": face.get("face_idx"), "normal": normal.tolist()})
        def _pin_end_points(item):
            axis = item.get("axis_dir")
            p0 = item.get("surface_point")
            radius = item.get("radius")
            if axis is None or p0 is None or radius is None:
                return None
            axis = np.array(axis, dtype=float)
            axis_len = np.linalg.norm(axis)
            if axis_len <= 1e-12:  return None
            axis = axis / axis_len
            p0 = np.array(p0, dtype=float)
            end_vals = [v for v in [end.get("axis_val") for end in item.get("end_planes", [])] if v is not None]
            base_val = float(np.dot(p0, axis))
            if len(end_vals) >= 2:  points = [p0 + axis * (v - base_val) for v in sorted(set(round(float(v), 6) for v in end_vals))]
            else:
                circle_vals = [float(np.dot(np.array(p, dtype=float), axis)) for p in item.get("circle_centers", []) if p is not None]
                if len(circle_vals) >= 2:
                    points = [p0 + axis * (v - base_val) for v in sorted(set(round(float(v), 6) for v in circle_vals))]
                else:
                    return None
            return axis, points, float(radius)
        for item in sorted(self.topology_info.get("cylinder_info", {}).values(), key=lambda item: item.get("face_idx", 0)):
            if item.get("kind") != "pin":
                continue
            ret = _pin_end_points(item)
            if ret is None:
                continue
            axis, points, radius = ret
            for axis_key, (axis_ix, axis_vec) in axis_items.items():
                if abs(abs(float(np.dot(axis, axis_vec))) - 1) <= 1e-3:
                    for point in points:
                        _add(axis_key, point[axis_ix], point, {"kind": "pin_end", "subkind": item.get("kind"), "face_id": item.get("face_id"), "face_idx": item.get("face_idx"), "radius": radius, "diameter": radius * 2})
                    break
        def _view_axis_key(view, screen_axis):
            vec = np.array(view["R" if screen_axis == "x" else "U"], dtype=float)
            vec_len = np.linalg.norm(vec)
            if vec_len <= 1e-12:
                return None
            vec = vec / vec_len
            for axis_key, (axis_ix, axis_vec) in axis_items.items():
                dot = float(np.dot(vec, axis_vec))
                if abs(abs(dot) - 1) <= 1e-3:
                    return axis_key, axis_ix, 1 if dot >= 0 else -1
            return None
        for line in getattr(self, "center_line_items", []):
            view_name = line.get("view")
            view = self.view_data.get(view_name)
            if view is None:
                continue
            if line.get("ori") == "v":
                axis_ret = _view_axis_key(view, "x")
                if axis_ret is None:
                    continue
                axis_key, axis_ix, axis_sign = axis_ret
                value = (float(line["p1"][0]) - float(self.proj_offset[view_name][0])) * axis_sign
            elif line.get("ori") == "h":
                axis_ret = _view_axis_key(view, "y")
                if axis_ret is None:
                    continue
                axis_key, axis_ix, axis_sign = axis_ret
                value = (float(line["p1"][1]) - float(self.proj_offset[view_name][1])) * axis_sign
            else:
                continue
            point = np.array([0, 0, 0], dtype=float)
            point[axis_ix] = value
            _add(axis_key, value, point, {"kind": "center_line", "view": view_name, "ori": line.get("ori")})
        for axis_key in dim_data_linear:
            dim_data_linear[axis_key] = sorted(dim_data_linear[axis_key], key=lambda item: item["value"])
        self.dim_data_linear = dim_data_linear
        self.dim_data_plane = dim_data_linear
        return dim_data_linear
    def proc_prepare_A3_paper(self, spacing=0.5):
        if self.view_data is None:
            raise ValueError("請先 proc_proj_stp_all_views")
        front_view = self.view_data["front"]
        right_view = self.view_data["right"]
        top_view = self.view_data["top"]
        need_w = float(front_view["width"]) * (1 + float(spacing)) + float(right_view["width"])
        need_h = float(front_view["height"]) * (1 + float(spacing)) + float(top_view["height"])
        options = []
        for scale_name in SCALE_OPTIONS:
            vals = str(scale_name).split("/")
            if len(vals) != 2:
                continue
            scale_float = float(vals[0]) / float(vals[1])
            if scale_float <= 0:
                continue
            options.append({"name": scale_name, "float": scale_float})
        options = sorted(options, key=lambda item: item["float"], reverse=True)
        paper_w = float(SPACE_IN_PAPER[0])
        paper_h = float(SPACE_IN_PAPER[1])
        self.paper_info = {"paper": "A3", "space": [paper_w, paper_h], "need": [need_w, need_h], "spacing": spacing, "fit": False}
        for item in options:
            space_w = paper_w / item["float"]
            space_h = paper_h / item["float"]
            if need_w <= space_w and need_h <= space_h:
                self.scale = {"name": item["name"], "float": item["float"]}
                self.paper_info.update({"fit": True, "scale": self.scale, "space_in_model": [space_w, space_h], "use_in_paper": [need_w * item["float"], need_h * item["float"]]})
                return self.scale
        raise ValueError("SCALE_OPTIONS 沒有可容納目前視圖的比例")
    def proc_auto_dim(self, gap=10, view_names=None, text_height=3, tick=1.8, layer="DIM", text_layer="DIM", precision=2):
        msp = self.doc.modelspace()
        for ent in list(msp):
            if getattr(ent.dxf, "layer", None) in (layer, text_layer):
                msp.delete_entity(ent)
        target_names = set(view_names) if view_names is not None else None
        fmt = f"{{:.{precision}f}}"
        scale = float(getattr(self, "scale", {}).get("float", 1))
        if scale <= 0:  scale = 1
        text_height = 3.0 / scale
        dim_override = {"dimtxt": text_height, "dimasz": tick, "dimexe": max(tick, text_height * 0.45), "dimexo": max(tick * 0.35, 0.4)}
        axis_items = {"dx": (0, np.array([1, 0, 0], dtype=float)), "dy": (1, np.array([0, 1, 0], dtype=float)), "dz": (2, np.array([0, 0, 1], dtype=float))}
        def _fmt(val):
            return fmt.format(float(val)).rstrip("0").rstrip(".")
        def _view_box(view_name):
            view = self.view_data[view_name]
            return float(view["bb"].xmin + view["dx"]), float(view["bb"].xmax + view["dx"]), float(view["bb"].ymin + view["dy"]), float(view["bb"].ymax + view["dy"])
        def _view_axis(view, screen_axis):
            vec = np.array(view["R" if screen_axis == "x" else "U"], dtype=float)
            vec_len = np.linalg.norm(vec)
            if vec_len <= 1e-12:
                return None
            vec = vec / vec_len
            for axis_key, (axis_ix, axis_vec) in axis_items.items():
                dot = float(np.dot(vec, axis_vec))
                if abs(abs(dot) - 1) <= 1e-3:
                    return axis_key, axis_ix, 1 if dot >= 0 else -1
            return None
        def _layer0_lines(view_name):
            vxmin, vxmax, vymin, vymax = _view_box(view_name)
            ret = []
            for ent in msp:
                if str(getattr(ent.dxf, "layer", "")).upper() not in ("0", "AUTO_CEN"):
                    continue
                typ = ent.dxftype()
                segments = []
                if typ == "LINE":
                    segments.append((ent.dxf.start, ent.dxf.end))
                elif typ == "LWPOLYLINE":
                    pts = [(p[0], p[1]) for p in ent.get_points("xy")]
                    for ix in range(1, len(pts)):
                        segments.append((pts[ix - 1], pts[ix]))
                    if ent.closed and len(pts) >= 2:
                        segments.append((pts[-1], pts[0]))
                elif typ == "POLYLINE":
                    pts = [(p.dxf.location.x, p.dxf.location.y) for p in ent.vertices]
                    for ix in range(1, len(pts)):
                        segments.append((pts[ix - 1], pts[ix]))
                    if ent.is_closed and len(pts) >= 2:
                        segments.append((pts[-1], pts[0]))
                for p1, p2 in segments:
                    p1 = np.array([float(p1[0]), float(p1[1])], dtype=float)
                    p2 = np.array([float(p2[0]), float(p2[1])], dtype=float)
                    if max(p1[0], p2[0]) < vxmin - 1e-4 or min(p1[0], p2[0]) > vxmax + 1e-4 or max(p1[1], p2[1]) < vymin - 1e-4 or min(p1[1], p2[1]) > vymax + 1e-4:
                        continue
                    ret.append({"p1": p1, "p2": p2})
            return ret
        def _match_line_point(lines, screen_axis, target, tol=0.03):
            coord_ix = 0 if screen_axis == "x" else 1
            other_ix = 1 - coord_ix
            pts = []
            for line in lines:
                p1 = line["p1"]
                p2 = line["p2"]
                if abs(p1[coord_ix] - target) <= tol and abs(p2[coord_ix] - target) <= tol:
                    pts += [p1, p2]
            if not pts:
                for line in lines:
                    for p in (line["p1"], line["p2"]):
                        if abs(p[coord_ix] - target) <= tol:
                            pts.append(p)
            if not pts:
                for line in lines:
                    p1 = line["p1"]
                    p2 = line["p2"]
                    v = p2 - p1
                    if abs(v[coord_ix]) <= 1e-9:
                        continue
                    t = (target - p1[coord_ix]) / v[coord_ix]
                    if -1e-9 <= t <= 1 + 1e-9:
                        pts.append(p1 + v * t)
            if not pts:
                return None
            p = min(pts, key=lambda p: p[other_ix])
            if screen_axis == "x":
                return (float(target), float(p[1]))
            return (float(p[0]), float(target))
        dim_items = []
        view_stack = {name: {"x": 0, "y": 0} for name in self.view_data}
        marked_axis_keys = set()
        def _draw_linear_view(view_name, allow_axis_keys):
            view = self.view_data.get(view_name)
            if view is None or view.get("is_iso"):
                return
            if target_names is not None and view_name not in target_names:
                return
            vxmin, vxmax, vymin, vymax = _view_box(view_name)
            lines = _layer0_lines(view_name)
            if not lines:
                return
            start_p1 = (vxmin, vymin)
            for screen_axis in ("x", "y"):
                axis_ret = _view_axis(view, screen_axis)
                if axis_ret is None:
                    continue
                axis_key, axis_ix, axis_sign = axis_ret
                if axis_key not in allow_axis_keys:
                    continue
                data = self.dim_data_linear.get(axis_key, [])
                if len(data) < 2:
                    continue
                draw_items = []
                used_values = set()
                for item in data:
                    screen_ix = 0 if screen_axis == "x" else 1
                    target = axis_sign * float(item["value"]) + float(self.proj_offset[view_name][screen_ix])
                    if screen_axis == "x":
                        dim_value = abs(target - start_p1[0])
                    else:
                        dim_value = abs(target - start_p1[1])
                    if dim_value <= 1e-5:
                        continue
                    key = round(dim_value, precision)
                    if key in used_values:
                        continue
                    start_p2 = _match_line_point(lines, screen_axis, target)
                    if start_p2 is None:
                        continue
                    used_values.add(key)
                    draw_items.append({"p1": start_p1, "p2": start_p2, "value": dim_value, "axis": axis_key, "screen_axis": screen_axis, "source": item})
                for draw_item in sorted(draw_items, key=lambda item: item["value"]):
                    if draw_item["screen_axis"] == "x":
                        st = view_stack[view_name]["x"]
                        view_stack[view_name]["x"] += 1
                        base = (draw_item["p1"][0], vymin - gap * (st + 1))
                        angle = 0
                    else:
                        st = view_stack[view_name]["y"]
                        view_stack[view_name]["y"] += 1
                        base = (vxmin - gap * (st + 1), draw_item["p1"][1])
                        angle = 90
                    dim = msp.add_linear_dim(base=base, p1=draw_item["p1"], p2=draw_item["p2"], angle=angle, text=_fmt(draw_item["value"]), dimstyle="Standard", override=dim_override, dxfattribs={"layer": layer})
                    dim.render()
                    dim_items.append({"kind": "linear", "view": view_name, "axis": draw_item["axis"], "value": draw_item["value"], "source_kind": draw_item["source"].get("kind"), "face_id": draw_item["source"].get("face_id"), "p1": draw_item["p1"], "p2": draw_item["p2"]})
                    marked_axis_keys.add(draw_item["axis"])
        front_view = self.view_data.get("front")
        if front_view is not None:
            front_axis_keys = set()
            for screen_axis in ("x", "y"):
                axis_ret = _view_axis(front_view, screen_axis)
                if axis_ret is not None:
                    front_axis_keys.add(axis_ret[0])
            _draw_linear_view("front", front_axis_keys)
        remain_axis_keys = set(axis_items) - marked_axis_keys
        _draw_linear_view("right", remain_axis_keys)
        self.dim_2d_items = dim_items
        return dim_items
    def proc_auto_circle_dim(self,):
        msp = self.doc.modelspace()
        for ent in getattr(self, "circle_dim_entities", []):
            try:
                msp.delete_entity(ent)
            except:
                pass
        scale = float(getattr(self, "scale", {}).get("float", 1))
        if scale <= 0:  scale = 1
        text_height = 3 / scale
        gap = 10 / scale
        dim_override = {"dimtxt": text_height, "dimasz": max(1.8 / scale, text_height * 0.6), "dimexe": max(1.8 / scale, text_height * 0.45), "dimexo": max(0.6 / scale, 0.2)}
        eps = 1e-5
        bb = self.model.val().BoundingBox() if self.model is not None else None
        def _fmt_num(val):
            if val is None:
                return ""
            val = float(val)
            if abs(val - round(val)) <= 1e-6:
                return str(int(round(val)))
            return f"{val:.2f}".rstrip("0").rstrip(".")
        def _fmt_int(val):
            if val is None:
                return ""
            return str(int(round(float(val))))
        def _thread_item(diameter):
            match_name = None
            match_item = None
            match_diff = None
            for size_name, size_item in THREAD_SIZE_ITEMS.items():
                diff = abs(float(diameter) - float(size_item["minor_d"]))
                if match_diff is None or diff < match_diff:
                    match_name = size_name
                    match_item = size_item
                    match_diff = diff
            if match_item is not None and match_diff <= max(0.03, float(match_item.get("pitch", 0)) * 0.08):
                return match_name, match_item
            return None, None
        def _is_full(axis, depth):
            if bb is None or depth is None:
                return False
            xs = (bb.xmin, bb.xmax)
            ys = (bb.ymin, bb.ymax)
            zs = (bb.zmin, bb.zmax)
            vals = []
            for x in xs:
                for y in ys:
                    for z in zs:
                        vals.append(float(np.dot(np.array([x, y, z], dtype=float), axis)))
            return float(depth) >= max(vals) - min(vals) - 1e-3
        def _note_suffix(kind, axis, depth):
            if kind == "pin":
                return "h=" + _fmt_int(depth)
            if _is_full(axis, depth):
                return "full"
            return "depth=" + _fmt_int(depth)
        def _view_box(view_name):
            view = self.view_data[view_name]
            return float(view["bb"].xmin + view["dx"]), float(view["bb"].xmax + view["dx"]), float(view["bb"].ymin + view["dy"]), float(view["bb"].ymax + view["dy"])
        circle_dim_items = []
        circle_dim_entities = []
        for view_name, view in self.view_data.items():
            if view.get("is_iso"):
                continue
            proj_matrix = self.proj_matrix.get(view_name)
            proj_offset = self.proj_offset.get(view_name)
            if proj_matrix is None or proj_offset is None:
                continue
            visible_items = []
            for item in sorted(self.topology_info.get("cylinder_info", {}).values(), key=lambda item: item.get("face_idx", 0)):
                if item.get("kind") not in ("hole", "pin") or item.get("diameter") is None:
                    continue
                axis = item.get("axis_dir")
                p0 = item.get("surface_point")
                radius = item.get("radius")
                end_vals = [v for v in [end.get("axis_val") for end in item.get("end_planes", [])] if v is not None]
                if axis is None or p0 is None or radius is None or len(end_vals) < 2:
                    continue
                axis = np.array(axis, dtype=float)
                axis_len = np.linalg.norm(axis)
                if axis_len <= 1e-12:
                    continue
                axis = axis / axis_len
                axis2 = proj_matrix @ axis
                if np.linalg.norm(axis2) > eps:
                    continue
                p0 = np.array(p0, dtype=float)
                base_val = float(np.dot(p0, axis))
                c1 = p0 + axis * (min(end_vals) - base_val)
                c2 = p0 + axis * (max(end_vals) - base_val)
                center2 = proj_matrix @ ((c1 + c2) / 2) + proj_offset
                diameter = float(item["diameter"])
                thread_name, thread_item = _thread_item(diameter) if item.get("kind") == "hole" else (None, None)
                if thread_item is not None:
                    kind = "thread"
                    dim_dia = float(thread_item["major_d"])
                    text_key = (kind, thread_name, _fmt_num(thread_item["pitch"]), "full" if _is_full(axis, item.get("depth")) else _fmt_num(item.get("depth")))
                else:
                    kind = item.get("kind")
                    dim_dia = diameter
                    text_key = (kind, round(dim_dia, 4), "full" if kind != "pin" and _is_full(axis, item.get("depth")) else _fmt_num(item.get("depth")))
                visible_items.append({"item": item, "item_kind": item.get("kind"), "face_id": item.get("face_id"), "face_idx": item.get("face_idx"), "kind": kind, "thread": thread_name, "thread_item": thread_item, "diameter": dim_dia, "real_diameter": diameter, "axis": axis, "depth": item.get("depth"), "text_key": text_key, "center": (float(center2[0]), float(center2[1])), "radius": float(dim_dia) / 2})
            if not visible_items:
                continue
            vxmin, vxmax, vymin, vymax = _view_box(view_name)
            groups = {}
            for item in visible_items:
                text_key = item["text_key"]
                groups.setdefault(text_key, {"kind": item["kind"], "thread": item["thread"], "thread_item": item["thread_item"], "diameter": item["diameter"], "axis": item["axis"], "depth": item["depth"], "items": []})
                groups[text_key]["items"].append({"center": item["center"], "radius": item["radius"], "face_id": item["face_id"], "face_idx": item["face_idx"]})
            for ix, group in enumerate(sorted(groups.values(), key=lambda item: (item["kind"], item["diameter"], len(item["items"])))):
                rep = sorted(group["items"], key=lambda item: (item["center"][1], item["center"][0]))[0]
                cx, cy = rep["center"]
                radius = rep["radius"]
                prefix = f"{len(group['items'])}-" if len(group["items"]) > 1 else ""
                suffix = _note_suffix(group["kind"], group["axis"], group["depth"])
                text_pt = (vxmax + gap * 0.8, vymax - gap * (ix + 1))
                if group["kind"] == "thread":
                    text = f"{prefix}{group['thread']}X{_fmt_num(group['thread_item']['pitch'])},{suffix}"
                    start = np.array([cx, cy], dtype=float)
                    view_center = np.array([(vxmin + vxmax) / 2, (vymin + vymax) / 2], dtype=float)
                    away = start - view_center
                    sign_x = 1 if away[0] >= 0 else -1
                    sign_y = 1 if away[1] >= 0 else -1
                    probe_bbox = self.get_dim_words_bbox(text, (0, 0), text_height)
                    hor_len = max(gap * 1.5, probe_bbox["width"] + gap * 0.8)
                    elbow = start + np.array([sign_x * gap, sign_y * gap], dtype=float)
                    end = elbow + np.array([sign_x * hor_len, 0], dtype=float)
                    text_center = ((elbow[0] + end[0]) / 2, elbow[1] + text_height * 0.8)
                    text_bbox = self.get_dim_words_bbox(text, text_center, text_height)
                    leader = msp.add_leader([tuple(start), tuple(elbow), tuple(end)], dxfattribs={"layer": "DIM"})
                    txt = msp.add_text(text, height=text_height, dxfattribs={"layer": "DIM"})
                    txt.set_placement(text_bbox["insert"])
                    circle_dim_entities += [leader, txt]
                    circle_dim_items.append({"kind": group["kind"], "view": view_name, "text": text, "count": len(group["items"]), "bbox": text_bbox, "items": group["items"]})
                    continue
                text = f"{prefix}%%c{_fmt_num(group['diameter'])},{suffix}"
                dim = msp.add_diameter_dim(center=(cx, cy), radius=radius, angle=45, location=text_pt, text=text, dimstyle="Standard", override=dim_override, dxfattribs={"layer": "DIM"})
                dim.render()
                circle_dim_entities.append(dim.dimension)
                circle_dim_items.append({"kind": group["kind"], "view": view_name, "text": text, "count": len(group["items"]), "items": group["items"]})
        self.circle_dim_entities = circle_dim_entities
        self.circle_dim_items = circle_dim_items
        return circle_dim_items
    def get_dim_words_bbox(self, text, center, height):
        center = np.array(center, dtype=float)
        height = float(height)
        text = str(text)
        show_text = text.replace("%%c", "D")
        width = max(len(show_text), 1) * height * 0.62
        xmin = float(center[0] - width / 2)
        xmax = float(center[0] + width / 2)
        ymin = float(center[1] - height / 2)
        ymax = float(center[1] + height / 2)
        return {"xmin": xmin, "xmax": xmax, "ymin": ymin, "ymax": ymax, "width": width, "height": height, "center": (float(center[0]), float(center[1])), "insert": (xmin, ymin)}
    def proc_auto_chamfer_dim(self,):
        msp = self.doc.modelspace()
        for ent in getattr(self, "chamfer_dim_entities", []):
            try:   msp.delete_entity(ent)
            except:     pass
        scale = float(getattr(self, "scale", {}).get("float", 1))
        if scale <= 0:  scale = 1
        text_height = 3 / scale
        gap = 10 / scale
        tol = 0.03
        def _fmt_num(val):
            val = float(val)
            if abs(val - round(val)) <= 1e-6:
                return str(int(round(val)))
            return f"{val:.2f}".rstrip("0").rstrip(".")
        def _view_box(view_name):
            view = self.view_data[view_name]
            return float(view["bb"].xmin + view["dx"]), float(view["bb"].xmax + view["dx"]), float(view["bb"].ymin + view["dy"]), float(view["bb"].ymax + view["dy"])
        def _line_segments():
            for ent in msp:
                if str(getattr(ent.dxf, "layer", "")).upper() != "0":
                    continue
                typ = ent.dxftype()
                if typ == "LINE":
                    yield np.array([float(ent.dxf.start[0]), float(ent.dxf.start[1])], dtype=float), np.array([float(ent.dxf.end[0]), float(ent.dxf.end[1])], dtype=float)
                elif typ == "LWPOLYLINE":
                    pts = [np.array([float(p[0]), float(p[1])], dtype=float) for p in ent.get_points("xy")]
                    for ix in range(1, len(pts)):
                        yield pts[ix - 1], pts[ix]
                    if ent.closed and len(pts) >= 2:
                        yield pts[-1], pts[0]
                elif typ == "POLYLINE":
                    pts = [np.array([float(p.dxf.location.x), float(p.dxf.location.y)], dtype=float) for p in ent.vertices]
                    for ix in range(1, len(pts)):
                        yield pts[ix - 1], pts[ix]
                    if ent.is_closed and len(pts) >= 2:
                        yield pts[-1], pts[0]
        chamfer_dim_items = []
        chamfer_dim_entities = []
        segments = list(_line_segments())
        for view_name, view in self.view_data.items():
            if view.get("is_iso"):  continue
            vxmin, vxmax, vymin, vymax = _view_box(view_name)
            groups = {}
            for p1, p2 in segments:
                mid = (p1 + p2) / 2
                if mid[0] < vxmin - tol or mid[0] > vxmax + tol or mid[1] < vymin - tol or mid[1] > vymax + tol:
                    continue
                dx = abs(float(p2[0] - p1[0]))
                dy = abs(float(p2[1] - p1[1]))
                if dx <= tol or dy <= tol:
                    continue
                if abs(dx - dy) > tol:
                    continue
                chamfer = (dx + dy) / 2
                key = round(chamfer, 3)
                groups.setdefault(key, {"value": chamfer, "items": []})
                groups[key]["items"].append({"p1": tuple(p1), "p2": tuple(p2), "mid": tuple(mid)})
            view_center = np.array([(vxmin + vxmax) / 2, (vymin + vymax) / 2], dtype=float)
            group_items = sorted(groups.values(), key=lambda item: item["value"])
            for ix, group in enumerate(group_items):
                rep = sorted(group["items"], key=lambda item: (item["mid"][1], item["mid"][0]))[0]
                text = f"{len(group['items'])}-D{_fmt_num(group['value'])}" if len(group["items"]) > 1 else f"D{_fmt_num(group['value'])}"
                start = np.array(rep["mid"], dtype=float)
                p1 = np.array(rep["p1"], dtype=float)
                p2 = np.array(rep["p2"], dtype=float)
                v = p2 - p1
                n = np.array([-v[1], v[0]], dtype=float)
                n_len = np.linalg.norm(n)
                if n_len <= 1e-12:
                    n = np.array([0, 1], dtype=float)
                else:
                    n = n / n_len
                away = start - view_center
                if np.linalg.norm(away) > 1e-12 and float(np.dot(n, away)) < 0:
                    n = -n
                sign_x = 1 if n[0] >= 0 else -1
                if abs(n[0]) <= 1e-9:
                    sign_x = 1 if start[0] >= view_center[0] else -1
                probe_bbox = self.get_dim_words_bbox(text, (0, 0), text_height)
                hor_len = max(gap * 1.5, probe_bbox["width"] + gap * 0.8)
                elbow = start + n * gap
                end = elbow + np.array([sign_x * hor_len, 0], dtype=float)
                text_center = ((elbow[0] + end[0]) / 2, elbow[1] + text_height * 0.8)
                text_bbox = self.get_dim_words_bbox(text, text_center, text_height)
                leader = msp.add_leader([tuple(start), tuple(elbow), tuple(end)], dxfattribs={"layer": "DIM"})
                txt = msp.add_text(text, height=text_height, dxfattribs={"layer": "DIM"})
                txt.set_placement(text_bbox["insert"])
                chamfer_dim_entities += [leader, txt]
                chamfer_dim_items.append({"view": view_name, "text": text, "value": group["value"], "count": len(group["items"]), "bbox": text_bbox, "items": group["items"]})
        self.chamfer_dim_entities = chamfer_dim_entities
        self.chamfer_dim_items = chamfer_dim_items
        return chamfer_dim_items
    def proc_thread_arc(self,):
        if self.doc is None or self.view_data is None or self.proj_matrix is None or self.proj_offset is None:
            raise ValueError("請先 proc_proj_stp_all_views")
        if self.topology_info is None or "cylinder_info" not in self.topology_info:
            raise ValueError("請先 proc_gather_cylinder")
        msp = self.doc.modelspace()
        for ent in getattr(self, "thread_arc_entities", []):
            try:
                msp.delete_entity(ent)
            except:
                pass
        faces = self.topology_info.get("faces", {})
        view_names = ("top", "left", "front", "right", "bottom")
        angle1, angle2 = [float(v) for v in THREAD_ARC_ANGLE]
        thread_arc_items = []
        thread_arc_entities = []
        draw_keys = set()
        for cyn in sorted(self.topology_info.get("cylinder_info", {}).values(), key=lambda item: item.get("face_idx", 0)):
            if cyn.get("kind") != "hole" or cyn.get("diameter") is None:
                continue
            diameter = float(cyn["diameter"])
            match_size = None
            match_item = None
            match_diff = None
            for size_name, size_item in THREAD_SIZE_ITEMS.items():
                diff = abs(diameter - float(size_item["minor_d"]))
                if match_diff is None or diff < match_diff:
                    match_size = size_name
                    match_item = size_item
                    match_diff = diff
            if match_item is None or match_diff > max(0.03, float(match_item.get("pitch", 0)) * 0.08):
                continue
            axis = cyn.get("axis_dir")
            p0 = cyn.get("surface_point")
            if axis is None or p0 is None:
                continue
            axis = np.array(axis, dtype=float)
            axis_len = np.linalg.norm(axis)
            if axis_len <= 1e-12:
                continue
            axis = axis / axis_len
            p0 = np.array(p0, dtype=float)
            end_planes = cyn.get("end_planes", [])
            open_end_planes = []
            for end_plane in end_planes:
                face = faces.get(end_plane.get("face_id"), {})
                if len(face.get("bounds", [])) >= 2:
                    open_end_planes.append(end_plane)
            if not open_end_planes:
                open_end_planes = end_planes
            base_val = float(np.dot(p0, axis))
            arc_radius = float(match_item.get("major_d", diameter)) / 2
            for end_plane in open_end_planes:
                if end_plane.get("axis_val") is None:
                    continue
                center3 = p0 + axis * (float(end_plane["axis_val"]) - base_val)
                end_normal = None
                if end_plane.get("normal") is not None:
                    normal = np.array(end_plane["normal"], dtype=float)
                    normal_len = np.linalg.norm(normal)
                    if normal_len > 1e-12:
                        end_normal = normal / normal_len
                        if faces.get(end_plane.get("face_id"), {}).get("same_sense") is False:
                            end_normal = -end_normal
                view_items = []
                for view_name in view_names:
                    view = self.view_data.get(view_name)
                    if view is None or view.get("is_iso"):
                        continue
                    view_n = np.array(view["N"], dtype=float)
                    view_n_len = np.linalg.norm(view_n)
                    if view_n_len <= 1e-12:
                        continue
                    view_n = view_n / view_n_len
                    if abs(abs(float(np.dot(axis, view_n))) - 1) > 1e-3:
                        continue
                    if end_normal is not None and float(np.dot(end_normal, view_n)) >= 1 - 1e-3:
                        view_items.append((view_name, view))
                if not view_items:
                    for view_name in view_names:
                        view = self.view_data.get(view_name)
                        if view is None or view.get("is_iso"):
                            continue
                        view_n = np.array(view["N"], dtype=float)
                        view_n_len = np.linalg.norm(view_n)
                        if view_n_len <= 1e-12:
                            continue
                        view_n = view_n / view_n_len
                        if abs(abs(float(np.dot(axis, view_n))) - 1) <= 1e-3:
                            view_items.append((view_name, view))
                for view_name, view in view_items:
                    proj_matrix = self.proj_matrix.get(view_name)
                    proj_offset = self.proj_offset.get(view_name)
                    if proj_matrix is None or proj_offset is None:
                        continue
                    center2 = proj_matrix @ center3 + proj_offset
                    cx, cy = float(center2[0]), float(center2[1])
                    key = (view_name, round(cx, 4), round(cy, 4), round(arc_radius, 4), match_size)
                    if key in draw_keys:
                        continue
                    draw_keys.add(key)
                    ent = msp.add_arc((cx, cy), arc_radius, angle1, angle2, dxfattribs={"layer": "SUP"})
                    thread_arc_entities.append(ent)
                    thread_arc_items.append({"view": view_name, "face_id": cyn.get("face_id"), "face_idx": cyn.get("face_idx"), "thread": match_size, "diameter": diameter, "thread_diameter": arc_radius * 2, "center": (cx, cy), "radius": arc_radius, "angles": (angle1, angle2)})
        self.thread_arc_entities = thread_arc_entities
        self.thread_arc_items = thread_arc_items
        return thread_arc_items
    def get_dxf(self,):
        return self.doc
    def add_dxf(self, dxf=None, offset=[0, 0]):
        if self.doc is None:
            self._init_dxf_document()
        if dxf is None:
            return 0
        if isinstance(dxf, STP_Helper):
            dxf = dxf.get_dxf()
        if hasattr(dxf, "document"):
            dxf = dxf.document
        dx = float(offset[0])
        dy = float(offset[1])
        count = 0
        msp = self.doc.modelspace()
        for ent in list(dxf.modelspace()):
            try:
                new_ent = ent.copy()
                if dx or dy:
                    new_ent.translate(dx, dy, 0)
                msp.add_entity(new_ent)
                count += 1
            except:
                pass
        return count
    def proc_line_ratio(self,):
        if self.doc is None:
            raise ValueError("請先建立 dxf")
        def _length(ent):
            typ = ent.dxftype()
            if typ == "LINE":
                p1 = np.array([float(ent.dxf.start[0]), float(ent.dxf.start[1])], dtype=float)
                p2 = np.array([float(ent.dxf.end[0]), float(ent.dxf.end[1])], dtype=float)
                return float(np.linalg.norm(p2 - p1))
            if typ == "ARC":
                angle = (float(ent.dxf.end_angle) - float(ent.dxf.start_angle)) % 360
                return float(abs(np.radians(angle) * float(ent.dxf.radius)))
            if typ == "CIRCLE":
                return float(abs(2 * np.pi * float(ent.dxf.radius)))
            if typ == "LWPOLYLINE":
                pts = [np.array([float(p[0]), float(p[1])], dtype=float) for p in ent.get_points("xy")]
                total = 0.0
                for ix in range(1, len(pts)):
                    total += float(np.linalg.norm(pts[ix] - pts[ix - 1]))
                if ent.closed and len(pts) >= 2:
                    total += float(np.linalg.norm(pts[0] - pts[-1]))
                return total
            if typ == "POLYLINE":
                pts = [np.array([float(p.dxf.location.x), float(p.dxf.location.y)], dtype=float) for p in ent.vertices]
                total = 0.0
                for ix in range(1, len(pts)):
                    total += float(np.linalg.norm(pts[ix] - pts[ix - 1]))
                if ent.is_closed and len(pts) >= 2:
                    total += float(np.linalg.norm(pts[0] - pts[-1]))
                return total
            return None
        line_ratio_items = []
        for ent in self.doc.modelspace():
            layer = str(getattr(ent.dxf, "layer", ""))
            if layer not in LINE_RATIO_GAMMA:
                continue
            line_length = _length(ent)
            if line_length is None or line_length <= 1e-9:
                continue
            ltscale = line_length ** 2 * float(LINE_RATIO_GAMMA[layer])
            try:
                ent.dxf.ltscale = ltscale
            except:
                continue
            line_ratio_items.append({"layer": layer, "type": ent.dxftype(), "length": line_length, "ltscale": ltscale})
        self.line_ratio_items = line_ratio_items
        return line_ratio_items
    
if __name__ == "__main__":
    output = STP_Helper()
    output._init_dxf_document()
    offset_x = 0
    output_items = []
    for i in range(13, 16):
        stp_path = Path(f"./stp_files_0613/part{i:03d}.stp")
        hpr = STP_Helper()
        hpr.load(stp_path)
        hpr.proc_proj_stp_all_views()
        hpr.proc_prepare_A3_paper()
        hpr.proc_fix_edges()
        hpr.proc_parse_stp()
        hpr.proc_gather_cylinder()
        hpr.debug_cylinder_bbox()
        hpr.proc_center_lines()
        hpr.proc_gather_linear_dim()
        hpr.proc_auto_dim()
        hpr.proc_auto_circle_dim()
        hpr.proc_auto_chamfer_dim()
        hpr.proc_thread_arc()
        hpr.proc_line_ratio()
        add_count = output.add_dxf(hpr.get_dxf(), [offset_x, 0])
        output_items.append({"stp_path": str(stp_path), "offset": offset_x, "scale": hpr.scale, "count": add_count})
        offset_x += float(hpr.paper_info["space_in_model"][0]) + 350
        print("ok", stp_path, hpr.scale, add_count, hpr.ct_info)
    save_path = "./output.dxf"
    output.get_dxf().saveas(save_path)
    print("ok", save_path, len(output.get_dxf().modelspace()), output_items)
    open_folder(save_path)
