def proc_center_lines(self,):
    for cyn_info in 剛剛整理出來的圓柱
        如果能用投影就投影
        
        cond = 圓柱投影下去有兩個視角, 一個看起來是圓,一個看起來是rect
        if 投影下去是圓 : 
            加入 add_line([cx-r-extend, cy], [cx+r+extend, cy], layer="AUTO_CEN")
            加入 add_line([cx, cy-r-extend], [cx, cy+r+extend], layer="AUTO_CEN")
        elif    投影下去是rect :  
            if 是水平還是垂直
                add_line([x_min-extend, cy], [x_max+extend, cy], layer="AUTO_CEN")
            or 
                add_line([cx, y_min-extend], [cx, y_max+extend], layer="AUTO_CEN")
    全部標註後, 中心線應該會散在每個view, 現在來合併與去重
    for this_view in views
        lines = 抓出 layer "AUTO_CEN" 的線
        for this_unique_x in 端點
            min_, max_ = 抓 所有端點的 y 範圍
            刪除 this_unique_x 上的所有中心線
            然後加入 min_ -> max_ 的中心線
        # 一樣地套用在水平線
        for this_unique_y in 端點
            ...
    def proc_gather_linear_dim(self, ):
        self.dim_data_linear = {"dx":[], "dy":[], "dz":[], }
        for this_plane in all planes
            if not   "廣義垂直水平" : 跳過
            
            檢查是哪個方向的法向量
            new_dim = 座標原點到法向量的距離
            依據方向 放入 self.dim_data_linear
        for cyn in 之前找出來的圓柱資訊
            如果是 凸pin 才蒐集
            找出凸pin端面的的分量存到 self.dim_data_linear
        for 每條中心線
            把中心線的距離也加入, 例如正面視圖有一條垂直中心線, 我們會標註左邊界到中心線的dx
        self.dim_data_linear 在蒐集的時候要確保 unique (tor=0.01mm)
        
        
        
    def proc_auto_dim(self, gap=10):
        找出正面視圖的 xy 與 原本 3d 坐標軸關係
        從 self.dim_data_linear 找兩個分量符合正視圖
        items = []
        start_p1 = 正面視圖的左下角
        for val in self.dim_data_linear[分量1]:
            lines = 抓 dxf layer="0"裡面的直線
            確認 lines 在 正面視圖
            start_p2 = 計算 min(端點y in this_dx)
            dim_value = 這個尺寸多長
            items.append([start_p1, start_p2, dim_value])
        items = []
        start_p1 = 正面視圖的左下角
        for val in self.dim_data_linear[分量2]:
            lines = 抓 dxf layer="0"裡面的直線
            確認 lines 在 正面視圖
            start_p2 = 計算 min(端點x in this_dy)
            dim_value = 這個尺寸多長
            items.append([start_p1, start_p2, dim_value])
            
        基於 dim_value 排序尺寸列表
        從最小到最大尺寸開始漸漸往外拉出,  文字放的位置基於 參數gap
        
        
        --------------------------------------------------
        現在切換到右側視圖, 現在self.dim_data_plane 只有一個分量還沒標註
        把那個分量找出來
        items = []
        start_p1 = 右側視圖的左下角
        for val in self.dim_data_plane[分量2]:
            lines = 抓 dxf layer="0"裡面的直線
            確認 lines 在 右側視圖
            start_p2 = 計算 min(端點x in this_dy) or 計算 min(端點y in this_dx)
            dim_value = 這個尺寸多長
            items.append([start_p1, start_p2, dim_value])
        基於 dim_value 排序尺寸列表
        從最小到最大尺寸開始漸漸往外拉出,  文字放的位置基於 參數gap
        
        
def proc_gather_linear_dim(self,):
    ...原本的內容
    -------------------
    最後面新增以下
    
    
    

    def proc_prepare_A3_paper(self, spacing=0.5):
        need_w = front_view_w * (1+spacing) + right_view_w
        need_h = front_view_h * (1+spacing) + up_view_h
        for this_scale_name in options # scale value 由大到小
            this_scale_val = convert to float(this_scale_name)
            space_w = SPACE_IN_PAPER[0] * this_scale_val
            space_h = SPACE_IN_PAPER[1] * this_scale_val
            if w, h 都足夠 : 
                紀錄可以的 name
                stop







    def proc_auto_circle_dim(self,):
        先抓出 self.topology_info["cylinder_info"]
        
        for this_view in all views
            先抓出 this_view的坐標系可以看到哪幾個 self.topology_info["cylinder_info"] 剛好顯示成為圓型
            
            根據直徑分類 -> 哪幾個 unique, 每個unique有幾個重複
            
            先確認三種情況 : "hole", "pin", "thread"
            
            if "thread":
                加入 引線 標註 
                -> 文字 : 如果是螺紋 f"{幾個}-{M幾}X{pitch},depth={int}", 或是 f"{幾個}-{M幾}X{pitch},full"
            
            elif "hole":
                加入 直徑 標註 
                -> 文字 : 如果是普通圓孔 f"{幾個}-{直徑符號}{尺寸數值},depth={int}", 或是 f"{幾個}-{直徑符號}{尺寸數值},full"
            elif "pin":
                加入 直徑 標註 
                -> 文字 : 如果是凸pin f"{幾個}-{直徑符號}{尺寸數值},h={int}"


            -> 文字 : 如果只有一個就不需要標註--> 幾個+"-"
            -> layer : "DIM", color=bylayer
            -> 字高 : 3 / scale

    def proc_auto_chamfer_dim(self,):
        for this_view in all views
            從 dxf 找直線, 如果存在 45度 斜直線
            
            for this_line in 45度直線:
                紀錄 p1 p2的dx 或是 dy (dx=dy 因為45度)
                記錄起來
            
            最後 unique 與統計
            加入引線標註
            -> f"{幾個}-D{dx}"
            
        











