from pathlib import Path
import re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.path import Path as MplPath
from matplotlib.patches import PathPatch
STP_FOLDER = Path("./stp_files_basic_hole")
SAVE_FOLDER = STP_FOLDER / "tree_view"
MAX_LEVEL = 12
COLOR_LEVEL = 8
def sort_key(path):
    nums = re.findall(r"\d+", path.stem)
    return int(nums[-1]) if nums else path.stem
def split_params(data):
    ret, buf = [], []
    layer, in_text, i = 0, False, 0
    while i < len(data):
        ch = data[i]
        if ch == "'":
            buf.append(ch)
            if i + 1 < len(data) and data[i + 1] == "'":
                buf.append(data[i + 1]); i += 2; continue
            in_text = not in_text
        elif not in_text and ch in "()":
            layer += 1 if ch == "(" else -1
            buf.append(ch)
        elif not in_text and ch == "," and layer == 0:
            ret.append("".join(buf).strip()); buf = []
        else:
            buf.append(ch)
        i += 1
    if buf: ret.append("".join(buf).strip())
    return ret
def parse_stp_entities(stp_path):
    txt_data = Path(stp_path).read_text(encoding="utf-8", errors="ignore")
    entities = {}
    for m in re.finditer(r"#(\d+)\s*=\s*(.*?);", txt_data, re.S):
        id_name = "#" + m.group(1)
        text = " ".join(m.group(2).split())
        f = re.match(r"([A-Z0-9_]+)\s*\((.*)\)$", text)
        func, items = (f.group(1), split_params(f.group(2))) if f else ("", [])
        entities[id_name] = {"id": id_name, "idx": int(m.group(1)), "func": func, "items": items, "refs": re.findall(r"#\d+", text), "text": text}
    return entities
def get_tree_relation(entities, id_name, max_level=20, _used=None):
    _used = set() if _used is None else set(_used)
    if id_name not in entities or id_name in _used or max_level <= 0:
        return {id_name: None}
    _used.add(id_name)
    refs = entities[id_name].get("refs", [])
    if not refs:
        return {id_name: None}
    data = {}
    for ref in refs:
        item = get_tree_relation(entities, ref, max_level - 1, _used)
        data[ref] = item.get(ref)
    return {id_name: data}
def draw_tree_view(data, entities=None, save_path=None, show=False, fig_size=None):
    entities = {} if entities is None else entities
    level_items, lines = {}, []
    def _walk(now, level=0, parent=None, color_id=None):
        for id_name, child in now.items():
            color_id = id_name if level == COLOR_LEVEL else color_id
            level_items.setdefault(level, [])
            if id_name not in level_items[level]: level_items[level].append(id_name)
            if parent is not None: lines.append((parent, (level, id_name), color_id))
            if isinstance(child, dict): _walk(child, level + 1, (level, id_name), color_id)
    _walk(data)
    if not level_items: return None
    max_level = max(level_items)
    order_items = {level: {id_name: ix for ix, id_name in enumerate(items)} for level, items in level_items.items()}
    for level in range(1, max_level + 1):
        parent_pos = {}
        for parent, child, color_id in lines:
            if child[0] == level:
                parent_pos.setdefault(child[1], []).append(order_items.get(parent[0], {}).get(parent[1], 0))
        old_order = order_items.get(level, {})
        level_items[level] = sorted(level_items.get(level, []), key=lambda id_name: (sum(parent_pos.get(id_name, [old_order.get(id_name, 0)])) / len(parent_pos.get(id_name, [1])), old_order.get(id_name, 0)))
        order_items[level] = {id_name: ix for ix, id_name in enumerate(level_items[level])}
    row_count = max(len(items) for items in level_items.values())
    fig_w = max(14, (max_level + 1) * 4.75) if fig_size is None else fig_size[0]
    fig_h = max(3, row_count * 0.2 + 1.4) if fig_size is None else fig_size[1]
    fig, ax = plt.subplots(figsize=(fig_w, fig_h), facecolor="#fbfbfc")
    ax.set_facecolor("#fbfbfc")
    ax.axis("off")
    y_top, y_bottom, col_w, func_dx, pos, rows, text_items = row_count, 1, 3.65, 1.25, {}, [], {}
    box_kw = {"facecolor": "white", "edgecolor": "#c6ccd4", "linewidth": 0.55, "boxstyle": "round,pad=0.16,rounding_size=0.04"}
    header_kw = {"facecolor": "#eef3f8", "edgecolor": "#aeb8c4", "linewidth": 0.6, "boxstyle": "round,pad=0.18,rounding_size=0.05"}
    func_names = sorted({entities.get(id_name, {}).get("func", "") for items in level_items.values() for id_name in items})
    cmap = plt.get_cmap("tab20")
    func_color = {}
    for ix, func in enumerate(func_names):
        r, g, b, a = cmap(ix % 20)
        func_color[func] = (0.72 + r * 0.28, 0.72 + g * 0.28, 0.72 + b * 0.28, 1)
    for level in range(max_level + 1):
        ax.text(level * col_w, y_top + 0.65, f"level{level + 1}", fontsize=8.5, weight="bold", bbox=header_kw, zorder=3)
        ax.text(level * col_w + func_dx, y_top + 0.65, "func", fontsize=8.5, weight="bold", bbox=header_kw, zorder=3)
        items = level_items.get(level, [])
        y_gap = (y_top - y_bottom) / (len(items) - 1) if len(items) > 1 else 0
        for ix, id_name in enumerate(items):
            x = level * col_w
            y = y_top - ix * y_gap if len(items) > 1 else (y_top + y_bottom) / 2
            func = entities.get(id_name, {}).get("func", "")
            this_box_kw = {**box_kw, "facecolor": func_color.get(func, "white")}
            pos[(level, id_name)] = (x, y)
            rows.append({"id": id_name, "func": func, "level": level, "y": y})
            t1 = ax.text(x, y, id_name, fontsize=7.8, va="center", color="#1f2933", bbox=this_box_kw, zorder=3)
            t2 = ax.text(x + func_dx, y, func, fontsize=7.8, va="center", color="#1f2933", bbox=this_box_kw, zorder=3)
            text_items[(level, id_name)] = (t1, t2)
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    level_func_right, item_box = {}, {}
    for key, texts in text_items.items():
        id_bb = texts[0].get_bbox_patch().get_window_extent(renderer)
        func_bb = texts[1].get_bbox_patch().get_window_extent(renderer)
        id_p0 = ax.transData.inverted().transform((id_bb.x0, id_bb.y0)); id_p1 = ax.transData.inverted().transform((id_bb.x1, id_bb.y1))
        func_p0 = ax.transData.inverted().transform((func_bb.x0, func_bb.y0)); func_p1 = ax.transData.inverted().transform((func_bb.x1, func_bb.y1))
        item_box[key] = {"id_xmin": id_p0[0], "id_xmax": id_p1[0], "func_xmin": func_p0[0], "func_xmax": func_p1[0], "ymin": min(id_p0[1], func_p0[1]), "ymax": max(id_p1[1], func_p1[1])}
        level_func_right[key[0]] = max(level_func_right.get(key[0], func_p1[0]), func_p1[0])
    color_ids = list(level_items.get(COLOR_LEVEL, []))
    color_map = {id_name: plt.get_cmap("tab20")(ix % 20) for ix, id_name in enumerate(color_ids)}
    for parent, child, color_id in lines:
        if parent not in pos or child not in pos: continue
        x1, y1 = pos[parent]; x2, y2 = pos[child]
        start_x = item_box.get(parent, {}).get("func_xmax", x1) + 0.1
        end_x = item_box.get(child, {}).get("id_xmin", x2) - 0.1
        mid_x = (start_x + end_x) / 2
        path = MplPath([(start_x, y1), (mid_x, y1), (mid_x, y2), (end_x, y2)], [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4])
        ax.add_patch(PathPatch(path, facecolor="none", edgecolor=color_map.get(color_id, "#b8c2cc"), linewidth=1.95, alpha=0.6, zorder=1))
    ax.set_xlim(-0.3, max((level_func_right.get(level, level * col_w) for level in range(max_level + 1)), default=0) + 0.5)
    ax.set_ylim(0, y_top + 1.0)
    if save_path is not None: fig.savefig(save_path, dpi=180, bbox_inches="tight")
    if show: plt.show()
    return fig, ax, rows
def main():
    SAVE_FOLDER.mkdir(parents=True, exist_ok=True)
    for stp_path in sorted(STP_FOLDER.glob("*.stp"), key=sort_key):
        entities = parse_stp_entities(stp_path)
        root_items = [item for item in entities.values() if item["refs"]]
        if not root_items:
            print("skip", stp_path.name, "no refs")
            continue
        root = max(root_items, key=lambda item: len(item["refs"]))
        data = get_tree_relation(entities, root["id"], max_level=MAX_LEVEL)
        save_path = SAVE_FOLDER / f"{stp_path.stem}_{root['id'].replace('#', 'id')}.png"
        fig, ax, rows = draw_tree_view(data, entities, save_path=save_path)
        plt.close(fig)
        print("ok", stp_path.name, root["id"], root["func"], "rows", len(rows), save_path)
if __name__ == "__main__": main()
