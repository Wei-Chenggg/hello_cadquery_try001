from pathlib import Path
import re
import cadquery as cq
from cadquery import importers, Compound
from cadquery.occ_impl.exporters.dxf import DxfDocument
from OCP.BRepLib import BRepLib
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt

STP_FOLDER = Path("./stp_files_basic_hole")
SAVE_PATH = STP_FOLDER / "quick_view.dxf"
dxf_color_map = {"白": 7, "綠": 3, "青": 4}
dxf_layer_items = {
    "0": {"color": dxf_color_map["白"], "linetype": "CONTINUOUS", "lineweight": 18},
    "HID": {"color": dxf_color_map["綠"], "linetype": "HIDDEN", "lineweight": 18},
    "TAN": {"color": dxf_color_map["青"], "linetype": "CONTINUOUS", "lineweight": 18},
}
VIEW_CFGS = {
    "top": {"N": (0, 1, 0), "U": (0, 0, -1), "grid": (1, 2)},
    "left": {"N": (-1, 0, 0), "U": (0, 1, 0), "grid": (0, 1)},
    "front": {"N": (0, 0, 1), "U": (0, 1, 0), "grid": (1, 1)},
    "right": {"N": (1, 0, 0), "U": (0, 1, 0), "grid": (2, 1)},
    "bottom": {"N": (0, -1, 0), "U": (0, 0, 1), "grid": (1, 0)},
}
def sort_key(path):
    nums = re.findall(r"\d+", path.stem)
    return int(nums[-1]) if nums else path.stem
def init_dxf_document():
    dxf_doc = DxfDocument(setup=["linetypes"])
    if "HIDDEN" not in dxf_doc.document.linetypes:
        dxf_doc.document.linetypes.add("HIDDEN", pattern=[4, 3, -1], description="Hidden __ __ __ __ __ __ __")
    for layer_name, layer_item in dxf_layer_items.items():
        if layer_name not in dxf_doc.document.layers:
            dxf_doc.add_layer(layer_name, color=layer_item["color"], linetype=layer_item["linetype"])
        layer = dxf_doc.document.layers.get(layer_name)
        layer.dxf.color = layer_item["color"]
        layer.dxf.linetype = layer_item["linetype"]
        layer.dxf.lineweight = layer_item["lineweight"]
    return dxf_doc
def cal_proj_hlr(stp_shape, view_normal_dir, x_dir, eta=1e-3):
    hlr = HLRBRep_Algo()
    hlr.Add(stp_shape.wrapped)
    hlr.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(), gp_Dir(*view_normal_dir), gp_Dir(*x_dir))))
    hlr.Update()
    hlr.Hide()
    hlr_shapes = HLRBRep_HLRToShape(hlr)
    visible = []
    hidden = []
    tan = []
    for target, items in (
        (visible, (hlr_shapes.VCompound(), hlr_shapes.OutLineVCompound())),
        (tan, (hlr_shapes.Rg1LineVCompound(),)),
        (hidden, (hlr_shapes.HCompound(), hlr_shapes.OutLineHCompound())),
    ):
        for item in items:
            if item.IsNull():
                continue
            BRepLib.BuildCurves3d_s(item, eta)
            for edge in Compound(item).Edges():
                target.append(edge)
    return visible, hidden, tan
def get_x_dir(view):
    u = view["U"]
    n = view["N"]
    return (u[1] * n[2] - u[2] * n[1], u[2] * n[0] - u[0] * n[2], u[0] * n[1] - u[1] * n[0])
def add_proj_views(dxf_doc, stp_path, offset_x=0, spacing=18):
    shape = importers.importStep(str(stp_path)).val()
    view_data = {}
    for name, cfg in VIEW_CFGS.items():
        visible, hidden, tan = cal_proj_hlr(shape, cfg["N"], get_x_dir(cfg))
        all_items = visible + hidden + tan
        if not all_items:
            raise ValueError(f"{stp_path} {name} view no projection edge")
        bb = Compound.makeCompound(all_items).BoundingBox()
        view_data[name] = {"visible": visible, "hidden": hidden, "tan": tan, "bb": bb, "width": bb.xlen, "height": bb.ylen, "grid": cfg["grid"]}
    col_w = [
        view_data["left"]["width"],
        max(view_data["top"]["width"], view_data["front"]["width"], view_data["bottom"]["width"]),
        view_data["right"]["width"],
    ]
    row_h = [
        view_data["bottom"]["height"],
        max(view_data["left"]["height"], view_data["front"]["height"], view_data["right"]["height"]),
        view_data["top"]["height"],
    ]
    col_x = [offset_x, offset_x + col_w[0] + spacing, offset_x + col_w[0] + spacing + col_w[1] + spacing]
    row_y = [0, row_h[0] + spacing, row_h[0] + spacing + row_h[1] + spacing]
    count = 0
    for view in view_data.values():
        c, r = view["grid"]
        dx = float(col_x[c] + (col_w[c] - view["width"]) / 2 - view["bb"].xmin)
        dy = float(row_y[r] + (row_h[r] - view["height"]) / 2 - view["bb"].ymin)
        for items, layer in ((view["hidden"], "HID"), (view["visible"], "0"), (view["tan"], "TAN")):
            for item in items:
                edge = item.translate((dx, dy, 0))
                dxf_doc.add_shape(cq.Workplane("XY").newObject([edge]), layer)
                count += 1
    return float(sum(col_w) + spacing * 2), count
def main():
    dxf_doc = init_dxf_document()
    offset_x = 0
    output_items = []
    for stp_path in sorted(STP_FOLDER.glob("*.stp"), key=sort_key):
        width, count = add_proj_views(dxf_doc, stp_path, offset_x)
        output_items.append({"stp_path": str(stp_path), "offset": offset_x, "width": width, "count": count})
        offset_x += width + 40
        print("ok", stp_path, count)
    SAVE_PATH.parent.mkdir(parents=True, exist_ok=True)
    dxf_doc.document.saveas(SAVE_PATH)
    print("ok", SAVE_PATH, len(dxf_doc.document.modelspace()), output_items)
if __name__ == "__main__":
    main()
