from pathlib import Path
import math
import random
import cadquery as cq
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from ezdxf.addons.drawing import RenderContext, Frontend
from ezdxf.addons.drawing.matplotlib import MatplotlibBackend
from toolbox.stp_generator import STP_Generator
try:
    from toolbox.cad_helper import cvt_stp_2_proj_views
except ModuleNotFoundError:
    from cad_helper import STP_Helper
    def cvt_stp_2_proj_views(stp_path, out_path=None, show_hidden=True, spacing=45, text_height=3):
        hpr = STP_Helper()
        hpr.load(stp_path)
        doc = hpr.proc_proj_stp_all_views(show_hidden=show_hidden, spacing=spacing)
        hpr.proc_fix_edges()
        if out_path is not None:
            doc.saveas(str(out_path))
        return doc

SAVE_FOLDER = Path("./stp_files_0613")

def gen_func01():
    hpr = STP_Generator()
    hpr.box([72, 58, 24])
    hpr.chamfer("front", "out-corner", val=3)
    rng = random.Random(613)
    face_ranges = {
        "front": ((-28, 28), (-21, 21)),
        "back": ((-28, 28), (-21, 21)),
        "left": ((-21, 21), (-8, 8)),
        "right": ((-21, 21), (-8, 8)),
        "up": ((-28, 28), (-8, 8)),
        "down": ((-28, 28), (-8, 8)),
    }
    for face, ranges in face_ranges.items():
        for ix in range(3):
            x = rng.randint(ranges[0][0], ranges[0][1])
            y = rng.randint(ranges[1][0], ranges[1][1])
            r = ["M3", 1.8, 2.5][ix % 3]
            hpr.hole(face, [x, y], r=r, depth=5 + ix, drilling=True)
    return hpr

def gen_func02():
    hpr = STP_Generator()
    hpr.box([80, 50, 8])
    hpr.hole("left", [[-16, 0], [16, 0]], r="M4", depth=6, drilling=True)
    hpr.hole("down", [[-26, 0], [0, 0], [26, 0]], r=2.5, depth=5, drilling=False)
    hpr.extend_rect("front", "-", p1=[8, 4], p2=[36, 24], h=12)
    hpr.slot("front", [-22, 12], r=3, c2c=14, depth=3)
    return hpr

def gen_func03():
    hpr = STP_Generator()
    hpr.cylinder(12, 54)
    hpr.extend_circle("front", "+", c=[0, 0], h=8, r=18)
    hpr.extend_circle("back", "+", c=[0, 0], h=6, r=8)
    hpr.hole("front", [0, 0], r="M6", depth="ALL", drilling=True)
    hpr.chamfer("front", "out-corner", val=1)
    hpr.chamfer("back", "out-corner", val=1)
    return hpr

def gen_func04():
    hpr = STP_Generator()
    hpr.box([90, 40, 8])
    hpr.slot("front", [[-25, 0], [25, 0]], r=3, c2c=18, depth="ALL")
    hpr.hole("front", [[-38, -13], [38, -13], [-38, 13], [38, 13]], r="M5", depth=7, drilling=True)
    return hpr

def gen_func05():
    hpr = STP_Generator()
    hpr.box([70, 70, 10])
    hpr.extend_circle("front", "+", c=[0, 0], h=8, r=18)
    hpr.hole("front", [0, 0], r="M8", depth="ALL", drilling=True)
    pts = [[17, 17], [-17, 17], [-17, -17], [17, -17]]
    hpr.hole("front", pts, r=2.5, depth="ALL", drilling=True)
    hpr.round("front", "out-corner", val=1)
    return hpr

def gen_func06():
    hpr = STP_Generator()
    hpr.box([60, 42, 12])
    hpr.extend_rect("front", "+", p1=[-20, -12], p2=[20, 12], h=6)
    hpr.extend_rect("front", "+", p1=[-10, -6], p2=[10, 6], h=5)
    hpr.hole("front", [0, 0], r="M6", depth=10, drilling=True)
    hpr.hole("right", [[-10, 0], [10, 0]], r=2, depth=8, drilling=False)
    return hpr

def gen_func07():
    hpr = STP_Generator()
    hpr.box([80, 38, 8])
    hpr.extend_rect("left", "+", p1=[-18, -4], p2=[18, 32], h=8)
    hpr.hole("front", [[-26, 0], [26, 0]], r=3, depth="ALL", drilling=False)
    hpr.hole("left", [[-10, 12], [10, 12]], r="M4", depth=6, drilling=True)
    hpr.chamfer("front", "out-corner", val=1)
    return hpr

def gen_func08():
    hpr = STP_Generator()
    hpr.box([70, 46, 28])
    side_pts = []
    for ix in range(3):
        for iy in range(2):
            side_pts.append([-22 + ix * 22, -7 + iy * 14])
    hpr.hole("up", side_pts, r=2.5, depth=9, drilling=False)
    hpr.hole("up", [[-11, 0], [11, 0]], r="M3", depth=8, drilling=True)
    hpr.hole("front", [[-24, -12], [24, -12]], r="M4", depth=7, drilling=True)
    hpr.hole("front", [0, 12], r=4, depth=10, drilling=False)
    hpr.hole("left", [[-8, 0], [8, 0]], r=3, depth=12, drilling=False)
    return hpr

def gen_func09():
    hpr = STP_Generator()
    hpr.box([76, 56, 12])
    hpr.extend_rect("front", "-", p1=[-26, -18], p2=[26, 18], h=5)
    hpr.extend_rect("front", "-", p1=[-8, -28], p2=[8, 28], h=14)
    hpr.hole("front", [[-30, -20], [30, -20], [-30, 20], [30, 20]], r="M5", depth=8, drilling=True)
    hpr.slot("right", [0, 0], r=2.5, c2c=16, depth=10)
    return hpr

def gen_func10():
    hpr = STP_Generator()
    hpr.cylinder(32, 10)
    bolt_pts = [[22, 0], [11, 19], [-11, 19], [-22, 0], [-11, -19], [11, -19]]
    hpr.hole("front", bolt_pts, r=2.5, depth="ALL", drilling=True)
    hpr.hole("front", [0, 0], r="M10", depth="ALL", drilling=True)
    hpr.extend_circle("front", "+", c=[0, 0], h=6, r=14)
    hpr.chamfer("front", "out-corner", val=1)
    return hpr

def gen_func11():
    hpr = STP_Generator()
    hpr.box([76, 46, 16])
    hpr.extend_rect("front", "-", p1=[-25, -12], p2=[25, 12], h=5)
    hpr.slot("front", [0, 0], r=3, c2c=24, depth="ALL")
    hpr.hole("front", [[-29, -16], [29, -16], [-29, 16], [29, 16]], r="M4", depth="ALL", drilling=True)
    hpr.chamfer("front", "out-corner", val=1)
    hpr.round("back", "out-corner", val=1.2)
    hpr.chamfer("front", "in-corner", val=0.45)
    hpr.round("back", "in-corner", val=0.35)
    return hpr

def gen_func12():
    hpr = STP_Generator()
    hpr.box([84, 56, 18])
    pts = [[-26, -16], [26, -16], [-26, 16], [26, 16]]
    hpr.hole("front", pts, r=2.5, depth="ALL", drilling=False)
    hpr.hole("front", pts, r=5, depth=7, drilling=False)
    hpr.hole("front", [0, 0], r=4, depth="ALL", drilling=False)
    hpr.hole("front", [0, 0], r=8, depth=6, drilling=False)
    hpr.chamfer("front", "out-corner", val=1)
    return hpr

def gen_func13():
    hpr = STP_Generator()
    hpr.box([60, 60, 10])
    pts = [[-20, -20], [20, -20], [-20, 20], [20, 20]]
    hpr.hole("front", [0, 0], r="M6", depth="ALL", drilling=True)
    hpr.hole("front", [0, 0], r=6, depth=3, drilling=False)
    hpr.hole("back", pts, r=3, depth="ALL", drilling=True)
    hpr.hole("back", pts, r=5, depth=3, drilling=False)
    return hpr

def gen_func14():
    hpr = STP_Generator()
    hpr.box([60, 60, 10])
    pts = [[-20, -20], [20, -20], [-20, 20], [20, 20]]
    hpr.hole("front", [0, 0], r="M6", depth="ALL", drilling=True)
    hpr.hole("front", [0, 0], r=6, depth=3, drilling=False)
    hpr.hole("back", pts, r=3, depth=4, drilling=True)
    hpr.hole("back", pts, r=5, depth=2, drilling=False)
    return hpr

def gen_func15():
    hpr = gen_func14()
    pts = [[-16, 0], [16, 0]]
    hpr.hole("left", pts, r="M4", depth=12, drilling=True)
    hpr.hole("left", pts, r=4, depth=6, drilling=False)
    return hpr

GEN_ITEMS = [
    ("part001", gen_func01),
    ("part002", gen_func02),
    ("part003", gen_func03),
    ("part004", gen_func04),
    ("part005", gen_func05),
    ("part006", gen_func06),
    ("part007", gen_func07),
    ("part008", gen_func08),
    ("part009", gen_func09),
    ("part010", gen_func10),
    ("part011", gen_func11),
    ("part012", gen_func12),
    ("part013", gen_func13),
    ("part014", gen_func14),
    ("part015", gen_func15),
]

def save_one(name, gen_func):
    SAVE_FOLDER.mkdir(parents=True, exist_ok=True)
    path = SAVE_FOLDER / f"{name}.stp"
    dxf_path = SAVE_FOLDER / f"{name}_quick.dxf"
    png_path = SAVE_FOLDER / f"{name}.png"
    hpr = gen_func()
    hpr.save(path)
    doc = cvt_stp_2_proj_views(path, out_path=dxf_path, show_hidden=True, spacing=45, text_height=3)
    fig = plt.figure(figsize=(8, 8), facecolor="black")
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_facecolor("black")
    ax.axis("off")
    Frontend(RenderContext(doc), MatplotlibBackend(ax)).draw_layout(doc.modelspace(), finalize=True)
    fig.savefig(png_path, dpi=180, facecolor=fig.get_facecolor(), bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)
    shape = cq.importers.importStep(str(path)).val()
    bb = shape.BoundingBox()
    return {"file": str(path), "png": str(png_path), "valid": shape.isValid(), "bbox": [round(bb.xlen, 3), round(bb.ylen, 3), round(bb.zlen, 3)]}

def main():
    for name, gen_func in GEN_ITEMS:
        info = save_one(name, gen_func)
        print(name, info["valid"], info["bbox"], info["file"], info["png"])

if __name__ == "__main__":
    main()
