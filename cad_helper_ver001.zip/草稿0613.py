



----------------------------------------------------------------
中心線如何標註?

load stp
gather 圓柱面/圓錐端點
 -> 紀錄圓柱面兩個圓盤的中心點 + 半徑, 所以會有 item = {"p1":[x1,y1,z1], "p2":[x2,y2,z2], "r":r}
 -> 紀錄圓錐面圓盤與尖端的座標 + 半徑, 所以會有 pts ={"p1":[x1,y1,z1], "p2":[x2,y2,z2], "r":r} 統一 p2 是尖端

.... 做了投影, 也得到投影矩陣了

先做 quick 初標註
for this_view in all_views
    pts = 投影剛剛蒐集好的點
    p1_all = self.cen_pts_info["p1"] -> 前一行已經壓成2D了
    p2_all = self.cen_pts_info["p2"]
    r_all = self.cen_pts_info["r"]
    
    dir_all = cal_length(p1_all, p2_all)
    if length < self.tol : dir = "Dot"
    else : dir = "Line"
    for item in all:
        if dir is "Dot" : 
            org_xy = get_this_view_orginal_xy
            add_line([org_x+ (p1_x-r-extend), org_y+p1_y], org_x+ (p1_x+r+extend), org_y+p1_y])
            add_line([org_x+ p1_x, org_y+(p1_y-r-extend)], org_x+ p1_x, org_y+(p1_y+r+extend)])
            

    
之後做去重
for this_view in views
    find_unqiue_x in all center lines
    find_unqiue_y in all center lines
	
    for this_unique_x
        if 重疊或是聯集 : new_lines = min -> max
        if 沒有交集 : 不要採取任何動作
        
    for this_unique_y
        if 重疊或是聯集 : new_lines = min -> max
        if 沒有交集 : 不要採取任何動作

中心線標註理論是不需要同零件內 views 相互考慮的
----------------------------------------------------------------









